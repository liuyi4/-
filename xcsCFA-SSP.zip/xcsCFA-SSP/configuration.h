enum Environment{
    multiplexer, hiddenEvenParity, hiddenOddParity, countOnes, carry, evenParity, majorityOn, dv1
};

const Environment env = multiplexer;

const int condLength = 11; // 6, 11, 20, and 37 for mux; 20 for others

// multiplexer environment settings
const int posBits = 3;//2, 3, 4, 5, and 6 for 6-, 11-, 20-, 37-, and 70-bits MUX respectively

// countOnes, hiddenEvenParity and hiddenOddParity environments settings
const int numRelevantBits = 11; 
const int posRelevantBits[] = {0,1,2,3,4,5,6,7,8,9,10}; //*/{1,5,8,12,15,17,19}; 

const int maxPopSize = 1.5*1000; //Specifies the maximal number of micro-classifiers in the population. [ (0.5, 1, 2, 6)*1000 for 6-, 11-, 20-, 37-bits MUX respectively]
const int maxProblems = 2*100*1000; //training set = (20,20,20,20)*100*1000 for 6-, 11-, 20-, 37-bits MUX respectively]
const int maxPayoff = 1000;

const int numActions = 2; //0 or 1

const int cfMaxDepth = 2; //2 3
const int cfMinDepth = 0;
const int cfMaxLength = 8; //8 16 pow(2,adfMaxDepth+1); //allow for endstop OPNOP
const int cfMaxArity = 2;
const int cfMaxStack = (cfMaxArity-1) * (cfMaxDepth-1) + 2;
const int cfMaxMuteDepth = 1;
const int maxOperands = 4; //4 8 pow(2,cfMaxDepth)
const int maxTestCases = 16; //16 256 pow(2,maxOperands)

typedef int opType;
const int opSize = sizeof(opType);

const opType OPNOP = 100; //to be used as ending symbol
const opType OPAND = 101;
const opType OPOR = 102;
const opType OPNAND = 103;
const opType OPNOR = 104;
const opType OPNOT = 105;

const opType functionCodes[] = {OPAND,OPOR,OPNAND,OPNOR,OPNOT};

const opType firstfunc = OPAND;
const int totalFunctions = 5;

struct Classifier{
	char condition[condLength];
	opType cfAction[cfMaxLength];
	double prediction;
	double predictionError;
	double accuracy;
	double fitness;
	int numerosity;
	int experience;
	double actionSetSize;
	int timeStamp;
	bool actionConsistency;
	int actionValue;
	unsigned long parentID[2];
	unsigned long ID;
};
struct ClassifierSet{
	Classifier *classifier;
	ClassifierSet *next;
};
