#include <fstream>
#include <math.h>
#include "configuration.h"

struct opcodeValue{// to be used in copmuting code fragment value
	opType opcode;
	int value;
};

struct testcase_Code_Value{// to be used in determining consistency of a code fragment
	opType code;
	char value;
};

void printAction(opType action[]);
void validateDepth(opType* cf, opType* end);
bool equalTwoCFs(opType cf1[], opType cf2[]);
void createNewCF(opType newCF[]);
void getOperandsOfCFAction(Classifier *clfr, int operands[], int& numOperands);
void insertOperand(int operands[], int& numOperands, opType operand);
int calculateNumberOfTestCases(Classifier *clfr, int operands[], int numOperands);
void fillTestCases(Classifier *clfr, int numTestCases, int operands[], int numOperands);
int getCodeFragmentValue(opType codeFragment[], testcase_Code_Value testCase[], int numOperands);
char getTestCaseValue(testcase_Code_Value testcase[], opType opcode, int numOperands);
bool isActionConsistent(Classifier *clfr);
int getActionValue(Classifier *clfr, char state[]);
int clfrConditionBasedActionValue(Classifier *clfr);
int currentInstanceBasedActionValue(Classifier *clfr, char state[]);
void resetOperands(opcodeValue operands[]);
int getCodeValue(opType code, opcodeValue operands[]);

int getNumberOfArguments(const opType opcode);
opType leafOpCode(const int r);
opType randomLeaf();
int validLeaf(const opType opcode);
opType randomFunction();
opType* randomProgram(opType* prog,const int isfull,const int maxDepth, const int minDepth);
char* leafname(const opType code);
char* opchar(const opType code);
void outprog_bin(const opType* prog, int size);
void outprog(const opType* const prog, int size, FILE *fp);
void DepthMax(const opType* const end,opType** prog, int& argstogo, int& depth);
int Depth(const opType* const end,opType** prog, const int depth);
int StackMax(const opType* prog, int size);
int getLengthOfProgram(const opType* prog, int maxLength);
int getLengthOfTree(const opType* prog);
void replaceTree(opType* prog, const int len, const int point, const int size0, const opType* in, const int size1);
int Point(const opType* prog,const int len);
void auxMutateProgram(opType* prog, int len, int LEN, int pMaxDepth, int pMaxMuteDepth);
void mutateProgram(opType prog[]);
void mutateN_prog(opType prog[]);
bool crossover(const int point1, opType prog1[], const int len1,const int point2, opType prog2[], const int len2, const int LEN, int pMaxDepth);
void crossover(opType prog1[],opType prog2[]);
