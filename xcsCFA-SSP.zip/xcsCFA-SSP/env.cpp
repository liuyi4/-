#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "xcsMacros.h"
#include "configuration.h"
#include "env.h"

const int sizeDV1 = 74;
const int DV1[] = {1, 2, 3, 8, 9, 10, 11, 13, 14, 24, 25, 26, 27, 28, 30, 40, 41, 42, 43, 46, 47, 56, 57, 58, 59, 61, 65, 66, 67, 69, 70, 71, 72, 73, 74, 75, 77, 78, 79, 81, 82, 83, 85, 86, 88, 89, 90, 91, 93, 94, 95, 97, 98, 99, 101, 102, 103, 104, 105, 106, 107, 109, 110, 113, 114, 115, 117, 118, 121, 122, 123, 125, 126, 127};

void resetState(char state[]){ //Generates a new random problem instance.
	for(int i=0; i<condLength; i++){
		if(drand()<0.5){
			state[i]='0';
		}
		else{
			state[i]='1';
		}
	}
}

double executeAction(int action, char state[], bool &correct){ // Executes the action and determines the reward.
    switch(env){
        case multiplexer:
            return executeMultiplexerAction(action,state,correct);
        case hiddenEvenParity:
            return executeHiddenEvenParityAction(action,state,correct);
        case hiddenOddParity:
            return executeHiddenOddParityAction(action,state,correct);
        case countOnes:
            return executeCountOnesAction(action,state,correct);
		case carry:
            return executeCarryAction(action,state,correct);
		case evenParity:
            return executeEvenParityAction(action,state,correct);
		case majorityOn:
            return executeMajorityOnAction(action,state,correct);
		case dv1:
            return executeDV1Action(action,state,correct);
        default:
            printf("\nEnvironment not supported!\n");
            exit(0);
    }
}

double executeMultiplexerAction(int action, char state[], bool &correct){
    int place=posBits;
	for(int i=0; i<posBits; i++){
	    if(state[i]=='1'){
			place += (int)pow(2.0, (double)(posBits-1-i));
	    }
	}
	int ret=0;
	if(action == state[place]-'0'){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeHiddenEvenParityAction(int action, char state[], bool &correct){
    int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 0){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeHiddenOddParityAction(int action, char state[], bool &correct){
    int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 1){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeCountOnesAction(int action, char state[], bool &correct){
	int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes > numRelevantBits/2){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;

}

double executeCarryAction(int action, char state[], bool &correct){ 
	int ret=0, actualAction = 0;
	int carry = 0, halfCondLength = condLength/2;
	for(int i=halfCondLength-1; i>=0; i--){
		carry = ((state[i] - '0') + (state[i+halfCondLength] - '0') + carry)/2;
	}
	actualAction = carry;

	/*
	printf("\nCondition: ");
	for(int i=0; i<condLength; i++){
		printf("%c ",state[i]);
	}
	printf("\nNum1: %d, Num2: %d, Sum: %d, Actual_Action: %d, Action: %d",num1,num2,sum,actualAction,action);
	*/
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeEvenParityAction(int action, char state[], bool &correct){
    int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<condLength; i++){
		if(state[i] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 0){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeMajorityOnAction(int action, char state[], bool &correct){
	int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<condLength; i++){
		if(state[i] == '1'){
			numOnes++;
		}
	}
	if (numOnes > condLength/2){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;

}

double executeDV1Action(int action, char state[], bool &correct){
	int ret=0;
	int actualAction = 0;
	int num = 0;
	int p = 0;
	for(int i=condLength-1; i>=0; i--){
		num += (state[i]-'0')*pow(2.0,p);
		p++;
	}
	if (isDV1Term(num)){
		actualAction = 1;
	}
	if(action == actualAction){
	    correct=true;
	    ret = maxPayoff;
	}
	else{
	    correct=false;
	    ret = 0;
	}
	return (double)ret;
}

bool isDV1Term(int n){
	for(int i=0; i<sizeDV1; i++){
		if(n == DV1[i]){
			return true;
		}
	}
	return false;
}
