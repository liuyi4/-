#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <fstream>
#include "xcsMacros.h"
#include "stateMachine.h"

void writeAction(StateMachine smAction, FILE *fp){
	char buf[100];
	sprintf(buf,"\nStart State: q_%d",smAction.smStartStateNumber); fwrite(buf,strlen(buf),1,fp);
	for(int i = 0; i<smAction.smNumberOfStates; i++){
		writeState(smAction.smStates[i],fp);
	}
	fwrite("\n",strlen("\n"),1,fp);
}

void writeState(State s, FILE *fp){
	char buf[100];
	sprintf(buf,"\nq_%d:\t",s.stateNumber); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"%d\t",s.stateValue); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"%d\t",s.isStateActive); fwrite(buf,strlen(buf),1,fp);
	for(int j=0; j<smMaxTransitions; j++){
		sprintf(buf,"%d\t",s.stateTransitions[j]); fwrite(buf,strlen(buf),1,fp);		
	}		
}

void printAction(StateMachine smAction){
	printf("\nStart State: q_%d",smAction.smStartStateNumber);
	for(int i = 0; i<smAction.smNumberOfStates; i++){
		printState(smAction.smStates[i]);
	}
}

void printState(State s){
	printf("\nq_%d:\t%d\t%d\t",s.stateNumber,s.stateValue,s.isStateActive);
	for(int i=0; i<smMaxTransitions; i++){
		printf("%d\t",s.stateTransitions[i]);
	}
}

bool isSameAction(StateMachine smAction1, StateMachine smAction2){
	if(smAction1.smStartStateNumber != smAction2.smStartStateNumber){
		return false;
	}
	if(smAction1.smNumberOfStates != smAction2.smNumberOfStates){
		return false;
	}
	for(int i=0; i<smAction1.smNumberOfStates; i++){
		if(!equalTwoStates(smAction1.smStates[i],smAction2.smStates[i])){
			return false;
		}
	}
	return true;
}

bool equalTwoStates(State s1, State s2){
	if(s1.stateNumber!=s2.stateNumber || s1.stateValue!=s2.stateValue || s1.isStateActive!=s2.isStateActive){
		return false;
	}
	for(int i=0; i<smMaxTransitions; i++){
		if(s1.stateTransitions[i] != s2.stateTransitions[i]){
			return false;
		}
	}
	return true;
}

// ################################## state machine construction ######################################

void randomStateMachine(StateMachine &smAction){
	int availedStateIndex = 0;
	int availableStates[smMaxStates];
	int numberAvailableStates = smMaxStates;
	for(int i=0; i<numberAvailableStates; i++){
		availableStates[i] = i;
	}

	smAction.smNumberOfStates = smMaxStates;
	smAction.smLength = smMaxStates*stateLength; 
	
	// set start state randomly, but it MUST be active. For simplicity, store the start state in the first position.
	availedStateIndex = irand(numberAvailableStates);
	smAction.smStartStateNumber = availableStates[availedStateIndex];
	smAction.smStates[0].stateNumber = smAction.smStartStateNumber;
	smAction.smStates[0].stateValue = irand(numActions); 
	smAction.smStates[0].isStateActive = 1; 
	for(int j=0; j<smMaxTransitions; j++){
		smAction.smStates[0].stateTransitions[j] = irand(smMaxStates);
	}

	//other states
	for(int k=availedStateIndex; k<numberAvailableStates-1; k++){
		availableStates[k] = availableStates[k+1];
	}
	numberAvailableStates--;
	for(int i=1; i<smMaxStates; i++){
		availedStateIndex = irand(numberAvailableStates);
		smAction.smStates[i].stateNumber = availableStates[availedStateIndex];
		smAction.smStates[i].stateValue = irand(numActions); 
		if(atCoveringAllActive){ //all active here
			smAction.smStates[i].isStateActive = 1; 
		}
		else{
			smAction.smStates[i].isStateActive = irand(2); 
		}
		for(int j=0; j<smMaxTransitions; j++){
			smAction.smStates[i].stateTransitions[j] = irand(smMaxStates);
		}
		for(int k=availedStateIndex; k<numberAvailableStates-1; k++){
			availableStates[k] = availableStates[k+1];
		}
		numberAvailableStates--;
	}
	//printAction(smAction); printf("\n");
}

// ####################################### state-machine action value ############################################

int getActionValue(Classifier *clfr, char inputMSG[]){
	
	/*printf("\n");
	for(int i=0; i<condLength; i++){
		printf("%c ",inputMSG[i]);
	}
	printf("\n");*/
	
	//printAction(clfr->smAction); printf("\n");
	int currentStateNumber = clfr->smAction.smStartStateNumber; 
	int currentStateIndex = findStateIndex(clfr->smAction,currentStateNumber);
	assert(clfr->smAction.smStates[currentStateIndex].isStateActive != 0);
		
	for(int i=0; i<condLength; i++){
		currentStateNumber = clfr->smAction.smStates[currentStateIndex].stateTransitions[inputMSG[i]-'0'];
		currentStateIndex = findStateIndex(clfr->smAction,currentStateNumber);
		assert(clfr->smAction.smStates[currentStateIndex].isStateActive != 0);
	}
	currentStateIndex = findStateIndex(clfr->smAction,currentStateNumber);
	int retValue = clfr->smAction.smStates[currentStateIndex].stateValue; // value of the inputMSG-ending state
	//printf("%d\n",retValue); 
	return retValue;

}

int findStateIndex(StateMachine smAction, int stateNumber){
	for(int i=0; i<smAction.smNumberOfStates; i++){
		if(smAction.smStates[i].stateNumber == stateNumber){
			return i;
		}
	}
	return -1;
}

// ################################## state machine evolution ######################################

void crossoverStateMachines(StateMachine &smAction1, StateMachine &smAction2){
	StateMachine action1=smAction1, action2=smAction2; 
	int numericAction1[smMaxLength], numericAction2[smMaxLength];
	//printAction(action1); printf("\n");	printAction(action2); printf("\n");
	do{
		getNumericAction(numericAction1,action1);
		getNumericAction(numericAction2,action2);
		if(crossoverType == 0){
			uniformCrossover(numericAction1, numericAction2, smAction1.smLength, smAction2.smLength);
		}
		else if(crossoverType == 1){
			onePointCrossover(numericAction1, numericAction2, smAction1.smLength, smAction2.smLength);
		}
		else{
			twoPointCrossover(numericAction1, numericAction2, smAction1.smLength, smAction2.smLength);
		}
		getSMAction(action1,numericAction1);
		getSMAction(action2,numericAction2);
		//printAction(action1); printf("\n");	printAction(action2); printf("\n");
	}while( duplicateStates(action1) || duplicateStates(action2) );

	

	smAction1 = action1;
	smAction2 = action2;

	/*
	// randomly set a start start for each of the crossedover state-machine actions
	int existingStatesNumber[smMaxStates];
	
	for(int i=0; i<smAction1.smNumberOfStates; i++){
		existingStatesNumber[i] = smAction1.smStates[i].stateNumber;
	}
	smAction1.smStartStateNumber = existingStatesNumber[irand(smAction1.smNumberOfStates)];

	for(int i=0; i<smAction2.smNumberOfStates; i++){
		existingStatesNumber[i] = smAction2.smStates[i].stateNumber;
	}
	smAction2.smStartStateNumber = existingStatesNumber[irand(smAction2.smNumberOfStates)];
	*/
}

void uniformCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length){ // Crosses the two action machines using uniform crossover.
	int len1 = smAction1Length;
	int len2 = smAction2Length;
	int len = (len1 < len2)? len1 : len2;
	int help;
	for(int i=0; i<len; i++){
		if(drand() < 0.5){
			help = numericAction1[i];
			numericAction1[i] = numericAction2[i];
			numericAction2[i] = help;
		}
	}
}

void onePointCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length){ // Crosses the two action machines using one-point crossover.
	int len1 = smAction1Length;
	int len2 = smAction2Length;
	int len = (len1 < len2)? len1 : len2;
	int help;
	int sep = irand(len);
	for(int i=0; i<=sep; i++){
		help = numericAction1[i];
		numericAction1[i] = numericAction2[i];
		numericAction2[i] = help;
	}
}

void twoPointCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length){ // Crosses the two action machines using two-point crossover.
	int len1 = smAction1Length;
	int len2 = smAction2Length;
	int len = (len1 < len2)? len1 : len2;
	int help;
	int sep1 = irand(len);
	int sep2 = irand(len);
	if(sep1>sep2){
		int helpSEP=sep1;
		sep1=sep2;
		sep2=helpSEP;
	}
	for(int i=sep1; i<=sep2; i++){
		help = numericAction1[i];
		numericAction1[i] = numericAction2[i];
		numericAction2[i] = help;
	}
}

void mutateStateMachine(StateMachine &smAction){ //Mutates the action machine.
	int existingStatesNumber[smMaxStates];
	
	for(int i=0; i<smAction.smNumberOfStates; i++){
		existingStatesNumber[i] = smAction.smStates[i].stateNumber;
	}

	/*
	if( smAction.smNumberOfStates>1 && drand()<pM ){ // change start state number
		int previousStartStateNumber = smAction.smStartStateNumber;
		do{
			smAction.smStartStateNumber = existingStatesNumber[irand(smAction.smNumberOfStates)];
		}while(smAction.smStartStateNumber == previousStartStateNumber);
	}
	*/

	for(int i=0; i<smAction.smNumberOfStates; i++){
		if(drand() < pM){
			int n = 1 + irand(stateLength-1); // state number is not mutated
			if(n==1){ // mutate state value
				int v = smAction.smStates[i].stateValue;
				do{
					smAction.smStates[i].stateValue = irand(numActions);
				}while(smAction.smStates[i].stateValue == v);
			} 
			else if(n==2){ // mutate isActive flag
				smAction.smStates[i].isStateActive = (smAction.smStates[i].isStateActive == 1) ? 0 : 1;
			}
			else if(smAction.smNumberOfStates>1){ // mutate a transition
				int j = irand(smMaxTransitions);
				int s = smAction.smStates[i].stateTransitions[j];
				do{
					smAction.smStates[i].stateTransitions[j] = existingStatesNumber[irand(smAction.smNumberOfStates)];
				}while(smAction.smStates[i].stateTransitions[j] == s);
			}	
		}
	}	
}

void getNumericAction(int numericAction[], StateMachine smAction){
	int index = 0;
	for(int i=0; i<smAction.smNumberOfStates; i++){
		numericAction[index++] = smAction.smStates[i].stateNumber;
		numericAction[index++] = smAction.smStates[i].stateValue;
		numericAction[index++] = smAction.smStates[i].isStateActive;
		for(int j=0; j<smMaxTransitions; j++){
			numericAction[index++] = smAction.smStates[i].stateTransitions[j];
		}
	}
}

void getSMAction(StateMachine &smAction, int numericAction[]){
	int index = 0;
	for(int i=0; i<smAction.smNumberOfStates; i++){
		smAction.smStates[i].stateNumber = numericAction[index++];
		smAction.smStates[i].stateValue = numericAction[index++];
		smAction.smStates[i].isStateActive = numericAction[index++];
		for(int j=0; j<smMaxTransitions; j++){
			smAction.smStates[i].stateTransitions[j] = numericAction[index++];
		}
	}
	smAction.smStartStateNumber = smAction.smStates[0].stateNumber; // IMPORTANT
}

bool duplicateStates(StateMachine smAction){
	for(int i=0; i<smAction.smNumberOfStates-1; i++){
		for(int j=i+1; j<smAction.smNumberOfStates; j++){
			if(smAction.smStates[i].stateNumber == smAction.smStates[j].stateNumber){
				return true;
			}
		}
	}
	return false;
}

void validateSMAction(StateMachine &smAction){
	int startStateIndex = findStateIndex(smAction,smAction.smStartStateNumber); 
	assert(startStateIndex != -1);
	smAction.smStates[startStateIndex].isStateActive = 1; // Start state MUST be active, otherwise it is a junk state machine
	int activeStates[smMaxStates];
	int numActiveStates = 0; 

	for(int i=0; i<smAction.smNumberOfStates; i++){
		if(smAction.smStates[i].isStateActive == 1){
			activeStates[numActiveStates++] = smAction.smStates[i].stateNumber;
		}
	}

	for(int i=0; i<smAction.smNumberOfStates; i++){
		if(smAction.smStates[i].isStateActive == 1){ // if it is active
			for(int j=0; j<smMaxTransitions; j++){
				if(!isValidTransition(smAction.smStates[i].stateTransitions[j],activeStates,numActiveStates)){
					smAction.smStates[i].stateTransitions[j] = activeStates[irand(numActiveStates)];
				}
			}			
		}
	}

	if(doRemoveNonReachableStates == true){
		removeNonReachableStates(smAction);
	}
}

void removeNonReachableStates(StateMachine &smAction){
	// first find the reachable states
	int reachableStates[smMaxStates];
	int numReachableStates = 0;
	reachableStates[numReachableStates++] = smAction.smStartStateNumber; // start state is ALWAYS reachable
	for(int i=0; i<numReachableStates; i++){
		for(int j=0; j<smMaxTransitions; j++){
			int reachableStateIndex = findStateIndex(smAction,reachableStates[i]);
			int nextReachableStateNumber = smAction.smStates[reachableStateIndex].stateTransitions[j];
			if(isNewReachableState(nextReachableStateNumber,reachableStates,numReachableStates)){
				reachableStates[numReachableStates++] = nextReachableStateNumber;
			}
		}	
	}
	// now remove the non-reachable states
	for(int i=0; i<smAction.smNumberOfStates; i++){
		if(!isReachableState(smAction.smStates[i].stateNumber,reachableStates,numReachableStates)){ // if it is not reachable
			removeState(smAction,i);
			i--;
		}
	}
}

bool isReachableState(int stateNumber, int reachableStates[], int numReachableStates){
	for(int i=0; i<numReachableStates; i++){
		if(stateNumber == reachableStates[i]){ 
			return true;
		}
	}
	return false;
}

bool isNewReachableState(int stateNumber, int reachableStates[], int numReachableStates){
	for(int i=0; i<numReachableStates; i++){
		if(stateNumber == reachableStates[i]){ 
			return false;
		}
	}
	return true;
}

void removeState(StateMachine &smAction, int stateIndex){
	//printf("B4 Removal .... \n"); printAction(smAction); printf("\n");
	for(int i=stateIndex; i<smAction.smNumberOfStates-1; i++){
		smAction.smStates[i] = smAction.smStates[i+1];
	}
	smAction.smNumberOfStates--;
	smAction.smLength -= stateLength;
	assert(smAction.smNumberOfStates > 0);
	//printf("After Removal .... \n"); printAction(smAction); printf("\n");
}

bool isValidTransition(int targetState, int activeStates[], int numActiveStates){
	for(int i=0; i<numActiveStates; i++){
		if(targetState == activeStates[i]){
			return true;
		}
	}
	return false;
}