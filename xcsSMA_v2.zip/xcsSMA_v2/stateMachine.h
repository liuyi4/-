#include <fstream>
#include <math.h>
#include "configuration.h"

void writeAction(StateMachine smAction,FILE *fp);
void writeState(State s, FILE *fp);
void printAction(StateMachine smAction);
void printState(State s);
bool isSameAction(StateMachine smAction1, StateMachine smAction2);
bool equalTwoStates(State s1, State s2);
int getActionValue(Classifier *clfr, char inputMSG[]);
int findStateIndex(StateMachine smAction, int stateNumber);
void randomStateMachine(StateMachine &smAction);
void crossoverStateMachines(StateMachine &smAction1, StateMachine &smAction2);
void uniformCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length);
void onePointCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length);
void twoPointCrossover(int numericAction1[], int numericAction2[], int smAction1Length, int smAction2Length);
void mutateStateMachine(StateMachine &smAction);
void getNumericAction(int numericAction[], StateMachine smAction);
void getSMAction(StateMachine &smAction, int numericAction[]);
bool duplicateStates(StateMachine smAction);
void validateSMAction(StateMachine &smAction);
void removeNonReachableStates(StateMachine &smAction);
bool isReachableState(int stateNumber, int reachableStates[], int numReachableStates);
bool isNewReachableState(int stateNumber, int reachableStates[], int numReachableStates);
void removeState(StateMachine &smAction, int stateIndex);
bool isValidTransition(int targetState, int activeStates[], int numActiveStates);