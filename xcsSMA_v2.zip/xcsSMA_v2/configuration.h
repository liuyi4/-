enum Environment{
    evenParity, multiplexer, hiddenEvenParity, hiddenOddParity, countOnes, majorityOn, dv1
};

const Environment env = multiplexer;

const int condLength = 11; // 6, 11, 20, and 37 for mux; 20 for others

// multiplexer environment settings
const int posBits = 3;//2, 3, 4, and 5 for 6-, 11-, 20-, 37-bits MUX respectively

// countOnes, hiddenEvenParity and hiddenOddParity environments settings
const int numRelevantBits = 9; // 7 for countOnes and 5 for both hiddenEvenParity and hiddenOddParity
const int posRelevantBits[] = {0,1,2,3,4,5,6,7,8}; 

const int maxPopSize = 1.5*1000; //Specifies the maximal number of micro-classifiers in the population. 
const int maxProblems = 20*100*1000; //training set 
const int maxPayoff = 1000;

const int numActions = 2; //0 or 1 

const int smMaxStates = (condLength > 10)?10:condLength;
const int smMaxTransitions = 2;
const int stateLength = 5; // (1 for stateNumber + 1 for stateValue + 1 for isStateActive + smMaxTransitions)
const int smMaxLength = smMaxStates * stateLength;

struct State{
	int stateNumber;
	int stateValue;
	int isStateActive; // 0 = false, 1 = true
	int stateTransitions[smMaxTransitions];
};

struct StateMachine{
	State smStates[smMaxStates];
	int smNumberOfStates;
	int smStartStateNumber;
	int smLength; // smNumberOfStates * stateLength
	
};

struct Classifier{
	char condition[condLength];
	StateMachine smAction;
	double prediction;
	double predictionError;
	double accuracy;
	double fitness;
	int numerosity;
	int experience;
	double actionSetSize;
	int timeStamp;
	bool usedInTesting;
};
struct ClassifierSet{
	Classifier *classifier;
	ClassifierSet *next;
};
