#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <fstream>
#include "xcsMacros.h"
#include "stateMachine.h"
#include "classifier.h"

double predictionArray[numActions]; //prediction array
double sumClfrFitnessInPredictionArray[numActions]; //The sum of the fitnesses of classifiers that represent each entry in the prediction array.

void setInitialVariables(Classifier *clfr, double setSize, int time){
	clfr->prediction = predictionIni;
	clfr->predictionError = predictionErrorIni;
	clfr->accuracy = fitnessIni;
	clfr->fitness = fitnessIni;
	clfr->numerosity = 1;
	clfr->experience = 0;
	clfr->actionSetSize = setSize;
	clfr->timeStamp = time;	
}

void initializePopulation(ClassifierSet **population){
	*population = NULL;
}

int getNumerositySum(ClassifierSet *set){
    int sum = 0;
    for(; set!=NULL; set=set->next){
        sum += set->classifier->numerosity;
    }
    return sum;
}

int getSetSize(ClassifierSet *set){
    int size = 0;
    for(; set!=NULL; set=set->next){
        size++;
    }
    return size;
}


// ####################### match set operations ##########################################

/**
 * Gets the match-set that matches state from pop.
 * If a classifier was deleted, record its address in killset to be
 * able to update former actionsets.
 * The iteration time 'itTime' is used when creating a new classifier
 * due to covering. Covering occurs when not all possible actions are
 * present in the match set. Thus, it is made sure that all actions
 * are present in the match set.
 */
ClassifierSet* getMatchSet(ClassifierSet **population, ClassifierSet **killset, char state[], int itTime){
	ClassifierSet *mset=NULL, *poppointer;
	Classifier *killedp, *coverClfr;
	int popSize=0, setSize=0, representedActions;

	bool coveredActions[numActions];

	for(poppointer= *population; poppointer!=NULL; poppointer=poppointer->next){
		popSize += poppointer->classifier->numerosity; // calculate the population size
		if(isConditionMatched(poppointer->classifier->condition,state)){
			addNewClassifierToSet(poppointer->classifier, &mset); // add matching classifier to the matchset
			setSize+=poppointer->classifier->numerosity; // calculate size of the match set
		}
	}

	representedActions = nrActionsInSet(mset,state,coveredActions);

	while(representedActions < numActions){ // create covering classifiers, if not all actions are covered
		for(int i=0; i<numActions; i++){
			if(coveredActions[i]==false){ // make sure that all actions are covered!
				coverClfr = matchingCondAndSpecifiedAct(state,i,setSize+1,itTime);
				//printClassifier(coverClfr);
				addNewClassifierToSet(coverClfr,&mset);
				setSize++;
				addNewClassifierToSet(coverClfr,population);
				popSize++;
			}
		}

	    /* Delete classifier if population is too big and record it in killset */
		while( popSize > maxPopSize ) {
			/* PL */
			killedp = deleteStochClassifier(population);
			if(killedp!=NULL) {
				deleteClassifierPointerFromSet(&mset, killedp);
  				addClassifierToPointerSet(killedp, killset);
			}
			popSize--;
		}
		representedActions = nrActionsInSet(mset,state,coveredActions);
	}
	return mset; // return the match set
}
/**
 * Returns the number of actions in the set and stores which actions are covered in the array coveredActions.
 */
int nrActionsInSet(ClassifierSet *set, char state[], bool coveredActions[]){
	int nr;

	for(int i=0; i<numActions; i++){
		coveredActions[i] = false;
	}

	for(nr=0; nr<numActions && set!=NULL; set=set->next){
		int actValue =  getActionValue(set->classifier,state);
		if(coveredActions[actValue]==false){
			coveredActions[actValue] = true;
			nr++;
		}
	}
	return nr;
}

bool isConditionMatched(char clfrCond[], char cond[]){
	for(int i=0; i<condLength; i++){
		if(clfrCond[i]!=dontcare && clfrCond[i]!=cond[i]){
			return false;
		}
	}
	return true;
}
Classifier* matchingCondAndSpecifiedAct(char state[], int act, int setSize, int time){ //matchingCondAndSpecifiedAct(currentState,i,matchSetNumerositySum+1,time)
	Classifier *clfr;
	assert((clfr=( struct Classifier*)calloc(1,sizeof(struct Classifier)))!=NULL); // get memory for the new classifier
	createMatchingCondition(clfr->condition,state);
	createSpecifiedAction(clfr,act,state);
	setInitialVariables(clfr,setSize,time);
	return clfr;
}
void createMatchingCondition(char cond[], char state[]){
	for(int i=0; i<condLength; i++){
		if(drand()<P_dontcare){
			cond[i] = dontcare;
		}
		else{
			cond[i] = state[i];
		}
	}
}
void createSpecifiedAction(Classifier *clfr, int actionValue, char state[]){
	int val;
	do{
		createRandomAction(clfr);
		val = getActionValue(clfr,state);
		//printf("\nHELP: val->%d, actionValue->%d\n",val,actionValue);
	}while(val!=actionValue);
}
void createRandomAction(Classifier *clfr){
	randomStateMachine(clfr->smAction);
	validateSMAction(clfr->smAction);
}

// ######################### prediction array operations ############################################

void getPredictionArray(ClassifierSet *ms, char state[]){ //determines the prediction array out of the match set ms
	assert(ms!=NULL); // ms should never be NULL (because of covering)
	for(int i=0; i<numActions; i++){
		predictionArray[i]=0.0;
	    sumClfrFitnessInPredictionArray[i]=0.0;
	}
	for(; ms!=NULL ; ms=ms->next){
		int actValue = getActionValue(ms->classifier,state);
	    predictionArray[actValue]+= ms->classifier->prediction*ms->classifier->fitness;
	    sumClfrFitnessInPredictionArray[actValue]+= ms->classifier->fitness;
	}
	for(int i=0; i<numActions; i++){
	    if(sumClfrFitnessInPredictionArray[i]!=0){
			predictionArray[i] /= sumClfrFitnessInPredictionArray[i];
	    }
		else{
			predictionArray[i]=0;
	    }
	}
}
double getBestValue(){ //Returns the highest value in the prediction array.
	double max = predictionArray[0];
	for(int i=1; i<numActions; i++){
		if(max<predictionArray[i]){
			max = predictionArray[i];
		}
	}
	return max;
}
int randomActionWinner(){ //Selects an action randomly. The function assures that the chosen action is represented by at least one classifier in the prediction array.
	int ret=0;
	do{
	    ret = irand(numActions);
	}while(sumClfrFitnessInPredictionArray[ret]==0);
	return ret;
}
int bestActionWinner(){ //Selects the action in the prediction array with the best value.
	int ret=0;
	for(int i=1; i<numActions; i++){
		if(predictionArray[ret]<predictionArray[i]){
			ret=i;
		}
	}
	return ret;
}
int rouletteActionWinner(){ //Selects an action in the prediction array by roulette wheel selection.
	double bidSum=0.0;
	int i;
	for(i=0; i<numActions; i++){
	    bidSum += predictionArray[i];
	}
	bidSum *= drand();
	double bidC=0.0;
	for(i=0; bidC<bidSum; i++){
	    bidC += predictionArray[i];
	}
	return i;
}

// ######################## action set operations #########################################

ClassifierSet* getActionSet(int action, ClassifierSet *ms, char state[]){ // constructs an action set out of the match set ms.
	ClassifierSet *aset=NULL;
	for(; ms!=NULL; ms=ms->next){
		int actValue = getActionValue(ms->classifier,state);
		if(action == actValue){
			addNewClassifierToSet(ms->classifier,&aset);
		}	
	}
  	return aset;
}

/**
 * Updates all parameters in the action set.
 * Essentially, reinforcement Learning as well as the fitness evaluation takes place in this set.
 * Moreover, the prediction error and the action set size estimate is updated. Also,
 * action set subsumption takes place if selected. As in the algorithmic description, the fitness is updated
 * after prediction and prediction error. However, in order to be more conservative the prediction error is
 * updated before the prediction.
 * @param maxPrediction The maximum prediction value in the successive prediction array (should be set to zero in single step environments).
 * @param reward The actual resulting reward after the execution of an action.
 */
void updateActionSet(ClassifierSet **aset, double maxPrediction, double reward, ClassifierSet **pop, ClassifierSet **killset){
    double P, setsize=0.0;
	ClassifierSet *setp;

	P = reward + gama*maxPrediction;
	
	for(setp=*aset; setp!=NULL; setp=setp->next){
		setsize += setp->classifier->numerosity;
		setp->classifier->experience++;
	}
	
	for(setp=*aset; setp!=NULL; setp=setp->next) { // update prediction, prediction error and action set size estimate
		if((double)setp->classifier->experience < 1.0/beta) {
			// !first adjustments! -> simply calculate the average 
			setp->classifier->predictionError = (setp->classifier->predictionError * ((double)setp->classifier->experience - 1.0) + absoluteValue(P - setp->classifier->prediction)) / (double)setp->classifier->experience;
			setp->classifier->prediction = (setp->classifier->prediction * ((double)setp->classifier->experience - 1.0) + P) / (double)setp->classifier->experience;
			setp->classifier->actionSetSize = (setp->classifier->actionSetSize *((double)(setp->classifier->experience - 1))+setsize)/(double)setp->classifier->experience; 
		}
		else{
			// normal adjustment -> use widrow hoff delta rule 
			setp->classifier->predictionError += beta * (absoluteValue(P - setp->classifier->prediction) - setp->classifier->predictionError);
			setp->classifier->prediction += beta * (P - setp->classifier->prediction);
			setp->classifier->actionSetSize += beta * (setsize - setp->classifier->actionSetSize);
		}
	}
	updateFitness(*aset);
	if(doActSetSubsumption){
		doActionSetSubsumption(aset,pop,killset);
	}
}

// update the fitnesses of an action set (the previous [A] in multi-step envs or the current [A] in single-step envs.) 
void updateFitness(ClassifierSet *aset){
	ClassifierSet *setp;
	double ksum=0.0;
	
	if(aset==NULL){ // if the action set got NULL (due to deletion) return
		return;
	}
  
	//First, calculate the accuracies of the classifier and the accuracy sums
	for(setp=aset; setp!=NULL; setp=setp->next) {
		if(setp->classifier->predictionError <= epsilon_0) {
			setp->classifier->accuracy = 1.0;
		}
		else{
			setp->classifier->accuracy = alpha * pow(setp->classifier->predictionError / epsilon_0 , -nu); 
		}
		ksum += setp->classifier->accuracy*(double)setp->classifier->numerosity;
	}
  
  //Next, update the fitnesses accordingly
  for(setp=aset; setp!=NULL; setp=setp->next) {
	setp->classifier->fitness += beta * ( (setp->classifier->accuracy * setp->classifier->numerosity) / ksum - setp->classifier->fitness );
  }
}

// ############################ discovery mechanism #########################################

/**
 * The discovery conmponent with the genetic algorithm 
 * note: some classifiers in set could be deleted ! 
 */
void discoveryComponent(ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int itTime, char situation[]){
	ClassifierSet *setp;
	Classifier *cl[2], *parents[2];
	double fitsum=0.0;
	int i, len, setsum=0, gaitsum=0;

	if(*set==NULL){ // if the classifier set is empty, return (due to deletion)
		return;
	}
  
	getDiscoversSums(*set, &fitsum, &setsum, &gaitsum); // get all sums that are needed to do the discovery 
  
	// do not do a GA if the average number of time-steps in the set since the last GA is less or equal than thetaGA
	if( itTime - (double)gaitsum / (double)setsum < theta_GA){
		return;
	}
	setTimeStamps(*set, itTime);
  
	selectTwoClassifiers(cl, parents, *set, fitsum, setsum); // select two classifiers (tournament selection) and copy them
  	crossover(cl,crossoverType); // do crossover on the two selected classifiers
	for(i=0; i<2; i++){ // do mutation 
		mutation(cl[i], situation);
	}
	
	// validate state-machine actions
	validateSMAction(cl[0]->smAction);
	validateSMAction(cl[1]->smAction);

	//if(crossed){	
		cl[0]->prediction   = (cl[0]->prediction + cl[1]->prediction) / 2.0; 
		cl[0]->predictionError = predictionErrorReduction * ( (cl[0]->predictionError + cl[1]->predictionError) / 2.0 );
		cl[0]->fitness = fitnessReduction * ( (cl[0]->fitness + cl[1]->fitness) / 2.0 ); 

		cl[1]->prediction = cl[0]->prediction;
		cl[1]->predictionError = cl[0]->predictionError;
		cl[1]->fitness = cl[0]->fitness;
	//}
	
	// get the length of the population to check if clasifiers have to be deleted
	for(len=0, setp=*pop; setp!=NULL; setp=setp->next){
		len += setp->classifier->numerosity;
	}
  
	// insert the new two classifiers and delete two if necessary
	insertDiscoveredClassifier(cl, parents, set, pop, killset, len);
}
void getDiscoversSums(ClassifierSet *set, double *fitsum, int *setsum, int *gaitsum){ // Calculate all necessary sums in the set for the discovery component.
	ClassifierSet *setp;
  
	*fitsum=0.0;
	*setsum=0;  
	*gaitsum=0;
	for(setp=set; setp!=NULL; setp=setp->next){
		(*fitsum)+=setp->classifier->fitness;
		(*setsum)+=setp->classifier->numerosity;
		(*gaitsum) += setp->classifier->timeStamp*setp->classifier->numerosity;
	}
}
void setTimeStamps(ClassifierSet *set, int itTime){ // Sets the time steps of all classifiers in the set to itTime (because a GA application is occurring in this set!).
	for( ; set!=NULL; set=set->next){
		set->classifier->timeStamp = itTime;
	}
}

// ########################### selection mechanism ########################################

/**
 * Select two classifiers using the chosen selection mechanism and copy them as offspring. 
 */
void selectTwoClassifiers(Classifier **cl, Classifier **parents, ClassifierSet *set, double fitsum, int setsum){
	int i; /*,j, length;*/
	Classifier *clp;

	assert(set!=NULL);

	for(i=0;i<2;i++) {
		if(tournamentSize == 0){
			clp = selectClassifierUsingRWS(set,fitsum);
		}
		else{
			if(i==0){
				clp = selectClassifierUsingTournamentSelection(set, setsum, 0);
			}
			else{
				clp = selectClassifierUsingTournamentSelection(set, setsum, parents[0]);
			}
		}
		
		parents[i]=clp;
		
		assert((cl[i]=(struct Classifier *)calloc(1,sizeof(struct Classifier)))!=NULL);
		
		memmove( &(cl[i]->condition),&(clp->condition),sizeof(clp->condition) );
		memmove( &(cl[i]->smAction),&(clp->smAction),sizeof(clp->smAction) );
      
		cl[i]->prediction = clp->prediction;
		cl[i]->predictionError = clp->predictionError;
		cl[i]->accuracy = clp->accuracy;
		cl[i]->fitness = clp->fitness / (double)clp->numerosity;
		cl[i]->numerosity = 1;
		cl[i]->experience = 0;
		cl[i]->actionSetSize = clp->actionSetSize;
		cl[i]->timeStamp = clp->timeStamp;
	}
}

/** 
 * Selects a classifier from 'set' using tournament selection.
 * If 'notMe' is not the NULL pointer and forceDifferentInTournament is set to a value larger 0,
 * this classifier is not selected except if it is the only classifier. 
 */
Classifier* selectClassifierUsingTournamentSelection(ClassifierSet *set, int setsum, Classifier *notMe){
	ClassifierSet *setp, *winnerSet=NULL;
	Classifier *winner=NULL;
	double fitness=-1.0, value;
	int i, j, *sel, size=0;

	assert(set!=NULL);/* there must be at least one classifier in the set */
  
	if(notMe!=0) {
		if(drand() < forceDifferentInTournament){
			setsum -= notMe->numerosity; 
		}
		else{
			notMe=0; /* picking the same guy is allowed */
		}
	}
	if(setsum<=0){ /* only one classifier in set */
		return set->classifier;
	}

	if(tournamentSize>1){/* tournament with fixed size */
		assert((sel = (int *)calloc(setsum, sizeof(int)))!=NULL);
		for(i=0; i<tournamentSize; i++) { /* (with replacement) */
			sel[irand(setsum)]=1;
		}
		if(i-tournamentSize != 0 && drand() > i-tournamentSize) {
			/* possible probabilistic selection of the last guy */
			sel[irand(setsum)]=1;
		}
		for(setp=set, i=0; setp!=NULL; setp=setp->next) {
			if(setp->classifier != notMe) {
				if(fitness < setp->classifier->fitness/setp->classifier->numerosity) {
					for(j=0; j<setp->classifier->numerosity; j++) {
						if(sel[i+j]) {
							freeSet(&winnerSet);
							addClassifierToPointerSet(setp->classifier, &winnerSet);
							fitness = setp->classifier->fitness/setp->classifier->numerosity;
							break; /* go to next classifier since this one is already a winner*/
						}
					}
				}
				i += setp->classifier->numerosity;
			}
		}
		free(sel);
		assert(winnerSet!=NULL);
		size=1;
	}
	else{/* tournament selection with the tournament size approx. equal to tournamentSize*setsum */
		winnerSet=NULL;
		while(winnerSet==NULL) {
			size=0;
			for(setp=set; setp!=NULL; setp=setp->next) {
				if(setp->classifier != notMe) { /* do not reselect the same classifier -> this only applies if forcedDifferentInTournament is set!*/
					value = setp->classifier->predictionError;
					if(winnerSet==NULL || (!doGAErrorBasedSelect && fitness - selectTolerance <= setp->classifier->fitness/setp->classifier->numerosity) || (doGAErrorBasedSelect && fitness + selectTolerance * maxPayoff >= value)) {
						/* if his fitness is worse then do not bother */
						for(i=0; i<setp->classifier->numerosity; i++) {
							if(drand() < tournamentSize) {
								/* this classifier is a selection candidate and 
								* his fitness/error is higher/lower or similar to the other classifier */
								if(winnerSet==NULL) {
									/* the first guy in the tournament */
									addClassifierToPointerSet(setp->classifier, &winnerSet);
									if(doGAErrorBasedSelect) {
										fitness = value;
									}
									else{
										fitness = setp->classifier->fitness/setp->classifier->numerosity;
									}
									size=1;
								}
								else{
									/* another guy in the tournament */
									if( (!doGAErrorBasedSelect && fitness + selectTolerance > setp->classifier->fitness/setp->classifier->numerosity) ||(doGAErrorBasedSelect && fitness - selectTolerance * maxPayoff < value)) {
										/* both classifiers in tournament have a similar fitness/error */
										size += addClassifierToPointerSet(setp->classifier, &winnerSet);
									}
									else{
										/* new classifier in tournament is clearly better */
										freeSet(&winnerSet);
										winnerSet=NULL;
										addClassifierToPointerSet(setp->classifier, &winnerSet);
										if(doGAErrorBasedSelect) {
											fitness = value;
										}
										else{
											fitness = setp->classifier->fitness/setp->classifier->numerosity;
										}
										size=1;
									}
								}
								break; /* go to next classifier since this one is already a winner*/
							}
						}
					}
				}
			}
		}
	}
	/* choose one of the equally best winners at random */
	size = irand(size);
	for(setp=winnerSet; setp!=NULL; setp=setp->next) {
		if(size==0){
			break;
		}
		size--;
	}
	winner = setp->classifier;
	freeSet(&winnerSet);
	return winner;
}

/**
 * Select a classifier for the discovery mechanism using roulette wheel selection 
 */
Classifier* selectClassifierUsingRWS(ClassifierSet *set, double fitsum){
	ClassifierSet *setp;
	double choicep;  

	choicep=drand()*fitsum;
	setp=set;
	fitsum=setp->classifier->fitness;
	while(choicep>fitsum){
		setp=setp->next;
		fitsum+=setp->classifier->fitness;
	}

	return setp->classifier;
}

// ########################## crossover and mutation ########################################

bool crossover(Classifier **cl, int crossoverType){ // Determines if crossover is applied and calls then the selected crossover type. 
	bool crossed = false;
	if(drand()<pX){
		if(crossoverType == 0){
			 crossed = uniformCrossover(cl);
		}
		else if(crossoverType == 1){
			crossed = onePointCrossover(cl);
		}
		else{
			crossed = twoPointCrossover(cl);
		}
		crossoverStateMachines(cl[0]->smAction,cl[1]->smAction);
	}
	return crossed;
}

bool uniformCrossover(Classifier **cl){ // Crosses the two received classifiers using uniform crossover.
	char help;
	bool crossed = false;
	for(int i=0; i<condLength; i++){
		if(drand() < 0.5){
			crossed = true;
			help = cl[0]->condition[i];
			cl[0]->condition[i] = cl[1]->condition[i];
			cl[1]->condition[i] = help;
		}
	}
	return crossed;
}

bool onePointCrossover(Classifier **cl){ // Crosses the two received classifiers using one-point crossover.
	char help;
	int sep = irand(condLength);
	for(int i=0; i<=sep; i++){
		help=cl[0]->condition[i];
		cl[0]->condition[i]=cl[1]->condition[i];
		cl[1]->condition[i]=help;
	}
	return true;
}

bool twoPointCrossover(Classifier **cl){ // Crosses the two received classifiers using two-point crossover.
	char help;
	int sep1 = irand(condLength);
	int sep2 = irand(condLength);
	if(sep1>sep2){
		int help=sep1;
		sep1=sep2;
		sep2=help;
	}
	for(int i=sep1; i<=sep2; i++){
		help=cl[0]->condition[i];
		cl[0]->condition[i]=cl[1]->condition[i];
		cl[1]->condition[i]=help;
	}
	return true;
}

/**
 * Apply mutation to classifier 'clfr'.
 * If niche mutation is applied, 'state' is considered to constrain mutation. 
 * returns if the condition was changed.
 */
void mutation(Classifier *clfr, char state[]){
	if(mutationType == 0){
		applyNicheMutation(clfr,state);
	}
	else{
		applyGeneralMutation(clfr,state);
	}
	mutateAction(clfr);
}
/**
 * Mutates the condition of the classifier. If one allele is mutated depends on the constant pM.
 * This mutation is a niche mutation. It assures that the resulting classifier still matches the current situation.
 */
void applyNicheMutation(Classifier *clfr, char state[]){
	for(int i=0; i<condLength; i++){
	   if(drand()<pM){
			if(clfr->condition[i]==dontcare){
				clfr->condition[i]=state[i];
			}
			else{
				clfr->condition[i]=dontcare;
			}
		}
	}
}
/**
 * Mutates the condition of the classifier. If one allele is mutated depends on the constant pM.
 * This mutation is a general mutation. 
 */
void applyGeneralMutation(Classifier *clfr, char state[]){
	for(int i=0; i<condLength; i++){
	    if(drand()<pM){
			if(clfr->condition[i]==dontcare){
				clfr->condition[i]= (drand() < 0.5)? '0' : '1';
			}
			else{
				clfr->condition[i]=dontcare;
			}
		}
	}
}
void mutateAction(Classifier *clfr){ //Mutates the action of the classifier.
	mutateStateMachine(clfr->smAction);
}

// ###################### offspring insertion #################################

/**
 * Insert a discovered classifier into the population and respects the population size.
 */
void insertDiscoveredClassifier(Classifier **cl, Classifier **parents, ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int len){
	Classifier *killedp;
	len+=2;
	if(doGASubsumption){
		subsumeClassifier(cl[0],parents,*set,pop);
		subsumeClassifier(cl[1],parents,*set,pop);
	}
	else{
		addClassifierToSet(cl[0],pop);
		addClassifierToSet(cl[1],pop);
	}
  
	while(len > maxPopSize) {
		len--;
		killedp=deleteStochClassifier(pop);
    
		/* record the deleted classifier to update other sets */
		if(killedp!=NULL) {
			addClassifierToPointerSet(killedp,killset);
			/* update the set */
			updateSet(set, *killset);
		}
	}
}

// ################################ subsumption deletion #################################

/**
 * Action set subsumption as described in the algorithmic describtion of XCS 
 */
void doActionSetSubsumption(ClassifierSet **aset, ClassifierSet **pop, ClassifierSet **killset){
	Classifier *subsumer=NULL;
	ClassifierSet *setp, *setpl;
  
	/* Find the most general subsumer */
	for(setp=*aset; setp!=NULL; setp=setp->next) {
		if(isSubsumer(setp->classifier)){
			if(subsumer==NULL || isMoreGeneral_AS(setp->classifier, subsumer)) { 
			//if(subsumer==NULL || isMoreGeneral(setp->classifier->condition, subsumer->condition)) {
				subsumer = setp->classifier;
			}
		}
	}

	/* If a subsumer was found, subsume all classifiers that are more specific. */
	if(subsumer!=NULL) {
		for(setp=*aset, setpl=*aset; setp!=NULL; setp=setp->next) {
			while(isMoreGeneral_AS(subsumer, setp->classifier)) {
			//while(isMoreGeneral(subsumer->condition, setp->classifier->condition)) {
				subsumer->numerosity += setp->classifier->numerosity;
				if(setpl==setp) {
					*aset=setp->next;
					deleteClassifierPointerFromSet(pop,setp->classifier);
					freeClassifier(setp->classifier);
					addClassifierToPointerSet(setp->classifier,killset);
					free(setp);
					setp=*aset;
					setpl=*aset;
				}
				else{
					setpl->next=setp->next;
					deleteClassifierPointerFromSet(pop,setp->classifier);
					freeClassifier(setp->classifier);
					addClassifierToPointerSet(setp->classifier,killset);
					free(setp);
					setp=setpl;
				}
			}
			setpl=setp;
		}
	}
}

/**
 * Tries to subsume the parents.
 */
void subsumeClassifier(Classifier *cl, Classifier **parents, ClassifierSet *locset, ClassifierSet **pop){
	int i;
	for(i=0; i<2; i++) {
		if(parents[i]!=NULL && subsumes(parents[i],cl)){
			parents[i]->numerosity++;
			freeClassifier(cl);
			return;
		}
	}
  	if(subsumeClassifierToSet(cl,locset)){
		return;
	}
	addClassifierToSet(cl,pop);
}

/**
 * Try to subsume in the specified set. 
 */
bool subsumeClassifierToSet(Classifier *cl, ClassifierSet *set){
	ClassifierSet * setp;
	Classifier *subCl[maxPopSize];
	int numSub=0;
  
	for(setp=set; setp!=NULL; setp=setp->next) {
		if(subsumes(setp->classifier,cl)) {
			subCl[numSub]=setp->classifier;
			numSub++;
		}
	}
	/* if there were classifiers found to subsume, then choose randomly one and subsume */
	if(numSub>0) {
		numSub = irand(numSub);
		subCl[numSub]->numerosity++;
		freeClassifier(cl);
		return true;
	}
	return false;
}

bool subsumes(Classifier *cl1, Classifier * cl2){ // check if classifier cl1 subsumes cl2 
	return isSameAction(cl1->smAction,cl2->smAction) && isSubsumer(cl1) && isMoreGeneral(cl1->condition,cl2->condition);
}

bool isSubsumer(Classifier *cl){
  return cl->experience > theta_sub && cl->predictionError <= epsilon_0;
}

bool isMoreGeneral_AS(Classifier *cl1, Classifier * cl2){ // check if classifier cl1 is more general than classifier cl2
	if(isSameAction(cl1->smAction,cl2->smAction) && isMoreGeneral(cl1->condition,cl2->condition)){
		return true;
	}
	return false;
}
/**
 * Check if the first condition is more general than the second.
 * It is made sure that the classifier is indeed more general and not equally general 
 * as well as that the more specific classifier is completely included in the more general one (do not specify overlapping regions).
 */
bool isMoreGeneral(char first[], char second[]){
	bool ret = false;
	for(int i=0; i<condLength; i++){
		if(first[i] != dontcare && first[i] != second[i]){
			return false;
		}
		else if(first[i] !=  second[i]){
			ret = true;
		}
	}
	return ret;
}

// ###################### adding classifiers to a set ###################################


/**
 * Adds only the pointers to the pointerset, ensures that no pointer is added twice,
 * returns if the pointer was added 
 */
bool addClassifierToPointerSet(Classifier *cl, ClassifierSet **pointerset){
	ClassifierSet *setp;
  	for(setp=*pointerset; setp!=NULL; setp=setp->next) {
		if(setp->classifier == cl){ // classifier is already in Set
			return false;
		}
	}
	// add the classifier, as it is not already in the pointerset
	assert((setp=( struct ClassifierSet*)calloc(1,sizeof(ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*pointerset;
	*pointerset=setp;
	return true;
}

// adds the classifier cl to the population, makes sure that the same classifier does not exist yet. 
bool addClassifierToSet(Classifier *cl, ClassifierSet **clSet){
	ClassifierSet *setp;
  	// Check if classifier exists already. If so, just increase the numerosity and free the space of the new classifier
	for(setp=*clSet; setp!=NULL; setp=setp->next) {
		if( equals(setp->classifier,cl) ){
			setp->classifier->numerosity++;
			freeClassifier(cl);
			return true;
		}
	}
	// classifier does not exist yet -> add new classifier 
	assert((setp=( struct ClassifierSet*)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*clSet;
	*clSet=setp;
	return false;
}

// adds the new Clasifier cl to the ClassifierSet 'clSet'. 
void addNewClassifierToSet(Classifier *cl, ClassifierSet **clSet){
	ClassifierSet *setp;
	assert((setp=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*clSet;
	*clSet=setp;
}

bool equals(Classifier *clfr1, Classifier *clfr2){ //Returns if the two classifiers are identical in condition and action.
	if( isSameCondition(clfr1->condition,clfr2->condition) && isSameAction(clfr1->smAction,clfr2->smAction) ){
			return true;
	}
	return false;
}
bool isSameCondition(char cond1[], char cond2[]){
	for(int i=0; i<condLength; i++){
		if(cond1[i] != cond2[i]){
			return false;
		}
	}
	return true;
}

// ############################## deletion ############################################
/**
 * Deletes one classifier in the population.
 * The classifier that will be deleted is chosen by roulette wheel selection
 * considering the deletion vote. Returns position of the macro-classifier which got decreased by one micro-classifier.
 **/
Classifier* deleteStochClassifier(ClassifierSet **pop){
	ClassifierSet *setp,*setpl;
	Classifier *killedp=NULL;
	double sum=0.0, choicep, meanf=0.0;
	int size=0;

	/* get the sum of the fitness and the numerosity */
	for(setp=*pop; setp!=NULL; setp=setp->next){
		meanf+=setp->classifier->fitness;
		size+=setp->classifier->numerosity;
	}
	meanf/=(double)size;

	/* get the delete proportion, which depends on the average fitness */
	for(setp=*pop; setp!=NULL; setp=setp->next) {
		sum += getDelProp(setp->classifier,meanf);
	}

	/* choose the classifier that will be deleted */
	choicep = drand()*sum;

	/* look for the classifier */
	setp=*pop;
	setpl=*pop;
	sum = getDelProp(setp->classifier,meanf);
	while(sum < choicep) {
		setpl=setp;
		setp=setp->next;
		sum += getDelProp(setp->classifier,meanf);
	}

	/* delete the classifier */
	killedp=deleteTypeOfClassifier(setp, setpl, pop);

	/* return the pointer to the deleted classifier, to be able to update other sets */
	return killedp;
}
double getDelProp(Classifier *clfr, double meanFitness){ //Returns the vote for deletion of the classifier.
	if(clfr->fitness/(double)clfr->numerosity >= delta*meanFitness || clfr->experience < theta_del){
		return (double)(clfr->actionSetSize*clfr->numerosity);
	}
	else{
		return (double)clfr->actionSetSize*(double)clfr->numerosity*meanFitness / (clfr->fitness/(double)clfr->numerosity);
	}
}
/**
 * Deletes the classifier setp from the population pop, setpl points to the classifier that is before setp in the list
 */
Classifier* deleteTypeOfClassifier(ClassifierSet *setp, ClassifierSet *setpl, ClassifierSet **pop){
	Classifier *killedp=NULL;

	/* setp must point to some classifier! */
	assert(setp!=NULL);

	if(setp->classifier->numerosity>1) {
		/* if the numerosity is greater than one -> just decrease it */
		setp->classifier->numerosity--;
	}
	else{
		/* if not, delete it and record it in killedp */
		if(setp==setpl) {
			*pop=setp->next;
		}
		else{
			setpl->next=setp->next;
		}
		killedp=setp->classifier;
		freeClassifier(setp->classifier);
		free(setp);
	}
	/* return a pointer ot a deleted classifier (NULL if the numerosity was just decreased) */
	return killedp;
}
/** 
 * Check if the classifier pointers that are in killset are in uset - delete the pointers,
 * if they are inside. Note that the classifiers in killset are already deleted, so do not 
 * read their values or try to delete them again here!
 */
bool updateSet(ClassifierSet **uset, ClassifierSet *killset){
	ClassifierSet *setp,*setpl,*killp,*usetp;
	bool updated = true;
  
	if(*uset==NULL || killset==NULL){ // if one of the sets is empty -> do not do anything
		return false;
	}
	// check all classifiers in uset
	setp=*uset;
	while(updated && setp!=NULL) {
		setp=*uset;
		setpl=*uset;
		updated = false;
		while(setp!=NULL && !updated){
			for(killp=killset; killp!=NULL; killp=killp->next) {
				if(killp->classifier == setp->classifier){
					// if killed classifier found, delete the struct classifier set in uset
					updated = true;
					if(setp==setpl) { // first entry in set 
						usetp=*uset;
						*uset=usetp->next;
						free(usetp);
						break;
					}
					else{
						setpl->next=setp->next;
						free(setp);
						setp = *uset;
						setpl= *uset;
						break;
					}
				}
			}
			if(updated){ // check the whole uset again, if one pointer was deleted 
				break;
			}
			setpl=setp;
			setp=setp->next;
		}
	}
    return updated;
}

/**
 * Deletes the classifier pointer from the specified set 
 * and returns if the pointer was found and deleted. 
 */
bool deleteClassifierPointerFromSet(ClassifierSet **set, Classifier *clp){
	ClassifierSet *setp, *setpl;
	for(setp=*set, setpl=*set; setp!=NULL; setp=setp->next){
		if(setp->classifier==clp){
			if(setpl==setp){
				*set=(*set)->next;
				free(setp);
			}
			else{
				setpl->next=setp->next;
				free(setp);
			}
			return true;
		}
		setpl=setp;
	}
	return false;
}

//############# concrete deletion of a classifier or a whole classifier set ############

/**
 * Frees only the complete ClassifierSet (not the Classifiers itself)! 
 */
void freeSet(ClassifierSet **cls){
	ClassifierSet *clp;
  	while(*cls!=NULL){
		clp=(*cls)->next;
		free(*cls);
		*cls=clp;
	}
}

/**
 * Frees the complete ClassifierSet with the corresponding Classifiers. 
 */
void freeClassifierSet(ClassifierSet **cls){
	ClassifierSet *clp;
	while(*cls!=NULL){
		freeClassifier((*cls)->classifier);
		clp=(*cls)->next;
		free(*cls);
		*cls=clp;
    }
}

/**
 * Frees one classifier. 
 */
void freeClassifier(Classifier *cl){
	free(cl);
}

// ############################### output operations ####################################

/**
 * print the classifiers in a ClassifierSet 
 */
void printClassifierSet(ClassifierSet *head){
	for(; head!=NULL; head=head->next){
		printClassifier(head->classifier);
	}
	printf("\n\n");
	
}

/**
 * print the classifier in a ClassifierSet to the file fp 
 */
void fprintClassifierSet(FILE *fp, ClassifierSet *head){
	for(; head!=NULL; head=head->next){
		fprintClassifier(fp, head->classifier);
	}
	fwrite("\n\n",strlen("\n\n"),1,fp);
}

/**
 * print a single classifier 
 */
void printClassifier(Classifier *clfr){
	for(int i=0; i<condLength; i++){
		printf("%c",clfr->condition[i]);
	}
	printAction(clfr->smAction);
	printf("\nNumerosity: %d ",clfr->numerosity);
	printf("Accuracy: %f ",clfr->accuracy);
	printf("Fitness: %f ",clfr->fitness);
	printf("Prediction_Error: %f ",clfr->predictionError);
	printf("Prediction: %f ",clfr->prediction);
	printf("Experience: %d ",clfr->experience);
	printf("Action_Set_Size: %f\n\n",clfr->actionSetSize);
}

/**
 * print a single classifier to the file fp 
 */
void fprintClassifier(FILE *fp, Classifier *classifier){
	char buf[100];
	for(int i=0; i<condLength; i++){
		sprintf(buf,"%c",classifier->condition[i]); fwrite(buf,strlen(buf),1,fp);
	}
	sprintf(buf,"\nAction:"); fwrite(buf,strlen(buf),1,fp);
	writeAction(classifier->smAction,fp);
	sprintf(buf,"Numerosity: %d ",classifier->numerosity); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Accuracy: %f ",classifier->accuracy); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Fitness: %f ",classifier->fitness); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Prediction_Error: %f ",classifier->predictionError); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Prediction: %f ",classifier->prediction); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Experience: %d ",classifier->experience); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"Action_Set_Size: %f ",classifier->actionSetSize); fwrite(buf,strlen(buf),1,fp);
	
	fwrite("\n",strlen("\n"),1,fp);

}

/*###################### sorting the classifier list ###################################*/

/**
 * Sort the classifier set cls in numerosity, prediction, fitness, or error order. 
 * type 0 = numerosity order, type 1 = prediction order, type 2 = fitness order, type 3=error order 
 */
ClassifierSet* sortClassifierSet(ClassifierSet **cls, int type){
	if(*cls == NULL){
		return NULL;
	}
	ClassifierSet *clsp, *maxcl, *newcls, *newclshead;
	double max;

	max=0.0;
	assert((newclshead=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	newcls=newclshead;
	do{
		max=-100000.0;
		/* check the classifier set cls for the next maximum -> already inserted classifier are referenced by the NULL pointer */
		for( clsp=*cls, maxcl=NULL; clsp!=NULL; clsp=clsp->next ) {
			if(clsp->classifier!=NULL && (maxcl==NULL || ((type==0 && clsp->classifier->numerosity>max) || (type==1 && clsp->classifier->prediction>max) || (type==2 && clsp->classifier->fitness/clsp->classifier->numerosity > max) || (type==3 && -1.0*(clsp->classifier->predictionError) > max)))) {
				if(type==0){
					max=clsp->classifier->numerosity;
				}
				else if (type==1){
					max=clsp->classifier->prediction;
				}
				else if (type==2){
					max=clsp->classifier->fitness/clsp->classifier->numerosity;
				}
				else if(type==3){
					max=-1.0*(clsp->classifier->predictionError);
				}
				maxcl=clsp;
			}
		}
		if(max>-100000.0) {
			assert((newcls->next=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
			newcls=newcls->next;
			newcls->next=NULL;
			newcls->classifier=maxcl->classifier;
			maxcl->classifier=NULL; // do not delete the classifier itself, as it will be present in the new, sorted classifier list
		}
	}while(max>-100000.0);
  
	// set the new ClassifierSet pointer and free the old stuff
	newcls=newclshead->next;
	free(newclshead);
	freeSet(cls);
	
	return newcls; // return the pointer to the new ClassifierSet
}


/*################################## Utilitiy ##########################################*/

/**
 * Get the absolute value of 'value'.
 */
double absoluteValue(double value){
	if(value < 0.0){
		return -1.0*value;
	}
	else{
		return value;
	}
}

// ################################# simplyfy #########################################

void simplifyPopulation(ClassifierSet **population){
	ClassifierSet *set,*setp, *killset = NULL;
	
	//consider only well experienced and accurate classifier rules
	for(set=*population,setp=*population ; set!=NULL; set=set->next){
		//printClassifier(set->classifier); printf("\n");
		while(set->classifier->experience <= 1.0/beta || set->classifier->predictionError > epsilon_0){
			//printClassifier(set->classifier);	printf("\n");
			if(setp==set){
				*population=set->next;
				deleteClassifierPointerFromSet(population,set->classifier);
				freeClassifier(set->classifier);
				addClassifierToPointerSet(set->classifier,&killset);
				free(set);
				set=*population;
				setp=*population;
			}
			else{
				setp->next=set->next;
				deleteClassifierPointerFromSet(population,set->classifier);
				freeClassifier(set->classifier);
				addClassifierToPointerSet(set->classifier,&killset);
				free(set);
				set=setp;
			}		
		}
		setp=set;
	}		
	freeSet(&killset);	

	for(set=*population,setp=*population ; set!=NULL; set=set->next){
		removeNonReachableStates(set->classifier->smAction);
	}
}

//condense the population of classifiers by deleting classifier rules with "numerosity < limit"
void condensePopulation(ClassifierSet **population){ //population sorted according to numerosity
	int finalPopSize=0, maxNumerosityDifference=0, lowBoundaryNumerosity=0, highBoundaryNumerosity=0;
	ClassifierSet *iterate, *boundary=NULL, *dummy;
		
	dummy = new ClassifierSet; // ending symbol
	dummy->classifier = new Classifier;
	dummy->classifier->numerosity = 0;
	dummy->next = NULL;
	for(iterate = *population; iterate->next!=NULL; iterate=iterate->next){
		;
	}
	iterate->next = dummy; // insert at the end
	
	for(iterate = *population; iterate->next!=NULL; iterate=iterate->next){
		if(iterate->classifier->numerosity - iterate->next->classifier->numerosity > maxNumerosityDifference){
			boundary = iterate;
			highBoundaryNumerosity = boundary->classifier->numerosity;
			lowBoundaryNumerosity = boundary->next->classifier->numerosity;
			maxNumerosityDifference = highBoundaryNumerosity - lowBoundaryNumerosity;
		}
	}

	freeClassifierSet(&(boundary->next));
	boundary->next = NULL;
	
	printf("\nLBN: %d, HBN: %d\n",lowBoundaryNumerosity, highBoundaryNumerosity);
	
	for(iterate=*population; iterate!=NULL; iterate=iterate->next){
		finalPopSize++;
	}
	printf("\nNumber of classifiers in final population: %d\n",finalPopSize);
}
