#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <string.h>
#include <math.h>
#include "xcsMacros.h"
#include "time.h"
#include "configuration.h"
#include "classifier.h"
#include "env.h"
#include "xcs.h"

void header() {
  time_t t;
  char hostName[1024]; //[MAXHOSTNAMELEN];
  time(&t);
  gethostname(hostName,sizeof(hostName));
  printf("%s\nSeed: %ld %s",hostName,getSeed(),ctime(&t));
}//end header

void Exit(FILE *fp) {
    printf("\nShutting down...\n");
	elapsedTime();
   	header();
	printf("Elapsed Time: ");
	elapsed(fp);
	printf(" Secs\n");
}//end exit

/*##########---- Output ----##########*/
/**
 * Writes the performance of the XCS to the specified file.
 * The function writes time performance systemError actualPopulationSizeInMacroClassifiers.
 * Performance and system error are averaged over the last fifty trials.
 *
 * @param performance The performance in the last fifty exploration trials.
 * @param sysError The system error in the last fifty exploration trials.
 * @param exploreProbC The number of exploration trials executed so far.
 */
void writePerformance(ClassifierSet *population, int performance[], double sysError[], int exploreProbC) {
	char buf[100];
	double perf=0.0, serr=0.0;
	int setSize;
	
	for(int i=0; i<testFrequency; i++){
		perf+=performance[i];
        serr+=sysError[i];
	}
	
	perf/=testFrequency;
    serr/=testFrequency;
	setSize = getSetSize(population);

    sprintf(buf,"%d ",exploreProbC); fwrite(buf,strlen(buf),1,filePerformance);
	sprintf(buf,"%f ",perf); fwrite(buf,strlen(buf),1,filePerformance);
	sprintf(buf,"%f ",serr); fwrite(buf,strlen(buf),1,filePerformance);
	sprintf(buf,"%d ",setSize); fwrite(buf,strlen(buf),1,filePerformance);
	fwrite("\n",strlen("\n"),1,filePerformance);

	//int numerositySum = getNumerositySum(population); printf("%d %f %f %d %d\n",exploreProbC,perf,serr,setSize,numerositySum); // to check numerosity sum
	//printf("%d %f %f %d\n",exploreProbC,perf,serr,setSize);
}
/**************************** Single Step Experiments ***************************/
void doOneSingleStepProblemExplore(ClassifierSet **population, char state[], int counter){// Executes one main learning loop for a single step problem.
	bool wasCorrect = false;
	ClassifierSet *mset, *aset, *killset=NULL;

	mset = getMatchSet(population,&killset,state,counter);
	freeSet(&killset);

	getPredictionArray(mset,state);
	int actionWinner = randomActionWinner();
	aset = getActionSet(actionWinner,mset,state);
	double reward = executeAction(actionWinner,state,wasCorrect);

	updateActionSet(&aset,0.0,reward,population,&killset);
	freeSet(&killset);

	discoveryComponent(&aset,population,&killset,counter,state);
	freeSet(&killset);

	freeSet(&mset);
	freeSet(&aset);
}
void doOneSingleStepProblemExploit(ClassifierSet **population, char state[], int counter, int correct[], double sysError[]){ //Executes one main performance evaluation loop for a single step problem.
	bool wasCorrect = false;
	ClassifierSet *mset, *killset=NULL;

	mset = getMatchSet(population,&killset,state,counter);
	freeSet(&killset);

	getPredictionArray(mset,state);
	int actionWinner = bestActionWinner();
	double reward = executeAction(actionWinner,state,wasCorrect);

	if(wasCorrect){
		correct[counter%testFrequency]=1;
	}
	else{
		correct[counter%testFrequency]=0;
	}
    sysError[counter%testFrequency] = absoluteValue(reward - getBestValue());

	freeSet(&mset);
}
void doOneSingleStepExperiment(ClassifierSet **population){ //Executes one single-step experiment monitoring the performance.
	int explore=0;
    int correct[testFrequency];
    double sysError[testFrequency];
	char state[condLength];
	for(int exploreProbC=0; exploreProbC <= maxProblems; exploreProbC+=explore){
		explore = (explore+1)%2;
		resetState(state);
		if(explore==1){
			doOneSingleStepProblemExplore(population,state,exploreProbC);
        }
		else{
            doOneSingleStepProblemExploit(population,state,exploreProbC, correct, sysError);
        }
		if(exploreProbC%testFrequency==0 && explore==0 && exploreProbC>0){
			writePerformance(*population,correct,sysError,exploreProbC);
        }
	}
}
void resetUsedInTestingFlag(ClassifierSet **population){
	for(ClassifierSet *set=*population; set!=NULL; set=set->next){
        set->classifier->usedInTesting = false;
    }
}
int getSize(ClassifierSet **aset){
	int size = 0;
	for(ClassifierSet *set=*aset; set!=NULL; set=set->next){
		if(set->classifier->usedInTesting == false){
			set->classifier->usedInTesting = true;
			size++;
		}
	}
	return size;
}
ClassifierSet* getMatchSet2(ClassifierSet **population, ClassifierSet **killset, char state[]){
	ClassifierSet *mset=NULL, *poppointer;
	for(poppointer= *population; poppointer!=NULL; poppointer=poppointer->next){
		if(isConditionMatched(poppointer->classifier->condition,state)){
			addNewClassifierToSet(poppointer->classifier, &mset); // add matching classifier to the matchset
		}
	}
	return mset;
}
void startXCS(){
    startTimer();
	ClassifierSet *population;
	initializePopulation(&population);
	printf("\nIt is in progress! Please wait ....\n");
	doOneSingleStepExperiment(&population);
	population = sortClassifierSet(&population,0); // sort according to 'numerosity'
	//printClassifierSet(population);
	fprintClassifierSet(fileWholeClassifierPopulation,population);
	
	//simplifyPopulation(&population);
	//population = sortClassifierSet(&population,0); // sort according to 'numerosity'
	//fprintClassifierSet(fileSimplifiedClassifierPopulation,population);
	//
	//condensePopulation(&population);
	//fprintClassifierSet(fileCondensedClassifierPopulation,population);

	//// ...... START number of classifiers used in the test (for majority-on) .... 

	//resetUsedInTestingFlag(&population);
 //   
	//char state[condLength]; 
	//int numTests = pow(2,condLength);
	//int asetSize = 0;
	//for(int n=0; n<numTests; n++){
	//	int d, count=0;
	//	for (int c=condLength-1; c>=0; c--){
	//		d = n >> c;
	//	    if(d&1){
	//			state[count] = '1';
	//		}
	//		else{
	//			state[count] = '0';
	//		}
	//		count++;
	//	}
	//	/*printf("\nCONDITION: ");
	//	for(int i=0; i<condLength; i++){
	//		printf("%c ",state[i]);
	//	}
	//	printf("\n\n");*/

	//	bool wasCorrect = false;
	//	ClassifierSet *mset, *aset, *killset=NULL;

	//	mset = getMatchSet2(&population,&killset,state);
	//	freeSet(&killset);

	//	getPredictionArray(mset,state);
	//	int actionWinner = bestActionWinner();
	//	aset = getActionSet(actionWinner,mset,state);

	//	asetSize += getSize(&aset);
	//	//printf("asetSize: %d\n",asetSize);
	//	double reward = executeAction(actionWinner,state,wasCorrect);

	//	if(!wasCorrect){
	//		printf("NOT CORRECT!\n");
	//		exit(0);
	//	}
	//    

	//	freeSet(&mset);
	//	freeSet(&aset);

 //   }
	//printf("asetSize: %d\n",asetSize);
	//// ....... END number of classifiers used in the test .... 

	freeClassifierSet(&population); // free population for this experiment
	
}//end startXCS

int main(int argc, char **argv){

	char outputFile1[] = "output.txt";
	filePerformance=fopen(outputFile1, "w"); //open outputFile1 in writing mode
	if (filePerformance == NULL) {
		printf("Error in opening a file.. %s", outputFile1);
		exit(1);
	}

	char outputFile2[] = "Rules-simplified.txt";
	fileSimplifiedClassifierPopulation=fopen(outputFile2, "w"); //open outputFile2 in writing mode
	if (fileSimplifiedClassifierPopulation == NULL) {
		printf("Error in opening a file.. %s", outputFile2);
		exit(1);
	}

	char outputFile3[] = "Rules-whole.txt";
	fileWholeClassifierPopulation=fopen(outputFile3, "w"); //open outputFile2 in writing mode
	if (fileWholeClassifierPopulation == NULL) {
		printf("Error in opening a file.. %s", outputFile3);
		exit(1);
	}

	char outputFile4[] = "Rules-condensed.txt";
	fileCondensedClassifierPopulation=fopen(outputFile4, "w"); //open outputFile2 in writing mode
	if (fileCondensedClassifierPopulation == NULL) {
		printf("Error in opening a file.. %s", outputFile4);
		exit(1);
	}

	for(int j=0; j<30; j++){

		//setSeed(1+(unsigned)time(NULL)%10000);
		setSeed(seeds[j]);

		printf("Experiment: %d\n",j);

		startXCS();

		printf("Done\n");
		Exit(filePerformance);
	}

	fclose(filePerformance);//close outputFile
	fclose(fileSimplifiedClassifierPopulation);//close
	fclose(fileWholeClassifierPopulation);//close
	fclose(fileCondensedClassifierPopulation);//close
	exit(0);
}//end main
