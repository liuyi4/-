double executeAction(int action, char state[], bool &isCorrect);
double executeCarryAction(int action, char state[], bool &isCorrect);
double executeSumAction(int action, char state[], bool &isCorrect);
double executeEvenParityAction(int action, char state[], bool &isCorrect);
double executeMultiplexerAction(int action, char state[], bool &isCorrect);
double executeHiddenEvenParityAction(int action, char state[], bool &isCorrect);
double executeHiddenOddParityAction(int action, char state[], bool &isCorrect);
double executeCountOnesAction(int action, char state[], bool &isCorrect);
void resetState(char state[]);
