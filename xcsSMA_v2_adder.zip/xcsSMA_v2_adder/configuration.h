enum Environment{
    carry, sum, evenParity, multiplexer, hiddenEvenParity, hiddenOddParity, countOnes
};

const Environment env = carry;

const int condLength = 12; // 6, 11, 20, and 37 for mux; 20 for others

// multiplexer environment settings
const int posBits = 2;//2, 3, 4, and 5 for 6-, 11-, 20-, 37-bits MUX respectively

// countOnes, hiddenEvenParity and hiddenOddParity environments settings
const int numRelevantBits = 7; // 7 for countOnes and 5 for both hiddenEvenParity and hiddenOddParity
const int posRelevantBits[] = {1,5,8,12,15,17,19}; //{1,5,10,17,19};

const int maxPopSize = 9*1000; //Specifies the maximal number of micro-classifiers in the population. 
const int maxProblems = 20*100*1000; //training set 
const int maxPayoff = 1000;

const int numActions = 2; //0 or 1 

const int smMaxStates = (condLength > 10)?10:condLength;
const int smMaxTransitions = 4;
const int stateLength = 7; // (1 for stateNumber + 1 for stateValue + 1 for isStateActive + smMaxTransitions)
const int smMaxLength = smMaxStates * stateLength;

struct State{
	int stateNumber;
	int stateValue;
	int isStateActive; // 0 = false, 1 = true
	int stateTransitions[smMaxTransitions];
};

struct StateMachine{
	State smStates[smMaxStates];
	int smNumberOfStates;
	int smStartStateNumber;
	int smLength; // smNumberOfStates * stateLength
	
};

struct Classifier{
	char condition[condLength];
	StateMachine smAction;
	double prediction;
	double predictionError;
	double accuracy;
	double fitness;
	int numerosity;
	int experience;
	double actionSetSize;
	int timeStamp;
	bool actionConsistency;
	int actionValue;
	bool usedInTesting;
};
struct ClassifierSet{
	Classifier *classifier;
	ClassifierSet *next;
};
