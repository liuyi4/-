#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "xcsMacros.h"
#include "configuration.h"
#include "env.h"

void resetState(char state[]){ //Generates a new random problem instance.
	for(int i=0; i<condLength; i++){
		if(drand()<0.5){
			state[i]='0';
		}
		else{
			state[i]='1';
		}
	}
}

double executeAction(int action, char state[], bool &isCorrect){ // Executes the action and determines the reward.
    switch(env){
		case carry:
			return executeCarryAction(action,state,isCorrect);
		case sum:
			return executeSumAction(action,state,isCorrect);
		case evenParity:
			return executeEvenParityAction(action,state,isCorrect);
        case multiplexer:
            return executeMultiplexerAction(action,state,isCorrect);
        case hiddenEvenParity:
            return executeHiddenEvenParityAction(action,state,isCorrect);
        case hiddenOddParity:
            return executeHiddenOddParityAction(action,state,isCorrect);
        case countOnes:
            return executeCountOnesAction(action,state,isCorrect);
        default:
            printf("\nEnvironment not supported!\n");
            exit(0);
    }
}

double executeCarryAction(int action, char state[], bool &isCorrect){
	int ret=0, actualAction = 0;
	int carry = 0, halfCondLength = condLength/2;
	for(int i=halfCondLength-1; i>=0; i--){
		carry = ((state[i] - '0') + (state[i+halfCondLength] - '0') + carry)/2;
	}
	actualAction = carry;

	////int ret=0;
	////int actualAction = 0;
	//unsigned long num1=0, num2=0, sum;
	//int j =0;
	//for(int i=condLength/2 - 1; i>=0; i--){
	//	num1 += (state[i]-'0')*pow(2,j);
	//	j++;
	//}
	//j = 0; // IMPORTANT to set j equal to ZERO
	//for(int i=condLength - 1; i>=condLength/2; i--){
	//	num2 += (state[i]-'0')*pow(2,j);
	//	j++;
	//}
	//sum = num1 + num2;
	////unsigned long ss = (unsigned long)(pow(2.0,condLength/2));
	//////printf("\nss: %lu\n",ss);
	////if (sum >= ss /*pow(2,condLength/2)*/){
	////	actualAction = 1;
	////}
	////
	//printf("\nCondition: ");
	//for(int i=0; i<condLength; i++){
	//	printf("%c ",state[i]);
	//}
	//printf("\nNum1: %lu, Num2: %lu, Sum: %lu, Actual_Action: %d, Action: %d",num1,num2,sum,actualAction,action); //printf("\nss: %lu\n",ss);
	//
	if(action == actualAction){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeSumAction(int action, char state[], bool &isCorrect){
	return 0.0;
}

double executeEvenParityAction(int action, char state[], bool &isCorrect){ 
	int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<condLength; i++){
		if(state[i] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 0){
		actualAction = 1;
	}
	/*
	printf("\nstate: ");
	for(int i=0; i<condLength; i++){
		printf("%c ",state[i]);
	}
	*/
	if(action == actualAction){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeMultiplexerAction(int action, char state[], bool &isCorrect){
    int place=posBits;
	for(int i=0; i<posBits; i++){
	    if(state[i]=='1'){
			place += (int)pow(2.0, (double)(posBits-1-i));
	    }
	}
	int ret=0;
	if(action == state[place]-'0'){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeHiddenEvenParityAction(int action, char state[], bool &isCorrect){
    int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 0){
		actualAction = 1;
	}
	if(action == actualAction){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeHiddenOddParityAction(int action, char state[], bool &isCorrect){
    int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes%2 == 1){
		actualAction = 1;
	}
	if(action == actualAction){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;
}

double executeCountOnesAction(int action, char state[], bool &isCorrect){
	int ret=0;
	int actualAction = 0;
	int numOnes = 0;
	for(int i=0; i<numRelevantBits; i++){
		if(state[posRelevantBits[i]] == '1'){
			numOnes++;
		}
	}
	if (numOnes > numRelevantBits/2){
		actualAction = 1;
	}
	if(action == actualAction){
	    isCorrect=true;
	    ret = maxPayoff;
	}
	else{
	    isCorrect=false;
	    ret = 0;
	}
	return (double)ret;

}
