struct PredictionArray{
    float a;
    float p;
    float f;
};

void setInitialVariables(Classifier *clfr, float setSize, int time);
void initializePopulation(ClassifierSet **population);
int getNumerositySum(ClassifierSet *set);
int getSetSize(ClassifierSet *set);

ClassifierSet* getMatchSet(ClassifierSet **population, ClassifierSet **killset, float state[], int itTime);
bool isValidAction(float actionValue);
bool isConditionMatched(Interval clfrCond[], float cond[]);
Classifier* matchingCondAndValidAct(float state[], int setSize, int time);
void createMatchingCondition(Interval cond[], float state[]);
void createValidAction(Classifier *clfr, float state[]);
void createRandomAction(Classifier *clfr);

int getPredictionArray(ClassifierSet *ms, PredictionArray *pa, float state[]);
float getBestValue(PredictionArray *pa, int paSize);
float getPredictionValue(PredictionArray *pa, int paSize, float action);
float learningActionWinner(PredictionArray *pa, int paSize);
float randomActionWinner(PredictionArray *pa, int paSize);
float bestActionWinner(PredictionArray *pa, int paSize);
float rouletteActionWinner(PredictionArray *pa, int paSize);

ClassifierSet* getActionSet(float action, ClassifierSet *ms);
void updateActionSet(ClassifierSet **aset, float maxPrediction, float reward, ClassifierSet **pop, ClassifierSet **killset);
void updateFitness(ClassifierSet *aset);

void discoveryComponent(ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int itTime, float situation[]);
void getDiscoversSums(ClassifierSet *set, float *fitsum, int *setsum, int *gaitsum);
void setTimeStamps(ClassifierSet *set, int itTime);

void selectTwoClassifiers(Classifier **cl, Classifier **parents, ClassifierSet *set, float fitsum, int setsum);
Classifier* selectClassifierUsingTournamentSelection(ClassifierSet *set, int setsum, Classifier *notMe);
Classifier* selectClassifierUsingRWS(ClassifierSet *set, float fitsum);

void crossover(Classifier **cl, int crossoverType);
void uniformCrossover(Classifier **cl);
void onePointCrossover(Classifier **cl);
void twoPointCrossover(Classifier **cl);
void mixCrossover(Classifier **cl);
void mutation(Classifier *clfr, float state[]);
void applyNicheMutation(Classifier *clfr, float state[]);
void applyGeneralMutation(Classifier *clfr, float state[]);
void mutateAction(Classifier *clfr);
void validateCondition(Interval condition[]);

void insertDiscoveredClassifier(Classifier **cl, Classifier **parents, ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int len);

void doActionSetSubsumption(ClassifierSet **aset, ClassifierSet **pop, ClassifierSet **killset);
void subsumeClassifier(Classifier *cl, Classifier **parents, ClassifierSet *locset, ClassifierSet **pop);
bool subsumeClassifierToSet(Classifier *cl, ClassifierSet *set);
bool subsumes(Classifier *cl1, Classifier * cl2);
bool isSubsumer(Classifier *cl);
bool isMoreGeneral(Interval first[], Interval second[]);
bool isMoreGeneral_AS(Interval first[], Interval second[]);
bool isGeneralInterval(Interval one, Interval two);

bool addClassifierToPointerSet(Classifier *cl, ClassifierSet **pointerset);
bool addClassifierToSet(Classifier *cl, ClassifierSet **clSet);
void addNewClassifierToSet(Classifier *cl, ClassifierSet **clSet);
bool equals(Classifier *clfr1, Classifier *clfr2);
bool isSameCondition(Interval cond1[], Interval cond2[]);
bool isSameAction(Classifier *clfr1, Classifier *clfr2);

Classifier* deleteStochClassifier(ClassifierSet **pop);
float getDelProp(Classifier *clfr, float meanFitness);
Classifier* deleteTypeOfClassifier(ClassifierSet *setp, ClassifierSet *setpl, ClassifierSet **pop);
bool updateSet(ClassifierSet **uset, ClassifierSet *killset);
bool deleteClassifierPointerFromSet(ClassifierSet **set, Classifier *clp);

void freeSet(ClassifierSet **cls);
void freeClassifierSet(ClassifierSet **cls);
void freeClassifier(Classifier *cl);

void printClassifierSet(ClassifierSet *head);
void fprintClassifierSet(FILE *fp, ClassifierSet *head);
void printClassifier(Classifier *clfr);
void fprintClassifier(FILE *fp, Classifier *classifier);

ClassifierSet* sortClassifierSet(ClassifierSet **cls, int type);

void condensePopulation(ClassifierSet **population);
void simplifyPopulation(ClassifierSet **population);
bool qualifyForSimplification(Classifier *clfr1, Classifier *clfr2);

float absoluteValue(float value);
float min(float n1, float n2);
float max(float n1, float n2);
void bestAction(ClassifierSet *population);
