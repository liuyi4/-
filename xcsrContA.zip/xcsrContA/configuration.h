const float lowerActionBound = 0.0;
const float upperActionBound = 1.0;

const int condLength = 1;
const float lowerBound[condLength] = {0.0};
const float upperBound[condLength] = {1.0};

const int maxPayoff = 1;

const int maxPopSize = 2*1000; //Specifies the maximal number of micro-classifiers in the population.
const int maxProblems = 1*100*1000; //training examples

const int cfMaxDepth = 2;
const int cfMinDepth = 0;
const int cfMaxLength = 8;//8 16 pow(2,adfMaxDepth+1); //allow for endstop OPNOP
const int cfMaxArity = 2;
const int cfMaxStack = (cfMaxArity-1)*(cfMaxDepth-1)+2;
const int cfMaxMuteDepth = 1;

typedef float opType;
const int opSize = sizeof(opType);

const opType OPNOP = 100; //to be used as ending symbol

const opType OPADD = 101;
const opType OPSUB = 102;
const opType OPMUL = 103;
const opType OPDIV = 104;
const opType OPLN = 105;

const opType functionCodes[] = {OPADD,OPSUB,OPMUL,OPDIV,OPLN};

const opType firstfunc = OPADD;
const int totalFunctions = 4;

struct Interval{
    float lower;
    float upper;
};


struct Classifier{
	Interval condition[condLength];
	opType cfAction[cfMaxLength];
	float prediction;
	float predictionError;
	float accuracy;
	float fitness;
	int numerosity;
	int experience;
	float actionSetSize;
	int timeStamp;
	float actionValue;
};
struct ClassifierSet{
	Classifier *classifier;
	ClassifierSet *next;
};
