#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <fstream>
#include "xcsMacros.h"
#include "codeFragment.h"
#include "classifier.h"

void setInitialVariables(Classifier *clfr, float setSize, int time){
	clfr->prediction = predictionIni;
	clfr->predictionError = predictionErrorIni;
	clfr->accuracy = fitnessIni;
	clfr->fitness = fitnessIni;
	clfr->numerosity = 1;
	clfr->experience = 0;
	clfr->actionSetSize = setSize;
	clfr->timeStamp = time;
}

void initializePopulation(ClassifierSet **population){
	*population = NULL;
}

int getNumerositySum(ClassifierSet *set){
    int sum = 0;
    for(; set!=NULL; set=set->next){
        sum += set->classifier->numerosity;
    }
    return sum;
}

int getSetSize(ClassifierSet *set){
    int size = 0;
    for(; set!=NULL; set=set->next){
        size++;
    }
    return size;
}

// ####################### match set operations ##########################################

/**
 * Gets the match-set that matches state from pop.
 * If a classifier was deleted, record its address in killset to be
 * able to update former actionsets.
 * The iteration time 'itTime' is used when creating a new classifier
 * due to covering. Covering occurs when not all possible actions are
 * present in the match set. Thus, it is made sure that all actions
 * are present in the match set.
 */
ClassifierSet* getMatchSet(ClassifierSet **population, ClassifierSet **killset, float state[], int itTime){
	ClassifierSet *mset=NULL, *poppointer;
	Classifier *killedp, *coverClfr;
	int popSize=0, setSize=0;

	for(poppointer= *population; poppointer!=NULL; poppointer=poppointer->next){
		popSize += poppointer->classifier->numerosity; // calculate the population size
		if(isConditionMatched(poppointer->classifier->condition,state)){
			poppointer->classifier->actionValue = getActionValue(poppointer->classifier,state);
			if(isValidAction(poppointer->classifier->actionValue)){
			    addNewClassifierToSet(poppointer->classifier, &mset); // add matching classifier to the matchset
			    setSize+=poppointer->classifier->numerosity; // calculate size of the match set
			}
		}
	}

	while(mset==NULL){ // create a covering classifier with valid action, if match set is empty
		coverClfr = matchingCondAndValidAct(state,setSize+1,itTime);
		//printClassifier(coverClfr);
		addNewClassifierToSet(coverClfr,&mset);
		setSize++;
		addNewClassifierToSet(coverClfr,population);
		popSize++;


		/* Delete classifier if population is too big and record it in killset */
		while( popSize > maxPopSize ) {
			/* PL */
			killedp = deleteStochClassifier(population);
			if(killedp!=NULL) {
				deleteClassifierPointerFromSet(&mset, killedp);
  				addClassifierToPointerSet(killedp, killset);
			}
			popSize--;
		}
 	}
	assert(mset!=NULL);
	return mset; // return the match set
}

bool isValidAction(float actionValue){
    return (lowerActionBound<=actionValue && actionValue<=upperActionBound);
}

bool isConditionMatched(Interval clfrCond[], float cond[]){
	for(int i=0; i<condLength; i++){
		assert(clfrCond[i].lower <= clfrCond[i].upper);
		if(clfrCond[i].lower>cond[i] || clfrCond[i].upper<cond[i]){
			return false;
		}
	}
	return true;
}

Classifier* matchingCondAndValidAct(float state[], int setSize, int time){
	Classifier *clfr;
	assert((clfr=( struct Classifier*)calloc(1,sizeof(struct Classifier)))!=NULL); // get memory for the new classifier
	createMatchingCondition(clfr->condition,state);
	createValidAction(clfr,state);
	setInitialVariables(clfr,setSize,time);
	return clfr;
}
void createMatchingCondition(Interval cond[], float state[]){
	for(int i=0; i<condLength; i++){

		float temp = drand()*r_0;

		cond[i].lower = state[i] - temp;
		if(cond[i].lower < lowerBound[i]){
			cond[i].lower = lowerBound[i];
		}

		cond[i].upper = state[i] + temp;
		if(cond[i].upper > upperBound[i]){
			cond[i].upper = upperBound[i];
		}
	}
}
void createValidAction(Classifier *clfr, float state[]){
	float val;
	do{
		createRandomAction(clfr);
		val = getActionValue(clfr,state);
	}while(!isValidAction(val));
	clfr->actionValue = val;
}
void createRandomAction(Classifier *clfr){
	//ramped half-and-half, check end for sanity only
	createNewCF(clfr->cfAction);
	opType* end = randomProgram(clfr->cfAction,irand(2),cfMaxDepth,cfMinDepth);
	validateDepth(clfr->cfAction,end); //validate depth
}

// ######################### prediction array operations ############################################

int getPredictionArray(ClassifierSet *ms, PredictionArray pa[], float state[]){ //determines the prediction array out of the match set ms
	assert(ms!=NULL); // ms should never be NULL (because of covering)
	//printClassifierSet(ms);
	int paSize=0;
	//printf("\nB4\n");
	for(; ms!=NULL; ms=ms->next){
	    pa[paSize].a = ms->classifier->actionValue; //printf("\nA: %f  ",pa[paSize].a);
	    pa[paSize].p = ms->classifier->prediction*ms->classifier->fitness; //printf("P: %f  ",pa[paSize].p);
		pa[paSize].f = ms->classifier->fitness; //printf("F: %f  ",pa[paSize].f);
		paSize++;
	}
	
	for(int i=0; i<paSize-1; i++){
		for(int j=i+1; j<paSize; j++){

			if(pa[i].a == pa[j].a){
				pa[i].p += pa[j].p;
				pa[i].f += pa[j].f;

				for(int k=j; k<paSize-1; k++){// remove jth entry
				    pa[k] = pa[k+1];
				}
				paSize--;

				j--;
			}
		}
	}
	/*
	for(int i=0; i<paSize-1; i++){ //checking duplicate actions, if still any!
		for(int j=i+1; j<paSize; j++){
			if(pa[i].a == pa[j].a){
				printf("\nERROR in Duplicate Removal!\n");
				exit(0);
			}
		}
	}
	*/
	//printf("\nAfter\n");
	for(int i=0; i<paSize; i++){
		if(pa[i].f!=0.0){
			pa[i].p /= pa[i].f;
	    }
		else{
			pa[i].p=0.0;
	    }
	    //printf("\nA: %f  ",pa[i].a);
	    //printf("P: %f  ",pa[i].p);
		//printf("F: %f  ",pa[i].f);
	}

	return paSize;
}
float getBestValue(PredictionArray *pa, int paSize){ //Returns the highest value in the prediction array.
	float max = pa[0].p;
	for(int i=1; i<paSize; i++){
		if(max < pa[i].p){
			max = pa[i].p;
		}
	}
	return max;
}
float getPredictionValue(PredictionArray *pa, int paSize, float action){
	assert(lowerActionBound<=action && action<=upperActionBound);
	float val = 0.0;
	int i;
	for(i=0; i<paSize; i++){
	    if(pa[i].a == action){
		    val = pa[i].p;
			break;
		}
	}
	assert(i<paSize);
	return val;
}
float learningActionWinner(PredictionArray *pa, int paSize){
	if(drand()<exploreProb){
		return randomActionWinner(pa,paSize);
	}
	else{
		return bestActionWinner(pa,paSize);
	}
}
float randomActionWinner(PredictionArray *pa, int paSize){ //Selects an action randomly. The function assures that the chosen action is represented by at least one classifier in the prediction array.
	int ret=0;
	do{
	    ret = irand(paSize);
	}while(pa[ret].f==0.0);
	return pa[ret].a;
}
float bestActionWinner(PredictionArray *pa, int paSize){ //Selects the action in the prediction array with the best value.
	int ret=0;
	for(int i=1; i<paSize; i++){
		if(pa[ret].p < pa[i].p){
			ret=i;
		}
	}
	return pa[ret].a;
}
float rouletteActionWinner(PredictionArray *pa, int paSize){ //Selects an action in the prediction array by roulette wheel selection.
	float bidSum=0.0;
	int i;
	for(i=0; i<paSize; i++){
	    bidSum += pa[i].p;
	}
	bidSum *= drand();
	float bidC=0.0;
	for(i=0; bidC<bidSum; i++){
	    bidC += pa[i].p;
	}
	return pa[i].a;
}

// ######################## action set operations #########################################

ClassifierSet* getActionSet(float action, ClassifierSet *ms){ // constructs an action set out of the match set ms.
	ClassifierSet *aset=NULL;
	for(; ms!=NULL; ms=ms->next){
		if(action == ms->classifier->actionValue){
			addNewClassifierToSet(ms->classifier,&aset);
		}
	}
  	return aset;
}

/**
 * Updates all parameters in the action set.
 * Essentially, reinforcement Learning as well as the fitness evaluation takes place in this set.
 * Moreover, the prediction error and the action set size estimate is updated. Also,
 * action set subsumption takes place if selected. As in the algorithmic description, the fitness is updated
 * after prediction and prediction error. However, in order to be more conservative the prediction error is
 * updated before the prediction.
 * @param maxPrediction The maximum prediction value in the successive prediction array (should be set to zero in single step environments).
 * @param reward The actual resulting reward after the execution of an action.
 */
void updateActionSet(ClassifierSet **aset, float maxPrediction, float reward, ClassifierSet **pop, ClassifierSet **killset){
    float P, setsize=0.0;
	ClassifierSet *setp;

	P = reward + gama*maxPrediction;
	
	for(setp=*aset; setp!=NULL; setp=setp->next){
		setsize += setp->classifier->numerosity;
		setp->classifier->experience++;
	}
	
	for(setp=*aset; setp!=NULL; setp=setp->next) { // update prediction, prediction error and action set size estimate
		if((float)setp->classifier->experience < 1.0/beta) {
			// !first adjustments! -> simply calculate the average 
			setp->classifier->predictionError = (setp->classifier->predictionError * ((float)setp->classifier->experience - 1.0) + absoluteValue(P - setp->classifier->prediction)) / (float)setp->classifier->experience;
			setp->classifier->prediction = (setp->classifier->prediction * ((float)setp->classifier->experience - 1.0) + P) / (float)setp->classifier->experience;
			setp->classifier->actionSetSize = (setp->classifier->actionSetSize *((float)(setp->classifier->experience - 1))+setsize)/(float)setp->classifier->experience; 
		}
		else{
			// normal adjustment -> use widrow hoff delta rule 
			setp->classifier->predictionError += beta * (absoluteValue(P - setp->classifier->prediction) - setp->classifier->predictionError);
			setp->classifier->prediction += beta * (P - setp->classifier->prediction);
			setp->classifier->actionSetSize += beta * (setsize - setp->classifier->actionSetSize);
		}
	}
	updateFitness(*aset);
	if(doActSetSubsumption){
		//printClassifierSet(*aset);
		doActionSetSubsumption(aset,pop,killset);
		//printClassifierSet(*aset);
	}
}

// update the fitnesses of an action set (the previous [A] in multi-step envs or the current [A] in single-step envs.) 
void updateFitness(ClassifierSet *aset){
	ClassifierSet *setp;
	float ksum=0.0;
	
	if(aset==NULL){ // if the action set got NULL (due to deletion) return
		return;
	}
  
	//First, calculate the accuracies of the classifier and the accuracy sums
	for(setp=aset; setp!=NULL; setp=setp->next) {
		if(setp->classifier->predictionError <= epsilon_0) {
			setp->classifier->accuracy = 1.0;
		}
		else{
			setp->classifier->accuracy = alpha * pow(setp->classifier->predictionError / epsilon_0 , -nu); 
		}
		ksum += setp->classifier->accuracy*(float)setp->classifier->numerosity;
	}
  
  //Next, update the fitnesses accordingly
  for(setp=aset; setp!=NULL; setp=setp->next) {
	setp->classifier->fitness += beta * ( (setp->classifier->accuracy * setp->classifier->numerosity) / ksum - setp->classifier->fitness );
  }
}

// ############################ discovery mechanism #########################################

/**
 * The discovery conmponent with the genetic algorithm
 * note: some classifiers in set could be deleted !
 */
void discoveryComponent(ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int itTime, float situation[]){
	ClassifierSet *setp;
	Classifier *cl[2], *parents[2];
	float fitsum=0.0;
	int i, len, setsum=0, gaitsum=0;

	if(*set==NULL){ // if the classifier set is empty, return (due to deletion)
		return;
	}

	getDiscoversSums(*set, &fitsum, &setsum, &gaitsum); // get all sums that are needed to do the discovery

	// do not do a GA if the average number of time-steps in the set since the last GA is less or equal than thetaGA
	if( itTime - (float)gaitsum / (float)setsum < theta_GA){
		return;
	}
	setTimeStamps(*set, itTime);

	selectTwoClassifiers(cl, parents, *set, fitsum, setsum); // select two classifiers (tournament selection) and copy them
  	crossover(cl,crossoverType); // do crossover on the two selected classifiers
	for(i=0; i<2; i++){ // do mutation
		mutation(cl[i], situation);
	}

	cl[0]->prediction   = (cl[0]->prediction + cl[1]->prediction) / 2.0;
	cl[0]->predictionError = predictionErrorReduction * ( (cl[0]->predictionError + cl[1]->predictionError) / 2.0 );
	cl[0]->fitness = fitnessReduction * ( (cl[0]->fitness + cl[1]->fitness) / 2.0 );

	cl[1]->prediction = cl[0]->prediction;
	cl[1]->predictionError = cl[0]->predictionError;
	cl[1]->fitness = cl[0]->fitness;

  	// get the length of the population to check if clasifiers have to be deleted
	for(len=0, setp=*pop; setp!=NULL; setp=setp->next){
		len += setp->classifier->numerosity;
	}

	// insert the new two classifiers and delete two if necessary
	insertDiscoveredClassifier(cl, parents, set, pop, killset, len);
}
void getDiscoversSums(ClassifierSet *set, float *fitsum, int *setsum, int *gaitsum){ // Calculate all necessary sums in the set for the discovery component.
	ClassifierSet *setp;

	*fitsum=0.0;
	*setsum=0;
	*gaitsum=0;
	for(setp=set; setp!=NULL; setp=setp->next){
		(*fitsum)+=setp->classifier->fitness;
		(*setsum)+=setp->classifier->numerosity;
		(*gaitsum) += setp->classifier->timeStamp*setp->classifier->numerosity;
	}
}
void setTimeStamps(ClassifierSet *set, int itTime){ // Sets the time steps of all classifiers in the set to itTime (because a GA application is occurring in this set!).
	for( ; set!=NULL; set=set->next){
		set->classifier->timeStamp = itTime;
	}
}

// ########################### selection mechanism ########################################

/**
 * Select two classifiers using the chosen selection mechanism and copy them as offspring.
 */
void selectTwoClassifiers(Classifier **cl, Classifier **parents, ClassifierSet *set, float fitsum, int setsum){
	int i;
	Classifier *clp;

	assert(set!=NULL);

	for(i=0;i<2;i++) {
		if(tournamentSize <= 0){
			clp = selectClassifierUsingRWS(set,fitsum);
		}
		else{
			if(i==0){
				clp = selectClassifierUsingTournamentSelection(set, setsum, 0);
			}
			else{
				clp = selectClassifierUsingTournamentSelection(set, setsum, parents[0]);
			}
		}

		parents[i]=clp;

		assert((cl[i]=(struct Classifier *)calloc(1,sizeof(struct Classifier)))!=NULL);

		memmove( &(cl[i]->condition),&(clp->condition),sizeof(clp->condition) );
		memmove( &(cl[i]->cfAction),&(clp->cfAction),sizeof(clp->cfAction) );

		cl[i]->prediction = clp->prediction;
		cl[i]->predictionError = clp->predictionError;
		cl[i]->accuracy = clp->accuracy;
		cl[i]->fitness = clp->fitness / (float)clp->numerosity;
		cl[i]->numerosity = 1;
		cl[i]->experience = 0;
		cl[i]->actionSetSize = clp->actionSetSize;
		cl[i]->timeStamp = clp->timeStamp;
	}
}

/**
 * Selects a classifier from 'set' using tournament selection.
 * If 'notMe' is not the NULL pointer and forceDifferentInTournament is set to a value larger 0,
 * this classifier is not selected except if it is the only classifier.
 */
Classifier* selectClassifierUsingTournamentSelection(ClassifierSet *set, int setsum, Classifier *notMe){
	ClassifierSet *setp, *winnerSet=NULL;
	Classifier *winner=NULL;
	float fitness=-1.0, value;
	int i, j, *sel, size=0;

	assert(set!=NULL);/* there must be at least one classifier in the set */

	if(notMe!=0) {
		if(drand() < forceDifferentInTournament){
			setsum -= notMe->numerosity;
		}
		else{
			notMe=0; /* picking the same guy is allowed */
		}
	}
	if(setsum<=0){ /* only one classifier in set */
		return set->classifier;
	}

	if(tournamentSize>1){/* tournament with fixed size */
		assert((sel = (int *)calloc(setsum, sizeof(int)))!=NULL);
		for(i=0; i<tournamentSize; i++) { /* (with replacement) */
			sel[irand(setsum)]=1;
		}
		if(i-tournamentSize != 0 && drand() > i-tournamentSize) {
			/* possible probabilistic selection of the last guy */
			sel[irand(setsum)]=1;
		}
		for(setp=set, i=0; setp!=NULL; setp=setp->next) {
			if(setp->classifier != notMe) {
				if(fitness < setp->classifier->fitness/setp->classifier->numerosity) {
					for(j=0; j<setp->classifier->numerosity; j++) {
						if(sel[i+j]) {
							freeSet(&winnerSet);
							addClassifierToPointerSet(setp->classifier, &winnerSet);
							fitness = setp->classifier->fitness/setp->classifier->numerosity;
							break; /* go to next classifier since this one is already a winner*/
						}
					}
				}
				i += setp->classifier->numerosity;
			}
		}
		free(sel);
		assert(winnerSet!=NULL);
		size=1;
	}
	else{/* tournament selection with the tournament size approx. equal to tournamentSize*setsum */
		winnerSet=NULL;
		while(winnerSet==NULL) {
			size=0;
			for(setp=set; setp!=NULL; setp=setp->next) {
				if(setp->classifier != notMe) { /* do not reselect the same classifier -> this only applies if forcedDifferentInTournament is set!*/
					value = setp->classifier->predictionError;
					if(winnerSet==NULL || (!doGAErrorBasedSelect && fitness - selectTolerance <= setp->classifier->fitness/setp->classifier->numerosity) || (doGAErrorBasedSelect && fitness + selectTolerance * maxPayoff >= value)) {
						/* if his fitness is worse then do not bother */
						for(i=0; i<setp->classifier->numerosity; i++) {
							if(drand() < tournamentSize) {
								/* this classifier is a selection candidate and
								* his fitness/error is higher/lower or similar to the other classifier */
								if(winnerSet==NULL) {
									/* the first guy in the tournament */
									addClassifierToPointerSet(setp->classifier, &winnerSet);
									if(doGAErrorBasedSelect) {
										fitness = value;
									}
									else{
										fitness = setp->classifier->fitness/setp->classifier->numerosity;
									}
									size=1;
								}
								else{
									/* another guy in the tournament */
									if( (!doGAErrorBasedSelect && fitness + selectTolerance > setp->classifier->fitness/setp->classifier->numerosity) ||(doGAErrorBasedSelect && fitness - selectTolerance * maxPayoff < value)) {
										/* both classifiers in tournament have a similar fitness/error */
										size += addClassifierToPointerSet(setp->classifier, &winnerSet);
									}
									else{
										/* new classifier in tournament is clearly better */
										freeSet(&winnerSet);
										winnerSet=NULL;
										addClassifierToPointerSet(setp->classifier, &winnerSet);
										if(doGAErrorBasedSelect) {
											fitness = value;
										}
										else{
											fitness = setp->classifier->fitness/setp->classifier->numerosity;
										}
										size=1;
									}
								}
								break; /* go to next classifier since this one is already a winner*/
							}
						}
					}
				}
			}
		}
	}
	/* choose one of the equally best winners at random */
	size = irand(size);
	for(setp=winnerSet; setp!=NULL; setp=setp->next) {
		if(size==0){
			break;
		}
		size--;
	}
	assert(setp!=NULL);
	winner = setp->classifier;
	freeSet(&winnerSet);
	return winner;
}

/**
 * Select a classifier for the discovery mechanism using roulette wheel selection
 */
Classifier* selectClassifierUsingRWS(ClassifierSet *set, float fitsum){
	ClassifierSet *setp;
	float choicep;

	choicep=drand()*fitsum;
	setp=set;
	fitsum=setp->classifier->fitness;
	while(choicep>fitsum){
		setp=setp->next;
		fitsum+=setp->classifier->fitness;
	}

	return setp->classifier;
}

// ########################## crossover and mutation ########################################

void crossover(Classifier **cl, int crossoverType){ // Determines if crossover is applied and calls then the selected crossover type.
	if(drand()<pX){
		if(crossoverType == 0){
			uniformCrossover(cl);
		}
		else if(crossoverType == 1){
			onePointCrossover(cl);
		}
		else if(crossoverType == 2){
			twoPointCrossover(cl);
		}
		else{
			mixCrossover(cl);
		}
		crossover(cl[0]->cfAction,cl[1]->cfAction);
	}
}

//void uniformCrossover(Classifier **cl){ // Crosses the two received classifiers using uniform crossover.
//	Interval help;
//	for(int i=0; i<condLength; i++){
//		if(drand() < 0.5){
//			help = cl[0]->condition[i];
//			cl[0]->condition[i] = cl[1]->condition[i];
//
//			cl[1]->condition[i] = help;
//		}
//	}
//}

void uniformCrossover(Classifier **cl){ // Crosses the two received classifiers using uniform crossover.
	float help;
	for(int i=0; i<condLength; i++){
		for(int j=0; j<2; j++){
			if(drand() < 0.5){
				if(j==0){
					help = cl[0]->condition[i].lower;
					cl[0]->condition[i].lower = cl[1]->condition[i].lower;
					cl[1]->condition[i].lower = help;
				}
				else{
					help = cl[0]->condition[i].upper;
					cl[0]->condition[i].upper = cl[1]->condition[i].upper;
					cl[1]->condition[i].upper = help;
				}
			}
		}
	}
	validateCondition(cl[0]->condition);
	validateCondition(cl[1]->condition);
}

void onePointCrossover(Classifier **cl){ // Crosses the two received classifiers using one-point crossover.
	Interval help;
	int sep = irand(condLength);
	if(sep<0 || sep>=condLength){
		printf("\ninvalid crossover point\n");
		exit(0);
	}
	for(int i=0; i<=sep; i++){
		help=cl[0]->condition[i];
		cl[0]->condition[i]=cl[1]->condition[i];
		cl[1]->condition[i]=help;
	}
}

void twoPointCrossover(Classifier **cl){ // Crosses the two received classifiers using two-point crossover.
	Interval help;
	int sep1 = irand(condLength);
	int sep2 = irand(condLength);
	if(sep1<0 || sep1>=condLength || sep2<0 || sep2>=condLength){
		printf("\ninvalid crossover point\n");
		exit(0);
	}
	if(sep1>sep2){
		int help=sep1;
		sep1=sep2;
		sep2=help;
	}
	for(int i=sep1; i<=sep2; i++){
		help=cl[0]->condition[i];
		cl[0]->condition[i]=cl[1]->condition[i];
		cl[1]->condition[i]=help;
	}
}

void mixCrossover(Classifier **cl){ // Crosses the two received classifiers using mix crossover.
	Interval child1[condLength], child2[condLength];
	float gama_GA;
	for(int i=0; i<condLength; i++){
		gama_GA = (1.0 + 2.0*alpha_GA)*drand() - alpha_GA;
		child1[i].lower = (1.0 - gama_GA)*cl[0]->condition[i].lower + gama_GA*cl[1]->condition[i].lower;
		child1[i].upper = (1.0 - gama_GA)*cl[0]->condition[i].upper + gama_GA*cl[1]->condition[i].upper;

		gama_GA = (1.0 + 2.0*alpha_GA)*drand() - alpha_GA;
		child2[i].lower = (1.0 - gama_GA)*cl[0]->condition[i].lower + gama_GA*cl[1]->condition[i].lower;
		child2[i].upper = (1.0 - gama_GA)*cl[0]->condition[i].upper + gama_GA*cl[1]->condition[i].upper;
	}

	memmove(&cl[0]->condition,&child1,sizeof(child1));
	memmove(&cl[1]->condition,&child2,sizeof(child2));

	validateCondition(cl[0]->condition);
	validateCondition(cl[1]->condition);
}

/**
 * Apply mutation to classifier 'clfr'.
 * If niche mutation is applied, 'state' is considered to constrain mutation.
 * returns if the condition was changed.
 */
void mutation(Classifier *clfr, float state[]){
	if(mutationType == 0){
		applyNicheMutation(clfr,state);
	}
	else{
		applyGeneralMutation(clfr,state);
	}
	mutateAction(clfr);
}
/**
 * Mutates the condition of the classifier. If one allele is mutated depends on the constant pM.
 * This mutation is a niche mutation. It assures that the resulting classifier still matches the current situation.
 */
void applyNicheMutation(Classifier *clfr, float state[]){
	for(int i=0; i<condLength; i++){
	   if(drand()<pMC){
			float temp = drand()*m_0;
			if(drand()<0.5){
				temp = -temp;
			}
			if(drand()<0.5){
				clfr->condition[i].lower += temp;
			}
			else{
				clfr->condition[i].upper += temp;
			}
	  	}
	}
	validateCondition(clfr->condition);
}
/**
 * Mutates the condition of the classifier. If one allele is mutated depends on the constant pM.
 * This mutation is a general mutation.
 */
void applyGeneralMutation(Classifier *clfr, float state[]){

}
void mutateAction(Classifier *clfr){ //Mutates the action of the classifier.
	if(drand()<pMA){
		mutateProgram(clfr->cfAction);
	}
}
void validateCondition(Interval condition[]){
	for(int i=0; i<condLength; i++){
		if(condition[i].lower < lowerBound[i]){
			condition[i].lower = lowerBound[i];
		}
		else if(condition[i].lower > upperBound[i]){
			condition[i].lower = upperBound[i];
		}

		if(condition[i].upper < lowerBound[i]){
			condition[i].upper = lowerBound[i];
		}
		else if(condition[i].upper > upperBound[i]){
			condition[i].upper = upperBound[i];
		}

		if(condition[i].lower > condition[i].upper){
			float help;
			help = condition[i].lower;
			condition[i].lower = condition[i].upper;
			condition[i].upper = help;
		}
	}
}
// ###################### offspring insertion #################################

/**
 * Insert a discovered classifier into the population and respects the population size.
 */
void insertDiscoveredClassifier(Classifier **cl, Classifier **parents, ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int len){
	Classifier *killedp;
	len+=2;
	if(doGASubsumption){
		subsumeClassifier(cl[0],parents,*set,pop);
		subsumeClassifier(cl[1],parents,*set,pop);
	}
	else{
		addClassifierToSet(cl[0],pop);
		addClassifierToSet(cl[1],pop);
	}

	while(len > maxPopSize) {
		len--;
		killedp=deleteStochClassifier(pop);

		/* record the deleted classifier to update other sets */
		if(killedp!=NULL) {
			addClassifierToPointerSet(killedp,killset);
			/* update the set */
			updateSet(set, *killset);
		}
	}
}

// ################################ subsumption deletion #################################

/**
 * Action set subsumption as described in the algorithmic describtion of XCS
 */
void doActionSetSubsumption(ClassifierSet **aset, ClassifierSet **pop, ClassifierSet **killset){
	Classifier *subsumer=NULL;
	ClassifierSet *setp, *setpl;

	/* Find the most general subsumer */
	for(setp=*aset; setp!=NULL; setp=setp->next) {
		if(isSubsumer(setp->classifier)){
			//if(subsumer==NULL || isMoreGeneral_AS(setp->classifier->condition, subsumer->condition)) { // according to Wilson's XCSF
			if(subsumer==NULL || isMoreGeneral(setp->classifier->condition, subsumer->condition)) {
				subsumer = setp->classifier;
			}
		}
	}

	/* If a subsumer was found, subsume all classifiers that are more specific. */
	if(subsumer!=NULL) {
		for(setp=*aset, setpl=*aset; setp!=NULL; setp=setp->next) {
			while(isMoreGeneral(subsumer->condition, setp->classifier->condition)) {
				subsumer->numerosity += setp->classifier->numerosity;
				if(setpl==setp) {
					*aset=setp->next;
					deleteClassifierPointerFromSet(pop,setp->classifier);
					freeClassifier(setp->classifier);
					addClassifierToPointerSet(setp->classifier,killset);
					free(setp);
					setp=*aset;
					setpl=*aset;
				}
				else{
					setpl->next=setp->next;
					deleteClassifierPointerFromSet(pop,setp->classifier);
					freeClassifier(setp->classifier);
					addClassifierToPointerSet(setp->classifier,killset);
					free(setp);
					setp=setpl;
				}
			}
			setpl=setp;
		}
	}
}

/**
 * Tries to subsume the parents.
 */
void subsumeClassifier(Classifier *cl, Classifier **parents, ClassifierSet *locset, ClassifierSet **pop){
	int i;
	for(i=0; i<2; i++) {
		if(parents[i]!=NULL && subsumes(parents[i],cl)){
			parents[i]->numerosity++;
			freeClassifier(cl);
			return;
		}
	}
  	if(subsumeClassifierToSet(cl,locset)){
		return;
	}
	addClassifierToSet(cl,pop);
}

/**
 * Try to subsume in the specified set.
 */
bool subsumeClassifierToSet(Classifier *cl, ClassifierSet *set){
	ClassifierSet * setp;
	Classifier *subCl[maxPopSize];
	int numSub=0;

	for(setp=set; setp!=NULL; setp=setp->next) {
		if(subsumes(setp->classifier,cl)) {
			subCl[numSub]=setp->classifier;
			numSub++;
		}
	}
	/* if there were classifiers found to subsume, then choose randomly one and subsume */
	if(numSub>0) {
		numSub = irand(numSub);
		subCl[numSub]->numerosity++;
		freeClassifier(cl);
		return true;
	}
	return false;
}

bool subsumes(Classifier *cl1, Classifier * cl2){ // check if classifier cl1 subsumes cl2
	return isSameAction(cl1,cl2) && isSubsumer(cl1) && isMoreGeneral(cl1->condition,cl2->condition);
}

bool isSubsumer(Classifier *cl){
  return cl->experience > theta_sub && cl->predictionError <= epsilon_0;
}
bool isMoreGeneral_AS(Interval first[], Interval second[]){
	float generalityOne=0.0, generalityTwo=0.0;
	for(int i=0; i<condLength; i++){
		generalityOne += first[i].upper - first[i].lower + 1;
		generalityTwo += second[i].upper - second[i].lower + 1;
	}
	if(generalityOne > generalityTwo){
		return true;
	}
	return false;
}
/**
 * Check if the first condition is more general than the second.
 * It is made sure that the classifier is indeed more general and not equally general
 * as well as that the more specific classifier is completely included in the more general one (do not specify overlapping regions).
 */
bool isMoreGeneral(Interval first[], Interval second[]){
	for(int i=0; i<condLength; i++){
		if(!isGeneralInterval(first[i],second[i])){
			return false;
		}
	}
	return true;
}
/**
 * Check if the Interval one is more general than the Interval two.
 * It is made sure that the Interval is indeed more general and not equally general
 * as well as that the more specific Interval is completely included in the more general one (do not specify overlapping regions).
 */
bool isGeneralInterval(Interval one, Interval two){
    if( (one.lower<two.lower && one.upper>=two.upper) || (one.lower<=two.lower && one.upper>two.upper) ){
        return true;
    }
    return false;
}
// ###################### adding classifiers to a set ###################################


/**
 * Adds only the pointers to the pointerset, ensures that no pointer is added twice,
 * returns if the pointer was added
 */
bool addClassifierToPointerSet(Classifier *cl, ClassifierSet **pointerset){
	ClassifierSet *setp;
  	for(setp=*pointerset; setp!=NULL; setp=setp->next) {
		if(setp->classifier == cl){ // classifier is already in Set
			return false;
		}
	}
	// add the classifier, as it is not already in the pointerset
	assert((setp=( struct ClassifierSet*)calloc(1,sizeof(ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*pointerset;
	*pointerset=setp;
	return true;
}

// adds the classifier cl to the population, makes sure that the same classifier does not exist yet.
bool addClassifierToSet(Classifier *cl, ClassifierSet **clSet){
	ClassifierSet *setp;
  	// Check if classifier exists already. If so, just increase the numerosity and free the space of the new classifier
	for(setp=*clSet; setp!=NULL; setp=setp->next) {
		if( equals(setp->classifier,cl) ){
			setp->classifier->numerosity++;
			freeClassifier(cl);
			return true;
		}
	}
	// classifier does not exist yet -> add new classifier
	assert((setp=( struct ClassifierSet*)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*clSet;
	*clSet=setp;
	return false;
}

// adds the new Clasifier cl to the ClassifierSet 'clSet'.
void addNewClassifierToSet(Classifier *cl, ClassifierSet **clSet){
	//printClassifier(cl);
	ClassifierSet *setp;
	assert((setp=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	setp->classifier=cl;
	setp->next=*clSet;
	*clSet=setp;
}
bool equals(Classifier *clfr1, Classifier *clfr2){ //Returns if the two classifiers are identical in condition and action.
	if( isSameCondition(clfr1->condition,clfr2->condition) && isSameAction(clfr1,clfr2) ){
			return true;
	}
	return false;
}
bool isSameCondition(Interval cond1[], Interval cond2[]){
	for(int i=0; i<condLength; i++){
		if( (cond1[i].lower != cond2[i].lower) || (cond1[i].upper != cond2[i].upper) ){
			return false;
		}
	}
	return true;
}

bool isSameAction(Classifier *clfr1, Classifier *clfr2){
	for(int i=0; i<cfMaxLength; i++){
		if(clfr1->cfAction[i]!=clfr2->cfAction[i]){
			return false;
		}
	}
	return true;
}

// ############################## deletion ############################################
/**
 * Deletes one classifier in the population.
 * The classifier that will be deleted is chosen by roulette wheel selection
 * considering the deletion vote. Returns position of the macro-classifier which got decreased by one micro-classifier.
 **/
Classifier* deleteStochClassifier(ClassifierSet **pop){
	ClassifierSet *setp,*setpl;
	Classifier *killedp=NULL;
	float sum=0.0, choicep, meanf=0.0;
	int size=0;

	/* get the sum of the fitness and the numerosity */
	for(setp=*pop; setp!=NULL; setp=setp->next){
		meanf+=setp->classifier->fitness;
		size+=setp->classifier->numerosity;
	}
	meanf/=(float)size;

	/* get the delete proportion, which depends on the average fitness */
	for(setp=*pop; setp!=NULL; setp=setp->next) {
		sum += getDelProp(setp->classifier,meanf);
	}

	/* choose the classifier that will be deleted */
	choicep=drand()*sum;

	/* look for the classifier */
	setp=*pop;
	setpl=*pop;
	sum = getDelProp(setp->classifier,meanf);
	while(sum < choicep) {
		setpl=setp;
		setp=setp->next;
		sum += getDelProp(setp->classifier,meanf);
	}

	/* delete the classifier */
	killedp=deleteTypeOfClassifier(setp, setpl, pop);

	/* return the pointer to the deleted classifier, to be able to update other sets */
	return killedp;
}
float getDelProp(Classifier *clfr, float meanFitness){ //Returns the vote for deletion of the classifier.
	if(clfr->fitness/(float)clfr->numerosity >= delta*meanFitness || clfr->experience < theta_del){
		return (float)(clfr->actionSetSize*clfr->numerosity);
	}
	else{
		return (float)clfr->actionSetSize*(float)clfr->numerosity*meanFitness / (clfr->fitness/(float)clfr->numerosity);
	}
}
/**
 * Deletes the classifier setp from the population pop, setpl points to the classifier that is before setp in the list
 */
Classifier* deleteTypeOfClassifier(ClassifierSet *setp, ClassifierSet *setpl, ClassifierSet **pop){
	Classifier *killedp=NULL;

	/* setp must point to some classifier! */
	assert(setp!=NULL);

	if(setp->classifier->numerosity>1) {
		/* if the numerosity is greater than one -> just decrease it */
		setp->classifier->numerosity--;
	}
	else{
		/* if not, delete it and record it in killedp */
		if(setp==setpl) {
			*pop=setp->next;
		}
		else{
			setpl->next=setp->next;
		}
		killedp=setp->classifier;
		//printClassifier(killedp);
		freeClassifier(setp->classifier);
		free(setp);
	}
	/* return a pointer ot a deleted classifier (NULL if the numerosity was just decreased) */
	return killedp;
}
/**
 * Check if the classifier pointers that are in killset are in uset - delete the pointers,
 * if they are inside. Note that the classifiers in killset are already deleted, so do not
 * read their values or try to delete them again here!
 */
bool updateSet(ClassifierSet **uset, ClassifierSet *killset){
	ClassifierSet *setp,*setpl,*killp,*usetp;
	bool updated = true;

	if(*uset==NULL || killset==NULL){ // if one of the sets is empty -> do not do anything
		return false;
	}
	// check all classifiers in uset
	setp=*uset;
	while(updated && setp!=NULL) {
		setp=*uset;
		setpl=*uset;
		updated = false;
		while(setp!=NULL && !updated){
			for(killp=killset; killp!=NULL; killp=killp->next) {
				if(killp->classifier == setp->classifier){
					// if killed classifier found, delete the struct classifier set in uset
					updated = true;
					if(setp==setpl) { // first entry in set
						usetp=*uset;
						*uset=usetp->next;
						free(usetp);
						break;
					}
					else{
						setpl->next=setp->next;
						free(setp);
						setp = *uset;
						setpl= *uset;
						break;
					}
				}
			}
			if(updated){ // check the whole uset again, if one pointer was deleted
				break;
			}
			setpl=setp;
			setp=setp->next;
		}
	}
    return updated;
}

/**
 * Deletes the classifier pointer from the specified set
 * and returns if the pointer was found and deleted.
 */
bool deleteClassifierPointerFromSet(ClassifierSet **set, Classifier *clp){
	ClassifierSet *setp, *setpl;
	for(setp=*set, setpl=*set; setp!=NULL; setp=setp->next){
		if(setp->classifier==clp){
			if(setpl==setp){
				*set=(*set)->next;
				free(setp);
			}
			else{
				setpl->next=setp->next;
				free(setp);
			}
			return true;
		}
		setpl=setp;
	}
	return false;
}

//############# concrete deletion of a classifier or a whole classifier set ############

/**
 * Frees only the complete ClassifierSet (not the Classifiers itself)!
 */
void freeSet(ClassifierSet **cls){
	ClassifierSet *clp;
  	while(*cls!=NULL){
		clp=(*cls)->next;
		free(*cls);
		*cls=clp;
	}
}

/**
 * Frees the complete ClassifierSet with the corresponding Classifiers.
 */
void freeClassifierSet(ClassifierSet **cls){
	ClassifierSet *clp;
	while(*cls!=NULL){
		freeClassifier((*cls)->classifier);
		clp=(*cls)->next;
		free(*cls);
		*cls=clp;
    }
}

/**
 * Frees one classifier.
 */
void freeClassifier(Classifier *cl){
	free(cl);
}

// ############################### output operations ####################################

/**
 * print the classifiers in a ClassifierSet
 */
void printClassifierSet(ClassifierSet *head){
	for(; head!=NULL; head=head->next){
		printClassifier(head->classifier);
	}
	printf("\n\n");
}

/**
 * print the classifiers in a ClassifierSet to the file fp
 */
void fprintClassifierSet(FILE *fp, ClassifierSet *head){
	for(; head!=NULL; head=head->next){
		fprintClassifier(fp, head->classifier);
	}
	fwrite("\n\n",strlen("\n\n"),1,fp);
}

/**
 * print a single classifier
 */
void printClassifier(Classifier *clfr){
	for(int i=0; i<condLength; i++){
		printf("%f,%f  ",clfr->condition[i].lower,clfr->condition[i].upper);
	}
	printf(": ");
	printAction(clfr->cfAction);
	printf(" ----> Numerosity: %d ",clfr->numerosity);
	printf("Accuracy: %f ",clfr->accuracy);
	printf("Fitness: %f ",clfr->fitness);
	printf("Prediction Error: %f ",clfr->predictionError);
	printf("Prediction: %f ",clfr->prediction);
	printf("Experience: %d ",clfr->experience);
	printf("ActionSetSize: %f ",clfr->actionSetSize);
	printf("timeStamp: %d\n",clfr->timeStamp);
 }

/**
 * print a single classifier to the file fp
 */
void fprintClassifier(FILE *fp, Classifier *classifier){
	char buf[100];
	for(int i=0; i<condLength; i++){
		sprintf(buf,"%f, %f  ",classifier->condition[i].lower,classifier->condition[i].upper); fwrite(buf,strlen(buf),1,fp);
	}
	sprintf(buf,"\t: --->\t"); fwrite(buf,strlen(buf),1,fp);
	outprog(classifier->cfAction,cfMaxLength,fp);
	sprintf(buf,"\tNumerosity:\t%d\t",classifier->numerosity); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tAccuracy:\t%f\t",classifier->accuracy); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tFitness:\t%f\t",classifier->fitness); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tPrediction Error:\t%f\t",classifier->predictionError); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tPrediction:\t%f\t",classifier->prediction); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tExperience:\t%d\t",classifier->experience); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tActionSetSize:\t%f\t",classifier->actionSetSize); fwrite(buf,strlen(buf),1,fp);
	sprintf(buf,"\tTimeStamp:\t%d\n",classifier->timeStamp); fwrite(buf,strlen(buf),1,fp);
}

/*###################### sorting the classifier list ###################################*/

/**
 * Sort the classifier set cls in numerosity, prediction, fitness, or error order.
 * type 0 = numerosity order, type 1 = prediction order, type 2 = fitness order, type 3=error order, type 4=actionValue order
 */
ClassifierSet* sortClassifierSet(ClassifierSet **cls, int type){
	ClassifierSet *clsp, *maxcl, *newcls, *newclshead;
	float max;

	max=0.0;
	assert((newclshead=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
	newcls=newclshead;
	do{
		max=-100000.0;
		/* check the classifier set cls for the next maximum -> already inserted classifier are referenced by the NULL pointer */
		for( clsp=*cls, maxcl=NULL; clsp!=NULL; clsp=clsp->next ) {
			if(clsp->classifier!=NULL && (maxcl==NULL || ((type==0 && clsp->classifier->numerosity>max) || (type==1 && clsp->classifier->prediction>max) || (type==2 && clsp->classifier->fitness/clsp->classifier->numerosity > max) || (type==3 && -1.0*(clsp->classifier->predictionError) > max) || (type==4 && clsp->classifier->actionValue > max)))) {
				if(type==0){
					max=clsp->classifier->numerosity;
				}
				else if (type==1){
					max=clsp->classifier->prediction;
				}
				else if (type==2){
					max=clsp->classifier->fitness/clsp->classifier->numerosity;
				}
				else if(type==3){
					max=-1.0*(clsp->classifier->predictionError);
				}
				else if(type==4){
					max=clsp->classifier->actionValue;
				}
				maxcl=clsp;
			}
		}
		if(max>-100000.0) {
			assert((newcls->next=( struct ClassifierSet *)calloc(1,sizeof(struct ClassifierSet)))!=NULL);
			newcls=newcls->next;
			newcls->next=NULL;
			newcls->classifier=maxcl->classifier;
			maxcl->classifier=NULL; // do not delete the classifier itself, as it will be present in the new, sorted classifier list
		}
	}while(max>-100000.0);

	// set the new ClassifierSet pointer and free the old stuff
	newcls=newclshead->next;
	free(newclshead);
	freeSet(cls);

	return newcls; // return the pointer to the new ClassifierSet
}


/*################################## Utilitiy ##########################################*/

/**
 * Get the absolute value of 'value'.
 */
float absoluteValue(float value){
	if(value < 0.0){
		return -1.0*value;
	}
	else{
		return value;
	}
}

float min(float n1, float n2){
    if(n2 < n1){
        return n2;
    }
    return n1;
}

float max(float n1, float n2){
    if(n2 > n1){
        return n2;
    }
    return n1;
}

void bestAction(ClassifierSet *population){
	float state[condLength];
	for(float x=0.0; x<=1.0; x=x+0.001){
		state[0] = x;
		ClassifierSet *mset=NULL, *poppointer;
		PredictionArray *pa;

		for(poppointer= population; poppointer!=NULL; poppointer=poppointer->next){
			if(isConditionMatched(poppointer->classifier->condition,state)){
				poppointer->classifier->actionValue = getActionValue(poppointer->classifier,state);
				if(isValidAction(poppointer->classifier->actionValue)){
					addNewClassifierToSet(poppointer->classifier, &mset); // add matching classifier to the matchset
				}
			}
		}

		// we need room for the prediction array
		assert((pa = (PredictionArray *)calloc(getSetSize(mset),sizeof(PredictionArray)))!=0);

		int paSize = getPredictionArray(mset,pa,state);
		float actionWinner = bestActionWinner(pa,paSize);
		
		printf("%0.3f %0.3f\n",x,actionWinner);

		freeSet(&mset);
		free(pa);

	}
}
// ################################# simplyfy #########################################

bool qualifyForSimplification(Classifier *clfr1, Classifier *clfr2){
	if(isSameCondition(clfr1->condition,clfr2->condition) && clfr1->prediction == clfr2->prediction /*&& clfrConditionBasedActionValue(clfr1) == clfrConditionBasedActionValue(clfr2)*/){
		return true;
	}
	return false;
}

void simplifyPopulation(ClassifierSet **population){
	ClassifierSet *set,*set2,*setp, *killset = NULL;

	//consider only well experienced and accurate classifier rules
	for(set=*population,setp=*population ; set!=NULL; set=set->next){
		//printClassifier(set->classifier); printf("\n");
		while(set->classifier->experience <= 1.0/beta || set->classifier->predictionError > epsilon_0){
			//printClassifier(set->classifier);	printf("\n");
			if(setp==set){
				*population=set->next;
				deleteClassifierPointerFromSet(population,set->classifier);
				freeClassifier(set->classifier);
				addClassifierToPointerSet(set->classifier,&killset);
				free(set);
				set=*population;
				setp=*population;
			}
			else{
				setp->next=set->next;
				deleteClassifierPointerFromSet(population,set->classifier);
				freeClassifier(set->classifier);
				addClassifierToPointerSet(set->classifier,&killset);
				free(set);
				set=setp;
			}
		}
		setp=set;
	}
	freeSet(&killset);
	/*
	//simplify the population of classifiers by deleting redundant classifier rules
	for(set=*population; set->next!=NULL; set=set->next){
		for(setp=set,set2=set->next; set2!=NULL; set2=set2->next){
			if(qualifyForSimplification(set->classifier,set2->classifier)){
				set->classifier->numerosity += set2->classifier->numerosity;
				if(set->classifier->experience < set2->classifier->experience){
					set->classifier->experience = set2->classifier->experience;
				}
				if(set->classifier->fitness < set2->classifier->fitness){
					set->classifier->fitness = set2->classifier->fitness;
				}

				setp->next=set2->next;
				deleteClassifierPointerFromSet(population,set2->classifier);
				freeClassifier(set2->classifier);
				addClassifierToPointerSet(set2->classifier,&killset);
				free(set2);
				set2=setp;
			}
			setp=set2;
		}
		if(set->next==NULL){
			break;
		}
	}
	freeSet(&killset);
	*/
}

void condensePopulation(ClassifierSet **population){ //population sorted according to prediction
	//population->classifierSet[population->classifierSetSize++] = nullClassifier; // ending symbol
	int finalPopSize=0;
	ClassifierSet *iterate, *boundary=NULL;
	iterate = *population;

	if(iterate->classifier->prediction < maxPayoff){
		printf("\nNo accurate classifier!\n");
		return;
	}

	for( ; iterate->next!=NULL; iterate=iterate->next){
		if(iterate->next->classifier->prediction < maxPayoff){
			boundary = iterate;
			break;
		}
	}
	if(boundary!=NULL){
		freeClassifierSet(&(boundary->next));
		boundary->next = NULL;
	}

	for(iterate=*population; iterate!=NULL; iterate=iterate->next){
		finalPopSize++;
	}
	printf("\nNumber of classifiers in final population: %d\n",finalPopSize);
}