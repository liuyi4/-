#include <string.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include "xcsMacros.h"
#include "codeFragment.h"

char buf[100];

void printAction(opType action[]){
	char* temp = NULL;
	for(int j = 0; j<cfMaxLength; j++){
		temp = opchar(action[j]);
		printf("%s ",temp);
		if(action[j]==OPNOP)
			break; //reduce size of output
	}
	//printf("\n");
}
void validateDepth(opType* cf, opType* end){
	const opType* start = cf;
	opType* p = end -1;
	int a =1;
	int depth = -1;
	DepthMax(start,&p,a,depth);
	//printAction(cf);
	//printf("Depth: %d\n",depth);
	assert(depth<=cfMaxDepth);
}
bool equalTwoCFs(opType cf1[], opType cf2[]){
	for(int i=0; i<cfMaxLength; i++){
		if(cf1[i]!=cf2[i]){
			return false;
		}
	}
	return true;
}
void createNewCF(opType newCF[]){
	for(int i=0; i<cfMaxLength; i++){
		newCF[i] = OPNOP;
	}
}

// ####################################### action value ############################################

float getActionValue(Classifier *clfr, float currentState[]){
	/*
	printf("\n");
	for(int i=0; i<condLength; i++){
		printf("%c ",currentState[i]);
	}
	printf("\n");
	*/
	float stack[cfMaxStack];
	int SP = 0;
	for(int i=0; /*i<cfMaxLength*/; i++){
		const opType opcode = clfr->cfAction[i];
		//printf("SP:%d opcode:%d\n",SP,opcode);
		if(opcode==OPNOP) {
			break;
		}
		if(OPMINCOND<=opcode && opcode<condLength+OPMINCOND){ //condition bit
			stack[SP++] = currentState[(int)(opcode-OPMINCOND)];
		}
		else if(erc_min<=opcode && erc_max>=opcode){ //numeric constant
			stack[SP++] = opcode;
		}
		else if(opcode == OPLN){
			const float sp = stack[--SP];
			if(sp > 0.0){
				stack[SP++] = log(sp);
			}
			else{
				stack[SP++] = 0.0;
			}
		}
		else {
			const float sp2 = stack[--SP];
			const float sp1 = stack[--SP];
			if(opcode == OPADD){
				stack[SP++] = sp1 + sp2;
			}
			else if(opcode==OPSUB){
				stack[SP++] = sp1 - sp2;
			}
			else if(opcode==OPMUL){
				stack[SP++] = sp1 * sp2;
			}
			else if(opcode==OPDIV){
				if(sp2==0.0){
				    stack[SP++] = 0.0;
				}
				else{
				    stack[SP++] = sp1 / sp2;
				}
			}
			else{
				printf("\ninvalid operator: %f\n",opcode);
				exit(0);
			}
		}
	}
	float value = stack[--SP];
	assert(SP==0);
	//printf("%f  ",value); printAction(clfr->cfAction); printf("\n");
	return value;
}

// ################################## tree operations ######################################

inline int getNumberOfArguments(const opType opcode){
	if(opcode==OPADD || opcode==OPSUB || opcode==OPMUL || opcode== OPDIV){
		return 2;
	}
	if(opcode == OPLN){
		return 1;
	}
	return 0;
}
inline opType randomLeaf() {
	float leaf = 0.0;
	if(drand() < 1.0/( (float)(condLength + 1) )){ //numeric constant
		int range = (int)(erc_max - erc_min + 1.0);
		leaf = irand(range) + erc_min;
		if(leaf < erc_min || leaf > erc_max){
			printf("\nERROR in randomLeaf function ... %f\n",leaf);
			exit(0);
		}
		return leaf;
	}
	leaf = irand(condLength) + OPMINCOND; // condition bit
	if(leaf < OPMINCOND || leaf >= condLength+OPMINCOND){ //condition bit
		printf("\nERROR in randomLeaf function condition-bit... %f\n",leaf);
		exit(0);
	}
	return leaf;
}
float validLeaf(const opType opcode) {
	if(OPMINCOND<=opcode && opcode<condLength+OPMINCOND){ //condition bit
		return opcode;
	}
	if(erc_min<=opcode && erc_max>=opcode){ //numeric constant
		return opcode;
	}
	return erc_min - 1; // to signal error
}
inline opType randomFunction() {
  return functionCodes[irand(totalFunctions)];
}
//generate reverse polish
opType* randomProgram(opType* prog,const int isfull,const int maxDepth, const int minDepth){
	//if reached max depth or probabilistically reached mindepth
	if( maxDepth<=0 || ( (!isfull) && minDepth<=0 && irand(2) ) ) {
	  *prog = randomLeaf();
	  return prog+1;
	}
	else {
		opType* pc = prog;
		opType newFunction;
		newFunction = randomFunction();
	    const int numArgs = getNumberOfArguments(newFunction);
		for(int i=0; i<numArgs; i++){
			pc = randomProgram(pc,isfull,maxDepth-1,minDepth-1);
		}
		*pc = newFunction;
		return pc+1;
	}
}//end randomProgram
// --------------------------------- Start Display Functions -----------------------------
char* leafname(const opType code) {
	float leaf = validLeaf(code);
	if(OPMINCOND<=leaf && leaf<condLength+OPMINCOND){ //condition bit
		sprintf(buf,"D%d ",(int)(leaf-OPMINCOND));
	}
	else{
		sprintf(buf,"%0.1f ",leaf); //numeric constant
	}
	return buf;
}//end leafname
char* opchar(const opType code) {
	if(validLeaf(code)>= erc_min){
		return leafname(code);
	}
	if(code == OPADD){
		return (char*)"+ ";
	}
	if(code==OPSUB){
		return (char*)"- ";
	}
	if(code==OPMUL){
		return (char*)"* ";
	}
	if(code==OPDIV){
		return (char*)"/ ";
	}
	if(code==OPLN){
		return (char*)"ln ";
	}
	if(code==OPNOP){
		return (char*)"o ";
	}
	printf("\ninvalid code: %f\n",code);
	exit(0);
}

void outprog_bin(const opType* prog, int size) {
  for(int j = 0; j<size; j++)
	  printf("%f ", prog[j]);
}
void outprog(const opType* const prog, int size, FILE *fp){
	//printf("\nDisplaying Program...\n");
	char* temp = NULL;
	for(int j = 0; j<size; j++){
		temp = opchar(prog[j]);
		//printf("%s ",temp);
		fwrite(temp,strlen(temp),1,fp);
		if(prog[j]==OPNOP)
			break; //reduce size of output
	}
	//printf("\n");
	//fwrite("\n",strlen("\n"),1,fp);
}
// ------------------------- End Display Functions ----------------------------------
//Cf GProc's chrome.cxx, Convert to reverse polish
void DepthMax(const opType* const end,opType** prog, int& argstogo, int& depth) {
  if(*prog<end || argstogo<=0) return;
  const int a = getNumberOfArguments(*prog[0]);
  argstogo += a-1;
  *prog = (*prog-1);
  depth++;
  const int d0 = depth;
  for(int i=0;i<a;i++) {
    int d1 = d0;
    DepthMax(end,prog,argstogo,d1);
    depth = (depth>d1)? depth : d1; //max(depth,d1);
  }
}
int Depth(const opType* const end,opType** prog, const int depth) {
	if(*prog<=end){
		return depth;
	}
	const int a = getNumberOfArguments(*prog[0]);
	*prog = (*prog-1);
	const int d = depth+1;
	for(int i=0;i<a;i++) {
		const int d2 = Depth(end,prog,d);
		if(d2>0){
			return d2;
		}
	}
	return 0;
}
int StackMax(const opType* prog, int size) {//Reverse polish
  int sp = 0;
  int d  = sp;
  for(int i=0; i<size; i++) {
    if(prog[i]==OPNOP) return d;
    sp += 1-getNumberOfArguments(prog[i]);
    if(sp>d) d=sp;
  }
  assert(2==0);
}
int getLengthOfProgram(const opType* prog, int maxLength) { // excluding OPNOP(s)
	for(int i=0; i<maxLength; i++){
		if(prog[i] == OPNOP){
			return i;
		}
	}
	assert(2==0);
}
int getLengthOfTree(const opType* prog) {//Reverse polish
  int p = 0;
  int argstogo = 1;
  do {
    argstogo += getNumberOfArguments(prog[p])-1;
    p--;
  } while (argstogo>0);
  return -p;
}
void replaceTree(opType* prog, const int len, const int point, const int size0, const opType* in, const int size1) {
	//binary tree santy
	//assert(len%2 ==1);
	//assert(size0%2 ==1);
	//assert(size1%2 ==1);

	opType* excise = &prog[1+point];
	opType* insert = &prog[1+point-size0];
	const int tailsz = len-point;
	const int d = size1-size0;
	if(d>0) {//bigger Reverse polish tree
		//opType temp[tailsz];
		opType *temp = new opType[tailsz];
		memmove(temp,excise,tailsz*opSize);
		//printf("\n");
		//for(int i=0;i<tailsz;i++){
		//	printf("%d ",temp[i]);
		//}
		//printf("\n");
		memmove(insert+size1,temp,tailsz*opSize);
		delete temp;
	}
	else if(d<0) {//smaller RPN tree
		memmove(insert+size1,excise,tailsz*opSize);
		//opType temp[-d];
		opType *temp = new opType[-d];
		for(int i=0;i<-d;i++){
			temp[i]=OPNOP;
		}
		memmove(&prog[len+d],temp,-d*opSize);
		delete temp; // free space
	}//end if-else d
	memmove(insert,in,size1*opSize);
}//end replaceTree

inline int Point(const opType* prog,const int len) {
  const int func = irand(10); //Koza style 90% function bias
  int n = 0;
  do {
    const int point = irand(len);
    if(func!=0 && getNumberOfArguments(prog[point]) != 0) return point; //function
    if(func==0 && getNumberOfArguments(prog[point]) == 0) return point; //leaf
    if(++n>100) return point;
  } while(true);
}
///////////////////////////////////////////////////////////////////////////////////////////////
void auxMutateProgram(opType* prog, int len, int LEN, int pMaxDepth, int pMaxMuteDepth){
	const int point = Point(prog,len);
	const int size0 = getLengthOfTree(&prog[point]);
	opType* start = &prog[point];
	opType* p = &prog[len-1]; //root
	int a = 1;
	int depthroot = -1;
	DepthMax(start,&p,a,depthroot);
	//DepthMax(&prog[1+point-size0],&start,a,depthroot);
	//printf("DEPTH_ROOT:%d\n",depthroot);
	assert(0<=depthroot && depthroot<=pMaxDepth);

	//NB different conventions for depth of root 1 v 0
	//const int maxdepth=(pMaxMuteDepth<depthroot-1)?pMaxMuteDepth:depthroot-1;
	//const int maxdepth=(1<depthroot-1)?1:depthroot-1; //anti-bloat
	const int maxdepth=(1<pMaxDepth-depthroot)?1:pMaxDepth-depthroot;

	//opType temp[LEN]; //should cope with largest tree of pMaxMuteDepth
	opType *temp = new opType[LEN]; // get space
	int size1 = 0;

	opType* end; int limit=1000;
	do {
		for(int i=0; i<LEN; i++){
			temp[i] = OPNOP;
		}
		if(--limit<=0) {//too long;
			//printf("mutateProgram(%s\n",prog);
			printf(") len=%d point=%d size0=%d depthroot=%d maxdepth=%d\n",len,point,size0,depthroot,maxdepth);
			printf(" size1=%d",size1);
			exit(1);
		}//end if
		//ramped half-and-half,     //NB this is not size neutral!!
		end = randomProgram(temp,irand(2),maxdepth,0);
		assert(temp<end && end<&temp[LEN]);
		size1 = end-temp;
	}while( len-size0+size1 >(LEN-1) );
    replaceTree(prog, len, point, size0, temp, size1);

	delete temp; // free space

	//validate depth
	depthroot = -1;
	start = &prog[0];
	p = &prog[len-1-size0+size1]; //new root
	a = 1;
	DepthMax(start,&p,a,depthroot);
	//printf("DEPTH_NEWROOT:%d\n",depthroot);
	assert(0<=depthroot && depthroot<=pMaxDepth);
}//end auxMutateProgram

void mutateProgram(opType prog[]) {
	const int length = getLengthOfProgram(prog,cfMaxLength);
	auxMutateProgram(prog,length,cfMaxLength,cfMaxDepth,cfMaxMuteDepth);
}//end mutateProgram

void mutateN_prog(opType prog[]) {//exactly one change
	const int length = getLengthOfProgram(prog,cfMaxLength);
	int point;
	opType opcode;
	point = irand(length);
	opcode = prog[point];
	if(opcode == OPLN){//DON'T CHANGE
		return;
	}
	const int args = getNumberOfArguments(opcode);
	opType newopcode;
	do {
		newopcode = (args==0)? randomLeaf() : randomFunction();
	} while(newopcode==opcode || newopcode==OPLN);
	prog[point] = newopcode;
}//end mutateN_prog
bool crossover(const int point1, opType prog1[], const int len1,const int point2, opType prog2[], const int len2, const int LEN, int pMaxDepth) {
	const int size1 = getLengthOfTree(&prog1[point1]);
	const int size2 = getLengthOfTree(&prog2[point2]);
	if(len1-size1+size2>(LEN-1) || len2-size2+size1>(LEN-1)){
		return false;
	}

	//printf("point1:%d len1:%d size1:%d point2:%d len2:%d size2:%d\n",point1,len1,size1,point2,len2,size2);

	opType* p;
	int a;

	p = &prog1[point1];
	a = 1;
	int depthtree1 = -1;
	DepthMax(&prog1[point1-size1],&p,a,depthtree1); //subtree 1
	//printAction(prog1);
	//printf("depthTree1:%d\n", depthtree1);
	assert(0<=depthtree1 && depthtree1<=pMaxDepth);


	p = &prog1[len1-1];  //root 1
	const int depthroot1 = Depth(&prog1[point1],&p,0);
	//printf("depthRoot1:%d\n", depthroot1);
	assert(0<=depthroot1 && depthroot1<=pMaxDepth);

	p = &prog2[point2];
	a = 1;
	int depthtree2 = -1;
	DepthMax(&prog2[point2-size2],&p,a,depthtree2); //subtree 2
	//printf("depthTree2:%d\n", depthtree2);
	assert(0<=depthtree2 && depthtree2<=pMaxDepth);

	p = &prog2[len2-1];  //root 2
	const int depthroot2 = Depth(&prog2[point2],&p,0);
	//printf("depthRoot2:%d\n", depthroot2);
	assert(0<=depthroot2 && depthroot2<=pMaxDepth);

	if(depthtree1+depthroot2/*-1*/ > pMaxDepth || depthtree2+depthroot1/*-1*/ > pMaxDepth) {
		return false;
	}

	//opType temp1[LEN];
	opType *temp1 = new opType[LEN];
	memmove(temp1,&prog1[1+point1-size1],size1*opSize);

	//opType temp2[LEN];
	opType *temp2 = new opType[LEN];
	memmove(temp2,&prog2[1+point2-size2],size2*opSize);

	replaceTree(prog1, len1, point1, size1, temp2, size2);
	replaceTree(prog2, len2, point2, size2, temp1, size1);

	delete temp1; // free space
	delete temp2; // free space

	opType* start = &prog1[0];
	int len = getLengthOfProgram(prog1,cfMaxLength);
	p = &prog1[len-1];
	a = 1;
	int depth = -1;
	DepthMax(start,&p,a,depth); //sanity check
	//printf("depth___1:%d\n", depth);

	assert(0<=depth && depth<=pMaxDepth);

	start = &prog2[0];
	len = getLengthOfProgram(prog2,cfMaxLength);
	p = &prog2[len-1];
	a = 1;
	depth = -1;
	DepthMax(start,&p,a,depth); //sanity check
	//printf("depth___2:%d\n", depth);

	assert(0<=depth && depth<=pMaxDepth);

	return true;

}//end crossover

void crossover(opType prog1[],opType prog2[]) {
	//printf("\n\n");
	//printAction(prog1);
	//printf("\n");
	//printAction(prog2);
	const int length1 = getLengthOfProgram(prog1,cfMaxLength);
	const int length2 = getLengthOfProgram(prog2,cfMaxLength);
	//printf("\nLength_1: %d",length1);
	//printf("\nLength_2: %d",length2);
	int point1,point2;
	do{
		point1 = Point(prog1,length1);
		point2 = Point(prog2,length2);
	}while(crossover(point1,prog1,length1,point2,prog2,length2,cfMaxLength,cfMaxDepth)==false);
	//printf("\n");
	//printAction(prog1);
	//printf("\n");
	//printAction(prog2);
}//end crossover
