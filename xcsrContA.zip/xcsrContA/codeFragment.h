#include <fstream>
#include <math.h>
#include "configuration.h"

const int erc_min = -2;
const int erc_max = 2;
const opType OPMINCOND = erc_max + 1;

void printAction(opType action[]);
void validateDepth(opType* cf, opType* end);
bool equalTwoCFs(opType cf1[], opType cf2[]);
void createNewCF(opType newCF[]);
float getActionValue(Classifier *clfr, float state[]);

int getNumberOfArguments(const opType opcode);
opType randomLeaf();
float validLeaf(const opType opcode);
opType randomFunction();
opType* randomProgram(opType* prog,const int isfull,const int maxDepth, const int minDepth);
char* leafname(const opType code);
char* opchar(const opType code);
void outprog_bin(const opType* prog, int size);
void outprog(const opType* const prog, int size, FILE *fp);
void DepthMax(const opType* const end,opType** prog, int& argstogo, int& depth);
int Depth(const opType* const end,opType** prog, const int depth);
int StackMax(const opType* prog, int size);
int getLengthOfProgram(const opType* prog, int maxLength);
int getLengthOfTree(const opType* prog);
void replaceTree(opType* prog, const int len, const int point, const int size0, const opType* in, const int size1);
int Point(const opType* prog,const int len);
void auxMutateProgram(opType* prog, int len, int LEN, int pMaxDepth, int pMaxMuteDepth);
void mutateProgram(opType prog[]);
void mutateN_prog(opType prog[]);
bool crossover(const int point1, opType prog1[], const int len1,const int point2, opType prog2[], const int len2, const int LEN, int pMaxDepth);
void crossover(opType prog1[],opType prog2[]);
