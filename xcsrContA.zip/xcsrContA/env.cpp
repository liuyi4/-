#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <fstream>
#include "xcsMacros.h"
#include "configuration.h"
#include "env.h"

void resetState(float currentState[]){ //Resets the system to the initial position and gets the perceptions in this position.
	
	//frog1 problem
	float d = (upperBound[0]-lowerBound[0])*drand() + lowerBound[0];
	currentState[0] = 1.0-d;
	
	/*
	//frog2 problem
	float d = (upperBound[0]-lowerBound[0])*drand() + lowerBound[0];
	currentState[0] = pow(e,-d);
	*/


	/*
	if(d==0.0 || d==1.0){ //Debugging
		printf("%f",d);
		exit(0);
	}
	*/
	/*
	printf("\n\n");
	for(int i=0; i<condLength; i++){
		printf("%f ",currentState[i]);
	}
	printf("\n\n");
	*/
}

float executeAction(float action, float currentState[], bool &wasCorrect){ //Executes the specified action in the environment and returns possible payoff.
	float x = currentState[0];
	float reward = 0.0;
	
	//frog1 problem
	if(action == 1.0-x){ // error less than 0.01 ?
	    wasCorrect = true;
	}

	if(x+action <= 1.0){
		reward  = x+action;
	}
	else{
		reward = 2.0-(x+action);
	}
	
	/*
	//frog2 problem
	if(action == -log(x)){
	    wasCorrect = true;
	}

	if(action <= -log(x)){
		reward = x*pow(e,action);
	}
	else{
		reward = (1.0/x)*pow(e,-action);
	}
	*/
	/*
	printf("\n\n");
	printf("x: %f  action: %f reward: %f",x,action,reward);
	printf("\n\n");
	*/
	return reward;
	
}
