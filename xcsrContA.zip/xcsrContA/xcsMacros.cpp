//#include <stdio.h>
#include <math.h>
//#include <string.h>
//#include <time.h>

#include "xcsMacros.h"

long seed = 143907; // a number between 1 and _M-1 */
const long _Q = _M/_A; // constant for the random number generator (=_M/_A).
const long _R = _M%_A; // constant for the random number generator (=_M mod _A).
int haveUniNum=0;
float uniNum=0.0;

void setSeed(long s){ // sets a random seed in order to randomize the pseudo random generator.
	seed=s;
}

long getSeed(){
	return seed;
}

float drand(){ // returns a floating-point random number generated according to uniform distribution from [0,1]
	long hi   = seed / _Q;
	long lo   = seed % _Q;
	long test = _A*lo - _R*hi;
	if (test>0){
	    seed = test;
	}
	else{
	    seed = test+_M;
	}
	return (float)(seed)/_M;
}

float nrand(){ // returns a floating-point random number generated according to a normal distribution with mean 0 and standard deviation 1
	float x1, x2, w;

	if(haveUniNum){
		haveUniNum=0;
		return uniNum;
	}
	else{
		do{
			x1 = 2.0 * drand() - 1.0;
			x2 = 2.0 * drand() - 1.0;
			w = x1 * x1 + x2 * x2;
		}while( w >= 1.0 );
    
		w = sqrt( (-2.0 * log( w ) ) / w );
		uniNum = x1 * w;
		haveUniNum=1;
		return x2 * w;
	}
}

int irand(int n){ // returns a random number generated according to uniform distribution from [0,n-1]
	int num = (int)(drand()*(float)n);
	while(num == n){
		num = (int)(drand()*(float)n);
	}
	return num;
}