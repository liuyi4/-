const float e = 2.71828;
float executeAction(float action, float currentState[], bool &wasCorrect);
void resetState(float state[]);
