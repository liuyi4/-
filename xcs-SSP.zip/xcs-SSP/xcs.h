#include <fstream>

long seeds[30] = {114665,134296,176806,247157,262025,311756,336922,337104,344465,362234,379332,425485,470006,490758,538402,583115,584068,614795,678991,710953,715062,715911,784943,787483,790558,810292,824057,846845,968381,972820};
FILE *filePerformance=NULL, *fileCondensedClassifierPopulation=NULL, *fileSimplifiedClassifierPopulation=NULL, *fileWholeClassifierPopulation=NULL;
const int testFrequency = 1000;

void header();
void Exit(FILE *fp);

void writePerformance(int performance[], double sysError[], int exploreProbC);

void startXCS();
void doOneSingleStepExperiment(ClassifierSet **population);
void doOneSingleStepProblemExplore(ClassifierSet **population, char state[], int counter);
void doOneSingleStepProblemExploit(ClassifierSet **population, char state[], int counter, int correct[], double sysError[]);
