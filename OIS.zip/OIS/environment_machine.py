﻿import math
import sys
from environment_config import environment_config
import random
import sys
import os
class environment_machine:
    def __init__(self):
        self.e_con=environment_config()
        #DV1 size
        self.sizeDV1 = 74
        #DV1 Test data
        self.DV1 = [1, 2, 3, 8, 9, 10, 11, 13, 14, 24, 25, 26, 27, 28, 30, 40, 41, 42, 43, 46, 47, 56, 57, 58, 59, 61, 65, 66, 67, 69, 70, 71, 72, 73, 74, 75, 77, 78, 79, 81, 82, 83, 85, 86, 88, 89, 90, 91, 93, 94, 95, 97, 98, 99, 101, 102, 103, 104, 105, 106, 107, 109, 110, 113, 114, 115, 117, 118, 121, 122, 123, 125, 126, 127]
        #self.e_con.Test_2()#see which in the environment config
        #get the initial environment lists
        self.GetFileList(self.e_con.File_Environment_Basic_Address)
   
    #Nuber 1
    def Create_Normal_condition(self):
        state=[0]*self.e_con.condition_length
        for i in range(0, self.e_con.condition_length):
            random_number=random.randint(0,1)
            if(random_number==0):
                state[i]='0'
            else:
                state[i]='1'
        return state

    #Number2
    def Create_Symbol_condition(self,state):
        result=[0]*len(state)
        for i in range(0,len(state)):
            random_number=random.uniform(0,1)
            if(random_number<self.e_con.dont_care_probability):
                #print random_number
                result[i]=self.e_con.dont_care_symbol
            else:
                result[i]=state[i]
        return result

    #number 3
    def execute_Even_parity_Action(self,state):
        numbers=0
        actual_Action=False
        for i in range(0,len(state)):
            if state[i]=='1':
                numbers=numbers+1
        if numbers%2==0:
            actual_Action=True
        return actual_Action

    #number4
    def execute_Carry_Action(self,state):
        carry=0
        actual_Action=False
        half_condition=self.e_con.condition_length/2
        for i in range(0, half_condition):
            carry=(carry+int(state[half_condition-1-i])+int(state[half_condition-1-i+half_condition]))/2
        if carry==1:
            actual_Action=True
        return actual_Action

    #number5
    def execute_Multiplexer_Action(self,state):
        actual_Action=False
        place=self.e_con.posBits
        for i in range(0,self.e_con.posBits):
            if state[i]=='1':
                place=place+int(math.pow(2.0,float(self.e_con.posBits-1-i)))
                #print place
        if state[place]=='1':
            actual_Action=True
        return actual_Action

    #number6
    def execute_Hidden_Even_Parity_Action(self,state):
        actual_Action=False
        Numbers=0
        for i in range(0,self.e_con.numRelevantBits):
            if(state[self.e_con.posRelevantBits[i]]=='1'):
                Numbers=Numbers+1
        if Numbers%2==0:
            actual_Action=True
        return actual_Action

    #number7
    def execute_Hidden_Odd_Parity_Action(self,state):
        actual_Action=False
        Numbers=0
        for i in range(0,self.e_con.numRelevantBits):
            if(state[self.e_con.posRelevantBits[i]]=='1'):
                Numbers=Numbers+1
        if Numbers%2==1:
            actual_Action=True
        return actual_Action
    
    #number8
    def execute_Count_Ones_Action(self,state):
        actual_Action=False
        Numbers=0
        for i in range(0,self.e_con.numRelevantBits):
            if(state[self.e_con.posRelevantBits[i]]=='1'):
                Numbers=Numbers+1
        if Numbers>(self.e_con.numRelevantBits/2):
            actual_Action=True
        return actual_Action
    
    #number9
    def execute_Majority_On_Action(self,state):
        actual_Action=False
        Numbers=0
        for i in range(0,self.e_con.condition_length):
            if(state[i]=='1'):
                Numbers=Numbers+1
        if Numbers>(self.e_con.condition_length/2):
            actual_Action=True
        return actual_Action
   
    #number10
    def isDV1Term(self,n):
        for i in range(0,self.sizeDV1):
            if(n==self.DV1[i]):
                return True
        return False

    #number11
    def execute_DV1_Action(self,state):
        actualAction=False
        Number=0
        p=0
        for i in range(0,self.e_con.condition_length):
            Number=int(Number+int(state[self.e_con.condition_length-1-i])*math.pow(2,p))
            p=p+1
        #print Number
        if self.isDV1Term(Number):
            actualAction=True
        return actualAction

    #number12
    def Calculate_environment_rate_sum(self):
        sum=[]
        sum.append(0)
        Number_0=self.e_con.Rate_multiplexer
        sum.append(Number_0)
        Number_1=self.e_con.Rate_hiddenEvenParity+Number_0
        sum.append(Number_1)
        Number_2=self.e_con.Rate_hiddenOddParity+Number_1
        sum.append(Number_2)
        Number_3=self.e_con.Rate_countOnes+Number_2
        sum.append(Number_3)
        Number_4=self.e_con.Rate_carry+Number_3
        sum.append(Number_4)
        Number_5=self.e_con.Rate_evenParity+Number_4
        sum.append(Number_5)
        Number_6=self.e_con.Rate_majorityOn+Number_5
        sum.append(Number_6)
        Number_7=self.e_con.Rate_dv1+Number_6
        sum.append(Number_7)
        return sum

    #number13
    def Random_Environment_Type(self):
        sum=self.Calculate_environment_rate_sum()
        length=len(sum)-1
        lottery=random.randint(1,sum[length])
        #print lottery,sum[length]
        for i in range(0,len(self.e_con.Environments)):
            if lottery>sum[i] and lottery<=sum[i+1]:
                #print i
                #print self.e_con.Environments[i]
                return i,self.e_con.Environments[i]
                
    #number14
    def Generate_Condition(self,exe_number):
        if self.e_con.Condition_Model==self.e_con.Condition_Model_selections[0]:
            Numbers=random.randint(self.e_con.Condition_Min,self.e_con.Condition_Max)
        elif self.e_con.Condition_Model==self.e_con.Condition_Model_selections[1]:
            Numbers=self.e_con.NumofConditions
        else:
            Numbers=0
            print "system Error"
            sys.exit(0)
        conditions=[]
        for i in range(0,Numbers):
            state=self.Create_Normal_condition()
            #['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']
            if exe_number==0:
                result=self.execute_Multiplexer_Action(state)
            elif exe_number==1:
                result=self.execute_Hidden_Even_Parity_Action(state)
            elif exe_number==2: 
                result=self.execute_Hidden_Odd_Parity_Action(state)
            elif exe_number==3:
                result=self.execute_Count_Ones_Action(state)
            elif exe_number==4:
                result=self.execute_Carry_Action(state)
            elif exe_number==5:
                result=self.execute_Even_parity_Action(state)
            elif exe_number==6:
                result=self.execute_Majority_On_Action(state)
            elif exe_number==7:
                result=self.execute_DV1_Action(state)
            use_condition=Condition(state,result)
            #use_condition.state=state
            #use_condition.actual_action=result
            #use_condition.Test()
            conditions.append(use_condition)
        return conditions

    #number15
    def Generate_Environment(self,set):
        if self.e_con.Environment_selected==self.e_con.Environment_Set_options[0]:
            Type=self.Random_Environment_Type()
        elif self.e_con.Environment_selected==self.e_con.Environment_Set_options[1]:
            Type=self.e_con.Environment_Default
        elif self.e_con.Environment_selected==self.e_con.Environment_Set_options[2]:
            Type=set
        else:
            print "system error"
            sys.exit(0)
        conditions=self.Generate_Condition(Type[0])
        result_environment=Environment(conditions,Type[1],Type[0])
        #result_environment.Test()
        return result_environment

    #number16
    def Generate_many_Environments(self,Type):
        result_environments=[]
        default_Environment_Number_Set= self.e_con.Environment_Number_Set
        if Type!=None:         
            self.e_con.Set_Environment_Number_Set(Type)
        if self.e_con.Environment_Number_Set==self.e_con.Environment_Number_Set_Options[0]:
            for i in range(0,self.e_con.Environment_Random_Length):
                result=self.Generate_Environment(None)
                result_environments.append(result)
        elif self.e_con.Environment_Number_Set==self.e_con.Environment_Number_Set_Options[1]:
            use_list=self.e_con.Environment_sequence
            default_set=self.e_con.Environment_selected
            self.e_con.Set_Environment_selected(2)
            for i in use_list:
                work_type=[i,self.e_con.Environments[i]]
                result=self.Generate_Environment(work_type)
                result_environments.append(result)
            self.e_con.Environment_selected=default_set
        self.e_con.Environment_Number_Set= default_Environment_Number_Set
        return result_environments

    #number17
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    #number18
    def Build_File_Name_List(self,length):
        File_Name_List=[]
        for i in range(0,length):
            New_Name=self.e_con.File_Environment_Basic_Address+self.e_con.File_Environment_Basic_Name+'_'+str(i)+self.e_con.File_Environmet_Basic_Type
            File_Name_List.append(New_Name)
        return File_Name_List

    #number19
    def Create_folder(self):
        folder_Name=self.e_con.File_Environment_Basic_Address.replace('\\','')
        os.mkdir(folder_Name)
    
    #number20
    def Generate_write_Environment_message(self,environment):
        result=environment.type+'\n'
        #result="environment start\n"
        for i in range(0,len(environment.Conditions)):
            for j in range(0,len(environment.Conditions[i].state)):
                result=result+str(environment.Conditions[i].state[j])+' '
            result=result+'\\'+str(environment.Conditions[i].actual_action)+'\n'
        #result=result+"environment end\n"
        return result

    #number21 important
    def environment_File_Producer(self,environments):
        Name_List=self.Build_File_Name_List(len(environments))
        self.e_con.File_Environment_Name_List=Name_List
        if not self.Is_File_Exist(self.e_con.File_Environment_Basic_Address):
            self.Create_folder()
        for i in range(0,len(environments)):
            file_creater=Name_List[i]
            f=open(file_creater,'w')
            result=self.Generate_write_Environment_message(environments[i])
            f.writelines(result)
            f.close()
  
    #number22
    def GetFileList(self,FindPath):
        FileList=[]
        if self.Is_File_Exist(FindPath):
            FileNames=os.listdir(FindPath)
            for i in FileNames:
                if self.e_con.File_Environmet_Basic_Type in i:
                    FileList.append(i)
        if len(FileList)>0:
            self.e_con.File_Environment_Name_List=FileList
        else:
            self.e_con.File_Environment_Name_List=None

    #number23
    def Get_Read_Path(self): 
        file_Name=self.e_con.File_Environment_Name_List
        use_File=[]
        if len(file_Name)>0:
            for i in file_Name:
                full_name=self.e_con.File_Environment_Basic_Address+i
                use_File.append(full_name)
        return use_File
    
    #number24 important
    def Read_One_Environments(self,path):
        e=Environment(None,None,None)
        conditions=[]
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '':
             information.append(lines)
        if len(information)>0:
            type=str(information[0]).split('\n')
            e.type=type[0]
            for i in range(0,len(self.e_con.Environments)):
                if type[0]==self.e_con.Environments[i]:
                    e.type_Id=i
            for i in range(0,len(information)):
                if i>0:
                    state_o=str(information[i]).split('\n')
                    state_1=state_o[0].split('\\')
                    state=state_1[0].split(' ')
                    del state[-1]
                    c=Condition(state,state_1[1])
                    conditions.append(c)
            e.Conditions=conditions
            return e
        
    #number25
    def sort_Environments_Path(self,pathlist):  
        Dictionary =[]
        result=[]
        for address in pathlist:
            splits=address.split('_')
            Numbers=splits[1].split('.')
            pairs=[int(Numbers[0]),address]
            Dictionary.append(pairs)
        Dictionary.sort(key=lambda x:x[0])
        for address in Dictionary:
            result.append(address[1])
        return result
                        
    #number26 
    def environments_Translater(self):
        environments=[]
        First_Paths=self.Get_Read_Path() 
        Paths=self.sort_Environments_Path(First_Paths)  
        for i in Paths:
            e=self.Read_One_Environments(i)
            environments.append(e)
        return environments  
    
    #number27
    def Get_sorted_environment_address(self):
        First_Paths=self.Get_Read_Path() 
        Paths=self.sort_Environments_Path(First_Paths)  
        return Paths

    #number28
    def Environments_Machine_Generater(self):
        result=self.Generate_many_Environments(None)
        self.environment_File_Producer(result)

    #number29
    def Create_Set_condition(self,length):
        state=[0]*length
        for i in range(0, length):
            random_number=random.randint(0,1)
            if(random_number==0):
                state[i]='0'
            else:
                state[i]='1'
        return state

    #number30
    def Generate_Set_Conditions(self,size,length,exe_number):
         conditions=[]
         for i in range(0,size):
            state=self.Create_Set_condition(length)
            #['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']
            if exe_number==0:
                result=self.execute_Multiplexer_Action(state)
            elif exe_number==1:
                result=self.execute_Hidden_Even_Parity_Action(state)
            elif exe_number==2: 
                result=self.execute_Hidden_Odd_Parity_Action(state)
            elif exe_number==3:
                result=self.execute_Count_Ones_Action(state)
            elif exe_number==4:
                result=self.execute_Carry_Action(state)
            elif exe_number==5:
                result=self.execute_Even_parity_Action(state)
            elif exe_number==6:
                result=self.execute_Majority_On_Action(state)
            elif exe_number==7:
                result=self.execute_DV1_Action(state)
            use_condition=Condition(state,result)
            #use_condition.state=state
            #use_condition.actual_action=result
            #use_condition.Test()
            conditions.append(use_condition)
         return conditions

    #number31
    def Add_One_Environment(self,question,size,length):
        #['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']
        path=self.Get_sorted_environment_address()
        if path==None:
            Id=0
        else:
            Id=int( path[-1].split('_')[-1].split('.')[0])+1
        New_Name=self.e_con.File_Environment_Basic_Address+self.e_con.File_Environment_Basic_Name+'_'+str(Id)+self.e_con.File_Environmet_Basic_Type
        conditions=self.Generate_Set_Conditions(size,length,question)
        env=Environment(conditions,self.e_con.Environments[question],question)
        if not self.Is_File_Exist(self.e_con.File_Environment_Basic_Address):
            self.Create_folder()
        f=open(New_Name,'w')
        result=self.Generate_write_Environment_message(env)
        f.writelines(result)
        f.close()
        
    def Test_3(self):
        print"======================================================="
        print "Number 28"
        print "Function Name: Environments_Machine_Generater(self)"
        print "Purpose: Generate very basic environments "      
        print"======================================================="
        print "Number 29"
        print "Function Name: Create_Set_condition(self,length)"
        print "Purpose: Generate state base on the input length " 
        print "parameter length: the length of the state"
        print"======================================================="
        print "Number 30"
        print "Function Name: Generate_Set_Conditions(self,size,length,exe_number)"
        print "Purpose: Generate conditions base on the input length,size and exe_number "
        print "parameter size: the size of the conditions" 
        print "parameter length: the length of the state"
        print "parameter exe_number: the number of question Id" 
        print "['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']"
        print"======================================================="
        print "Number 31"
        print "Function Name: Add_One_Environment(self,question,size,length)"
        print "Purpose: add one environment into the environment pool "
        print "parameter size: the size of the conditions" 
        print "parameter length: the length of the state"
        print "parameter question: the number of question Id" 
        print "['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']"
        #self.Add_One_Environment(0,1000,11)

    #contain document from 17 to 27           
    def Test_2(self):
        print"======================================================="
        print "Number 17"
        print "Name: Is_File_Exist(self,file_Name)"
        print "Purpose: judge the file is exist or not yes return true not return false"
        print "return bool: true or false"
        #result=self.Is_File_Exist(self.e_con.File_Environment_Basic_Address)
        #print result
        print"======================================================="
        print "Number 18"
        print "Name: Build_File_Name_List(self,length)"
        print "Purpose: Get a list of file name"
        print "return File_Name_List: string[] a list of file name"
        #result=self.Build_File_Name_List(20)
        #for i in result:
        #    print i
        print"======================================================="
        print "Number 19"
        print "Name: Create_folder(self)"
        print "Purpose: create a folder"
        #self.Create_folder()
        print"======================================================="
        print "Number 20"
        print "Name: Generate_write_Environment_message(self,environment)"
        print "Parameter: environment an Environment type instance"
        print "Purpose: build the string foe the environment information to save in the file"
        print "return result: the string/char type for saving "
        #result=self.Generate_many_Environments(None)
        #result_0=self.Generate_write_Environment_message(result[0])
        #print result_0
        print"======================================================="
        print "Number 21 important"
        print "Name: environment_File_Producer(self,environments)"
        print "Purpose: save the environment information in the file"
        print "Parameter: environments a set of Environment type instances"
        #result=self.Generate_many_Environments(None)
        #self.environment_File_Producer(result)
        print"======================================================="
        print "Number 22"
        print "Name: GetFileList(self,FindPath)"
        print "Purpose: find all the environment files in one path"
        print "Parameter: FindPath the path of the document"
        #self.GetFileList(self.e_con.File_Environment_Basic_Address)
        #print self.e_con.File_Environment_Name_List
        print"======================================================="
        print "Number 23"
        print "Name: Get_Read_Path(self)"
        print "Purpose: get the full environment path list to read"
        #self.Get_Read_Path()   
        print"======================================================="
        print "Number 24 important"
        print "Name: Read_One_Environments(self,path)"
        print "Purpose: read the environment file and transfer it into environment instance"
        print "Parameter: Path the path of the environment file"
        #paths=self.Get_Read_Path()        
        #result=self.Read_One_Environments(paths[1])
        #result.Test()
        print"======================================================="
        print "Number 25"
        print "Name: sort_Environments_Path(self,pathlist)"
        print "Purpose: sort the environments path"
        #paths=self.Get_Read_Path() 
        #result=self.sort_Environments_Path(paths)
        #for i in result:
        #    print i
        print"======================================================="
        print "Number 26"
        print "Name: environments_Translater(self)"
        print "Purpose: read all the environment file and transfer it into environment instances"
        #result=self.environments_Translater()
        #for i in result:
        #    i.Test()
        print"======================================================="
        print "Number 27"
        print "Name: Get_sorted_environment_address(self)"
        print "Purpose: return the sorted environment path"
        #result=self.Get_sorted_environment_address()
        


    #contain document from 1 to 16
    def Test(self):
        print "Number 1"
        print "Name: Create_Normal_condition"
        print "Purpose: create normal conditions just like '101010', length depend on the value of condition length"
        print "return state: a condition"
        state=self.Create_Normal_condition()
        print state
        print"======================================================="
        print "Number 2"
        print "Name: Create_Symbol_condition"
        print "Purpose: create conditions with symbol just like '1#10#0', length depend on the value of condition length"
        print "return state: a condition with symbol"
        result=self.Create_Symbol_condition(state)
        print result
        print"======================================================="
        print "Number 3"
        print "Name: execute_Even_parity_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is Even return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Even_parity_Action(state)
        print result
        print"======================================================="
        print "Number 4"
        print "Name: execute_Carry_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is Carry return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Carry_Action(state)
        print result
        print"======================================================="
        print "Number 5"
        print "Name: execute_Multiplexer_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is Multiplexer return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Multiplexer_Action(state)
        print result
        print"======================================================="
        print "Number 6"
        print "Name: execute_Hidden_Even_Parity_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is Hidden even return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Hidden_Even_Parity_Action(state)
        print result
        print"======================================================="
        print "Number 7"
        print "Name: execute_Hidden_Odd_Parity_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is Hidden odd return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Hidden_Odd_Parity_Action(state)
        print result
        print"======================================================="
        print "Number 8"
        print "Name: execute_Count_Ones_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is count one return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Count_Ones_Action(state)
        print result
        print"======================================================="
        print "Number 9"
        print "Name: execute_Majority_On_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is majority 1 return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_Majority_On_Action(state)
        print result
        print"======================================================="
        print "Number 10"
        print "Name: isDV1Term(self,n)"
        print "Parameter n: int number just like 0,1,2,3"
        print "Purpose: judge the input value is in DV[] if it is return true else return false"
        print "return : True or False"
        print"======================================================="
        print "Number 11"
        print "Name: execute_Majority_On_Action(self,state)"
        print "Parameter state: condition"
        print "Purpose: get the result of condition if it is majority 1 return True if it is else return False"
        print "return actual_Action: True or False"
        result=self.execute_DV1_Action(state)
        print result
        print"======================================================="
        print "Number 12"
        print "Name: Calculate_environment_rate_sum(self)"
        print "Purpose: get the list of calculate the type of condition"
        print "return sum: int[]"
        #result=self.Calculate_environment_rate_sum()
        #print result
        print"======================================================="
        print "Number 13"
        print "Name: Random_Environment_Type(self)"
        print "Purpose: random generate the environment's type depend on the rate user set"
        print "return number,type: int,string"
        result=self.Random_Environment_Type()
        print result
        print"======================================================="
        print "Number 14"
        print "Name: Generate_Condition(self,exe_number)"
        print "Purpose: random generate message based on set"
        print "Parameter exe_number: enverniment type number just like [0,1,2,3,4,5,6,7]"
        print "return conditions: type Condition a set of conditions"
        #self.Generate_Condition(0)
        print"======================================================="
        print "Number 15"
        print "Name: Generate_Environment(self,set)"
        print "Purpose: random generate the environment"
        print "Parameter set: enverniment type if Environment_selected not equal 2 use None as input"
        print "return result_environment: type Environment a instance of environment"
        #result=self.Generate_Environment(None)
        #work=[1,self.e_con.Environments[1]]
        #result=self.Generate_Environment(work)
        #result.Test()
        print"======================================================="
        print "Number 16"
        print "Name: Generate_many_Environments(self)"
        print "Purpose: random generate many environments based on set Environment_Number_Set 0 randomly length20 1 a sequence of environment"
        print "Parameter type: set the type how to generate environment, 0 randomly 1 sequence if tyoe==0 use the configure set"
        print "return result_environments: type Environment[] a set instances of environment"
        #result=self.Generate_many_Environments(None)
        #for i in result:
        #    print "Number:",i
        #    i.Test()
        #print "length",len(result)
        print"======================================================="
     
class Condition:
    def __init__(self,use_state,result):
        self.state= use_state  
        self.actual_action=result

    def Test(self):
        print self.state
        print self.actual_action

class Environment:
    def __init__(self,conditions,use_type,Id_Type):
        self.Conditions=conditions
        self.type=use_type
        self.type_Id=Id_Type
    def Test(self):
        for i in self.Conditions:
            print i.state
            print i.actual_action
        print self.type
        print self.type_Id

class Test_Condition_or_Environment:
    def __init__(self):
        self.Condition=None
        self.Environment=None

    def Set_Condition(self,conditions):
        self.Condition=conditions

    def Set_Environment(self,Environments):
        self.Environment=Environments   
        
    def Test(self):
        print "Class Name: Condition"
        print "Purpose: save the information of conditions"
        print "Notice: it contain two parameters first state means the value of condition just like ['1','0','1','1']"
        print "Notice: actual_action is the result of this condition" 
        if self.Condition!=None:
            print self.Condition.state 
            print self.Condition.actual_action
        print "Class Name: Environment"
        print "Purpose: save the information of Environment"
        print "Notice: it contain two parameters first Conditions means a set of condition just like ['1','0','1','1'],['0','0','0','0']"
        print "Notice: type is the type of this condition" 
        if self.Environment!=None:
            print self.Environment.Conditions
            print self.Environment.type
            print self.Environment.type_Id

#e=environment_machine()
#e.Test()
#e.Test_2()
#e.Test_3()