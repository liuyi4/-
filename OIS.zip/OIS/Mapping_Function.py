﻿from Agent_Pools import xcsCFCavg_Translate
from computer_operator import computer_operator 
from Basic_Config import Basic_Config 
from Agent_Pools import Read_Agents
import random

class xcscfc_Mapping_Function:
    def __init__(self,agent):
        self.basic_symbols=['&','|','d','r','~']#Number1
        self.CF_string='CF_'#number2
        self.Data_String='D'#number3
        self.Output_string='o'#number4
        self.co_=computer_operator()
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number5
    
    #number6
    def operator_data(self,inf):
        if inf[0]==self.basic_symbols[4]:
            return self.co_.NOT(inf[1])
        elif inf[0]==self.basic_symbols[3]:
            return self.co_.NOR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[2]:
            return self.co_.NAND(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[1]:
            return self.co_.OR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[0]:
            return self.co_.AND(inf[1],inf[2])

    #number7
    def CFS_Search(self,CFS,Id):
        for CF in CFS:
            if CF.ID==Id:
                return CF.Rule[-1]

    #number8
    def Is_Good_Condition(self,rule,I_state,CFS):
         for cod in rule.conditions:
             result=self.branch_Calculate(cod[-1],I_state,CFS)
             if result==0:
                 return False
         return True

    #number9
    def Candidate_selection(self,Agent,state,CFS):
        #self.agent_O.Print_Tree_2(branch)
        inf=[]
        result=[]
        I_state=self.env_M.convert_int_condition_new(state)
        for rule in Agent.Rule:
            if self.Is_Good_Condition(rule,I_state,CFS):
                inf.append(rule.action)
                inf.append(float(rule.Prediction))
                inf.append(float(rule.Fitness))
                result.append(inf)
                inf=[]
        #print result[0][1]
        #print 'r',result
        return result

    #number10
    def PA_Calculation(self,Agent,state,CFS):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(Agent,state,CFS)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA

    #number11
    def Choose_Action(self,Agent,state,CFS):
        PA=self.PA_Calculation(Agent,state,CFS)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        return selection

    #number12
    def Data_split(self,value):
        result=value.split(self.Data_String)
        return int(result[1])

    #number13
    def CF_split(self,value):
        result=value.split(self.CF_string)
        return int(result[1])

    #number14
    def Set_Result_Null(self,branch):
        if branch.Left!=None:
            self.Set_Result_Null(branch.Left)
        if branch.Right!=None:
            self.Set_Result_Null(branch.Right)
        branch.Result=None

    #number15    
    def branch_Calculate(self,branch,state,CFS):
        if branch.Left!=None:
            self.branch_Calculate(branch.Left,state,CFS)
        if branch.Right!=None:
            self.branch_Calculate(branch.Right,state,CFS)
            
        if branch.Type==branch.Type_Id[0]:
            if self.Data_String in branch.value:    
                Id=self.Data_split(branch.value)
                branch.Set_Result(state[Id])
            elif self.CF_string in branch.value:
                Id=self.CF_split(branch.value)
                branch.Set_Result(self.branch_Calculate(self.CFS_Search(CFS,Id),state,CFS))
        elif branch.Type==branch.Type_Id[1]:
            if branch.value==self.basic_symbols[0]:
                inf=[self.basic_symbols[0],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[1]:
                inf=[self.basic_symbols[1],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[2]:
                inf=[self.basic_symbols[2],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[3]:
                inf=[self.basic_symbols[3],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[4]:
                inf=[self.basic_symbols[4],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.Output_string:
                result=branch.Left.Result
                self.Set_Result_Null(branch)
                return result

    #number16 important
    def Get_Action(self,state):
        result=self.Choose_Action(self.Work_Agent.Agent,state,self.Work_Agent.Agent.xcf.CFS)
        return result

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:basic_symbols"
        print "purpose: the symbol use"
        print ("value",self.basic_symbols)
        print"======================================================="
        print "Number 2"
        print "Name:CF_string"
        print "purpose: the CF_ string"
        print ("value",self.CF_string)
        print"======================================================="
        print "Number 3"
        print "Name:Data_String"
        print "purpose: the Data string"
        print ("value",self.Data_String)
        print"======================================================="
        print "Number 4"
        print "Name:Output_string"
        print "purpose: the output string"
        print ("value",self.Output_string)
        print"======================================================="
        print "Number 5"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        print"======================================================="
        print "Number 6"
        print "Function Name: operator_data(self,inf)"
        print "purpose: return the result after operator(and or notand not notor)"
        print "parameter inf: the data operator will use"
        print"======================================================="
        print "Number 7"
        print "Function Name: CFS_Search(self,CFS,Id)"
        print "purpose: return the CF's rule which map the input id"
        print "parameter CFS: the list of CF"
        print "parameter Id: the Id of CF you want"
        print"======================================================="
        print "Number 8"
        print "Function Name: Is_Good_Condition(self,rule,I_state,CFS)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter I_state: the state for use from environment"
        print "parameter CFS: the list of CF"
        print"======================================================="
        print "Number 9"
        print "Function Name:Candidate_selection(self,Agent,state,CFS)"
        print "purpose: select the candidates"
        print "parameter Agent: the agent use"
        print "parameter state: the state for use from environment"
        print "parameter CFS: the list of CF"
        print"======================================================="
        print "Number 10"
        print "Function Name:PA_Calculation(self,Agent,state,CFS)"
        print "purpose: calculate the PA prediction array"
        print "parameter Agent: the agent use"
        print "parameter state: the state for use from environment"
        print "parameter CFS: the list of CF"
        print"======================================================="
        print "Number 11"
        print "Function Name:Choose_Action(self,Agent,state,CFS)"
        print "purpose: choose the action"
        print "parameter Agent: the agent use"
        print "parameter state: the state for use from environment"
        print "parameter CFS: the list of CF"
        print"======================================================="
        print "Number 12"
        print "Function Name:Data_split(self,value)"
        print "purpose: split the data based on Data_String"
        print "parameter value: the value you want to split"
        print"======================================================="
        print "Number 13"
        print "Function Name:CF_split(self,value)"
        print "purpose: split the data based on CF_String"
        print "parameter value: the value you want to split"
        print"======================================================="
        print "Number 14"
        print "Function Name:Set_Result_Null(self,branch)"
        print "purpose: set all the branch's result in tree as None"
        print "parameter branch: the begin branch of the tree"
        print"======================================================="
        print "Number 15"
        print "Function Name:branch_Calculate(self,branch,state,CFS)"
        print "purpose: calculate the result from binary tree"
        print "parameter branch: the begin branch of the tree"
        print "parameter state: the state for use from environment"
        print "parameter CFS: the list of CF"
        print"======================================================="
        print "Number 16"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="
   
class xcsCFA_SSP_Mapping_Function:
     def __init__(self,agent):
        self.basic_symbols=['&','|','d','r','~']#Number1
        self.CF_string='CF_'#number2
        self.Data_String='D'#number3
        self.Output_string='o'#number4
        self.co_=computer_operator()
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number5

     #number6
     def operator_data(self,inf):
        if inf[0]==self.basic_symbols[4]:
            return self.co_.NOT(inf[1])
        elif inf[0]==self.basic_symbols[3]:
            return self.co_.NOR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[2]:
            return self.co_.NAND(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[1]:
            return self.co_.OR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[0]:
            return self.co_.AND(inf[1],inf[2])

     #number7
     def Data_split(self,value):
        result=value.split(self.Data_String)
        return int(result[1])

     #number8
     def Set_Result_Null(self,branch):
        if branch.Left!=None:
            self.Set_Result_Null(branch.Left)
        if branch.Right!=None:
            self.Set_Result_Null(branch.Right)
        branch.Result=None

     #number9
     def branch_Calculate(self,branch,state):
        if branch.Left!=None:
            self.branch_Calculate(branch.Left,state)
        if branch.Right!=None:
            self.branch_Calculate(branch.Right,state)
            
        if branch.Type==branch.Type_Id[0]:
            if self.Data_String in branch.value:    
                Id=self.Data_split(branch.value)
                branch.Set_Result(state[Id])
        elif branch.Type==branch.Type_Id[1]:
            if branch.value==self.basic_symbols[0]:
                inf=[self.basic_symbols[0],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[1]:
                inf=[self.basic_symbols[1],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[2]:
                inf=[self.basic_symbols[2],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[3]:
                inf=[self.basic_symbols[3],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[4]:
                inf=[self.basic_symbols[4],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.Output_string:
                result=branch.Left.Result                
                self.Set_Result_Null(branch)
                return result

     #number10
     def Is_Good_Condition(self,state,condition):
         for i in range(0,len(state)):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

     #number11
     def Candidate_selection(self,state):
         inf=[]
         result=[]
         calculate_state=self.env_M.convert_int_condition_new(state)
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcsCFA_SSPs:
             if self.Is_Good_Condition(state,rules.condition):
                 if rules.Action_Value==-1:
                     real_action=self.branch_Calculate(rules.result_tree[-1],calculate_state)
                     inf.append(real_action)
                     inf.append(rules.Prediction)
                     inf.append(rules.Fitness)
                     result.append(inf)
                     inf=[]
                     #print real_action
                 else:
                     #print rules.Action_Value
                     inf.append(rules.Action_Value)
                     inf.append(rules.Prediction)
                     inf.append(rules.Fitness)
                     result.append(inf)
                     inf=[]
         #print result
         return result
      
     #number12
     def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA      

     #number13
     def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection

     #number14
     def Get_Action(self,state):
        result=self.Choose_Action(state)
        #print result
        return result

     def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:basic_symbols"
        print "purpose: the symbol use"
        print ("value",self.basic_symbols)
        print"======================================================="
        print "Number 2"
        print "Name:CF_string"
        print "purpose: the CF_ string"
        print ("value",self.CF_string)
        print"======================================================="
        print "Number 3"
        print "Name:Data_String"
        print "purpose: the Data string"
        print ("value",self.Data_String)
        print"======================================================="
        print "Number 4"
        print "Name:Output_string"
        print "purpose: the output string"
        print ("value",self.Output_string)
        print"======================================================="
        print "Number 5"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        #tree=self.Work_Agent.Agent.xcsCFA_SSPs[0].result_tree
        #self.Work_Agent.Agent.xcsCFA_SSPs[0].Test()
        #tree[-1].Test_1()
        #Test_Message=['1','1','1','1','1','1','1','1','1','1','1']
        #Test_Message=[0,0,0,0,0,0,0,0,0,0,0]
        #Test_Message=['0','0','0','0','0','0','0','0','0','0','0']
        #result=self.branch_Calculate(tree[-1],Test_Message)
        #print 'r',result
        #self.Get_Action(Test_Message)
        print"======================================================="
        print "Number 6"
        print "Function Name: operator_data(self,inf)"
        print "purpose: return the result after operator(and or notand not notor)"
        print "parameter inf: the data operator will use"
        print"======================================================="
        print "Number 7"
        print "Function Name:Data_split(self,value)"
        print "purpose: split the data based on Data_String"
        print "parameter value: the value you want to split"
        print"======================================================="
        print "Number 8"
        print "Function Name:Set_Result_Null(self,branch)"
        print "purpose: set all the branch's result in tree as None"
        print "parameter branch: the begin branch of the tree"
        print"======================================================="
        print "Number 9"
        print "Function Name:branch_Calculate(self,branch,state)"
        print "purpose: calculate the result from binary tree"
        print "parameter branch: the begin branch of the tree"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 10"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 11"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 12"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 13"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 14"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="      

class xcs_SSP_Mapping_Function:
    def __init__(self,agent):
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number1

    #number2
    def Is_Good_Condition(self,state,condition):
         for i in range(0,len(state)):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

     #number3
    def Candidate_selection(self,state):
         inf=[]
         result=[]
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcs_SSPs:
             if self.Is_Good_Condition(state,rules.condition):
                inf.append(rules.Action_Value)
                inf.append(rules.Prediction)
                inf.append(rules.Fitness)
                result.append(inf)
                inf=[]
         #print result
         return result

     #number5
    def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection
    #number4
    def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA  
     
     #number6
    def Get_Action(self,state):
        result=self.Choose_Action(state)
        #print result
        return result

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        print"======================================================="
        print "Number 2"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 3"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 4"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 5"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="    

class xcsf_Boolean_Mapping_Function:
     def __init__(self,agent):
        self.env_M=env_Mapping()
        self.x0=1#number0
        self.Work_Agent=agent#number1

    #number2
     def Is_Good_Condition(self,state,condition):
         for i in range(0,len(state)):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

     #number7
     def calculate_prediction(self,state,prediction):
         result=self.x0*prediction[0]
         for i in range(0,len(state)):
             result=result+state[i]*prediction[i+1]
         return result

     #number3
     def Candidate_selection(self,state):
         inf=[]
         result=[]
         calculate_state=self.env_M.convert_int_condition_new(state)
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcsf_Boolean:
             if self.Is_Good_Condition(state,rules.condition):
                inf.append(int(rules.Action))
                Prediction=self.calculate_prediction(calculate_state,rules.Prediction)
                inf.append(Prediction)
                inf.append(rules.Fitness)
                result.append(inf)
                inf=[]
         #print result
         return result

     #number5
     def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection
    #number4
     def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA  
     
     #number6
     def Get_Action(self,state):
        result=self.Choose_Action(state)
        #print result
        return result

     def Test(self):
        print"======================================================="
        print "Number 0"
        print "Name:x0"
        print "purpose: the x0"
        print"======================================================="
        print "Number 1"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        print"======================================================="
        print "Number 2"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 3"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 4"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 5"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="    
        print "Number 7"
        print "Function Name:calculate_prediction(self,state,prediction)"
        print "purpose: Get the prediction"
        print "parameter prediction: a list of predictions"
        print "parameter state: one condition of the environments"
        print"======================================================="   

class xcsSMA_v2_adder_Mapping_Function:
    def __init__(self,agent):
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number1

    #number2
    def Is_Good_Condition(self,state,condition):
         number=len(state)
         if len(state)>self.Work_Agent.Length:
             number=self.Work_Agent.Length
         for i in range(0,number):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

    #number3
    def Get_active_action(self,FSM):
         active_list=[]
         for instance in FSM.FSM_q:
             if instance.active=='1':
                 active_list.append(instance.q_number)
         return active_list

    #number4
    def Is_Active(self,active_list,Id):
        for instance in active_list:
            if Id ==instance:
                return True
        return False

    #number5
    def Get_randomly_choose_Q(self,active_list):
        #active_list=self.Get_active_action(FSM)
        result=random.choice(active_list)
        return result 

    #number9
    def Candidate_selection(self,state):
         inf=[]
         result=[]
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcs_SMA_adder:
             if self.Is_Good_Condition(state,rules.condition):
                Action_Value=self.Run_FSM_basedon_list(rules.FSM,state)
                inf.append(int(Action_Value))
                inf.append(float(rules.Prediction))
                inf.append(float(rules.Fitness))
                result.append(inf)
                inf=[]
         #print result
         return result

    #number10
    def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection

    #number11
    def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA  

    #number12
    def Get_Action(self,state):
        result=self.Choose_Action(state)
        #print result
        return result

    #number13
    def Get_active_action_basedon_list(self,FSM):
         active_list=[]
         for i in range(0,len(FSM.FSM_q)):
             if FSM.FSM_q[i][1]=='1':
                 active_list.append(i)
         return active_list

    #number15
    def Get_Transfer_Id(self,state_1,state_2):
        if state_1==0 and state_2==0:
            return 0
        elif state_1==0 and state_2==1:
            return 1
        elif state_1==1 and state_2==0:
            return 2
        elif state_1==1 and state_2==1:
            return 3

    #number14
    def Run_FSM_basedon_list(self,FSM,state):
        calculate_state=self.env_M.convert_int_condition_new(state)
        active_list=self.Get_active_action_basedon_list(FSM)
        count_number=0
        answer_number=FSM.Start_q
        result=None
        for i in range(0,int(len(calculate_state)/2)):
            Transfer_Id=self.Get_Transfer_Id( calculate_state[2*i], calculate_state[2*i+1])
            answer_number=FSM.FSM_q[int(answer_number)][2][Transfer_Id]
            if i==(int(len(calculate_state)/2)-1):
                result=FSM.FSM_q[int(answer_number)][0]
        return result
            

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        print"======================================================="
        print "Number 2"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 3"
        print "Function Name:Get_active_action(self,FSM)"
        print "purpose: get the list of q which is active"
        print "parameter FSM: a set of instances of q"
        print"======================================================="
        print "Number 4"
        print "Function Name:Is_Active(self,active_list,Id)"
        print "purpose: judge the input q Id is active or not"
        print "parameter active_list: a list of active q Id"
        print "parameter Id: the id of q"
        print"======================================================="
        print "Number 5"
        print "Function Name:Get_randomly_choose_Q(self,active_list)"
        print "purpose: get the randomly q id choose based on the active q Id list"
        print "parameter active_list: a list of active q Id"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_FSM_Id(self,FSM_q,state_piece)"
        print "purpose: get the FSM's next step q Id"
        print "parameter FSM_q: the instance of some q "
        print "parameter state_piece: a piece of state "
        print"======================================================="
        print "Number 7"
        print "Function Name:Get_FSM_q(self,q_number,FSM_qs)"
        print "purpose: get the FSM_q instance based on input q Id"
        print "parameter FSM_q: a set of instances of some q "
        print "parameter q_number: the id of q"
        print"======================================================="
        print "Number 8"
        print "Function Name:Run_FSM(self,FSM,state)"
        print "purpose: get the action by run FSM"
        print "parameter FSM: a instance of FSM "
        print "parameter state: environment state"
        print"======================================================="
        print "Number 9"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 10"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 11"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 12"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="
        print "Number 13"
        print "Function Name:Get_active_action_basedon_list(self,FSM)"
        print "purpose: get the list of q which is active"
        print "parameter FSM: a set of instances of q"
        print"======================================================="
        print "Number 14"
        print "Function Name:Run_FSM_basedon_list(self,FSM,state)"
        print "purpose: get the action by run FSM"
        print "parameter FSM: a instance of FSM "
        print "parameter state: environment state"
        print"======================================================="
        print "Number 15"
        print "Function Name:Get_Transfer_Id(self,state_1,state_2)"
        print "purpose: get the transfer Id"
        print "parameter state_1: the first state from env "
        print "parameter state_2: the second state from env"
        print"======================================================="

class xcsrContA__Mapping_Function:
     def __init__(self,agent):
        self.basic_symbols=['&','|','d','r','~','+','-','*','/','%']#Number1
        self.Data_String=['D','.']#number3
        self.Output_string='o'#number4
        self.co_=computer_operator()
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number5

     #number6
     def operator_data(self,inf):
        if inf[0]==self.basic_symbols[4]:
            return self.co_.NOT(inf[1])
        elif inf[0]==self.basic_symbols[3]:
            return self.co_.NOR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[2]:
            return self.co_.NAND(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[1]:
            return self.co_.OR(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[0]:
            return self.co_.AND(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[5]:
            return self.co_.Add(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[6]:
            return self.co_.substract(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[7]:
            return self.co_.times(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[8]:
            return self.co_.division(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[9]:
            return self.co_.remainder(inf[1],inf[2])

     #number7
     def Data_split(self,value):
         result=value
         if self.Data_String[0] in value:
             result=value.split(self.Data_String[0])[1]
         return float(result)

     #number8
     def Set_Result_Null(self,branch):
        if branch.Left!=None:
            self.Set_Result_Null(branch.Left)
        if branch.Right!=None:
            self.Set_Result_Null(branch.Right)
        branch.Result=None

     #number9
     def branch_Calculate(self,branch,state):
        if branch.Left!=None:
            self.branch_Calculate(branch.Left,state)
        if branch.Right!=None:
            self.branch_Calculate(branch.Right,state)
            
        if branch.Type==branch.Type_Id[0]:
            if self.Data_String in branch.value:    
                Id=self.Data_split(branch.value)
                branch.Set_Result(state[Id])
        elif branch.Type==branch.Type_Id[1]:
            if branch.value==self.basic_symbols[0]:
                inf=[self.basic_symbols[0],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[1]:
                inf=[self.basic_symbols[1],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[2]:
                inf=[self.basic_symbols[2],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[3]:
                inf=[self.basic_symbols[3],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.basic_symbols[4]:
                inf=[self.basic_symbols[4],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf))
            elif branch.value==self.Output_string:
                result=branch.Left.Result                
                self.Set_Result_Null(branch)
                return result

     #number10
     def Is_Good_Condition(self,state,condition):
         for i in range(0,len(state)):
             if not(state[i]>=condition[2*i] and state[i]<=condition[2*i+1]):
                     return False
         return True

     #number11
     def Candidate_selection(self,state):
         inf=[]
         result=[]
         calculate_state=self.env_M.convert_int_condition_new(state)
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcsrContA:
             if self.Is_Good_Condition(state,rules.condition):
                     real_action=self.branch_Calculate(rules.result_tree[-1],calculate_state)
                     inf.append(int(real_action*1000))
                     inf.append(rules.Prediction)
                     inf.append(rules.Fitness)
                     result.append(inf)
                     inf=[]
         #print result
         return result
      
     #number12
     def PA_Calculation(self,state):
        PA=[None]*1000
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA      

     #number13
     def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection

     #number14
     def Get_Action(self,state):
        result=self.Choose_Action(state)
        result=float(result/1000.0)
        #print result
        return result

     def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:basic_symbols"
        print "purpose: the symbol use"
        print ("value",self.basic_symbols)
        print"======================================================="
        print "Number 2"
        print "Name:CF_string"
        print "purpose: the CF_ string"
        print ("value",self.CF_string)
        print"======================================================="
        print "Number 3"
        print "Name:Data_String"
        print "purpose: the Data string"
        print ("value",self.Data_String)
        print"======================================================="
        print "Number 4"
        print "Name:Output_string"
        print "purpose: the output string"
        print ("value",self.Output_string)
        print"======================================================="
        print "Number 5"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        #tree=self.Work_Agent.Agent.xcsCFA_SSPs[0].result_tree
        #self.Work_Agent.Agent.xcsCFA_SSPs[0].Test()
        #tree[-1].Test_1()
        #Test_Message=['1','1','1','1','1','1','1','1','1','1','1']
        #Test_Message=[0,0,0,0,0,0,0,0,0,0,0]
        #Test_Message=['0','0','0','0','0','0','0','0','0','0','0']
        #result=self.branch_Calculate(tree[-1],Test_Message)
        #print 'r',result
        #self.Get_Action(Test_Message)
        print"======================================================="
        print "Number 6"
        print "Function Name: operator_data(self,inf)"
        print "purpose: return the result after operator(and or notand not notor)"
        print "parameter inf: the data operator will use"
        print"======================================================="
        print "Number 7"
        print "Function Name:Data_split(self,value)"
        print "purpose: split the data based on Data_String"
        print "parameter value: the value you want to split"
        print"======================================================="
        print "Number 8"
        print "Function Name:Set_Result_Null(self,branch)"
        print "purpose: set all the branch's result in tree as None"
        print "parameter branch: the begin branch of the tree"
        print"======================================================="
        print "Number 9"
        print "Function Name:branch_Calculate(self,branch,state)"
        print "purpose: calculate the result from binary tree"
        print "parameter branch: the begin branch of the tree"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 10"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 11"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 12"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 13"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 14"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="  

class xcscfunctions_Mapping_Function:
    def __init__(self,agent):
        self.basic_symbols=['+','-','*','/','=','$','@','L','[',']','{']#Number1
        self.Functions_symbols=[]
        self.Data_String='L'
        self.CF_string='CF_'
        self.Output_string='o'#number4
        self.co_=computer_operator()
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number5
        self.extend_Function()
        #print self.Functions_symbols

    def operator_data(self,inf,state):
        if inf[0]==self.basic_symbols[0]:
            return self.co_.OPPLUS(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[1]:
            return self.co_.OPMINUS(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[2]:
            return self.co_.OPMUL(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[3]:
            return self.co_.OPDIV(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[4]:
            return self.co_.OPVAL(state,inf[1])
        elif inf[0]==self.basic_symbols[5]:
            return self.co_.OPBINSTR(state,inf[1])
        elif inf[0]==self.basic_symbols[6]:
            #notice
            return self.co_.OPPOW2LOOP(inf[1],inf[2])
        elif inf[0]==self.basic_symbols[7]:
            return self.co_.CONST_LEN(state)
        elif inf[0]==self.basic_symbols[8]:
            return self.co_.OPFLR(inf[1])
        elif inf[0]==self.basic_symbols[9]:
            return self.co_.OPCLG(inf[1])
        elif inf[0]==self.basic_symbols[10]:
            return self.co_.OPNLG(inf[1])

    def Data_split(self,value):
        result=value.split(self.Data_String)
        return int(result[1])

    def Is_Good_Condition(self,state,condition):
         for i in range(0,len(state)):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

    def CF_split(self,value):
        result=value.split(self.CF_string)
        return int(result[1])

    def CFS_Search(self,Id):
        for CF in self.Work_Agent.Agent.CFs:
            if int(CF.Id)==Id:
                return CF.CFS[-1]

    def extend_Function(self):
        for f in self.Work_Agent.Agent.Functions:
            if f.Name not in self.Functions_symbols:
                self.Functions_symbols.append(f.Name)

    def Is_Functions(self, value):
        if value in self.Functions_symbols:
            return True
        else:
            return False

    def Function_Search(self,name):
        for fun in self.Work_Agent.Agent.Functions:
            #print name,'        ',fun.Name
            if fun.Name==name:
                use_num=random.randint(1,fun.Number_Rules) 

                for rul in fun.Rules:
                    if int(rul.Id)==use_num:
                        return rul.Tree[-1]
     
    #number14
    def Set_Result_Null(self,branch):
        if branch.Left!=None:
            self.Set_Result_Null(branch.Left)
        if branch.Right!=None:
            self.Set_Result_Null(branch.Right)
        branch.Result=None

    #number15    
    def branch_Calculate(self,branch,state):
        #print branch.value
        if branch.Left!=None:
            self.branch_Calculate(branch.Left,state)
        if branch.Right!=None:
            self.branch_Calculate(branch.Right,state) 
        if branch.Type==branch.Type_Id[0]:
            if self.Data_String in branch.value:    
                inf=[self.basic_symbols[7]]
                #print self.operator_data(inf,state)
                branch.Set_Result(self.operator_data(inf,state))
            elif self.CF_string in branch.value:
                Id=self.CF_split(branch.value)
                branch.Set_Result(self.branch_Calculate(self.CFS_Search(Id),state))
            elif self.Is_Functions( branch.value):
                branch.Set_Result(self.branch_Calculate(self.Function_Search(branch.value),state))

        elif branch.Type==branch.Type_Id[1]:
            if self.Is_Functions( branch.value):
                branch.Set_Result(self.branch_Calculate(self.Function_Search(branch.value),state))
            elif branch.value==self.basic_symbols[0]:
                inf=[self.basic_symbols[0],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[1]:
                inf=[self.basic_symbols[1],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[2]:
                inf=[self.basic_symbols[2],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[3]:
                inf=[self.basic_symbols[3],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[4]:
                inf=[self.basic_symbols[4],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[5]:
                inf=[self.basic_symbols[5],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf,state))
                #notice
            elif branch.value==self.basic_symbols[6]:
                inf=[self.basic_symbols[6],branch.Left.Result,branch.Right.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[8]:
                inf=[self.basic_symbols[8],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[9]:
                inf=[self.basic_symbols[9],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.basic_symbols[10]:
                inf=[self.basic_symbols[10],branch.Left.Result]
                branch.Set_Result(self.operator_data(inf,state))
            elif branch.value==self.Output_string:
                result=branch.Left.Result
                #print result
                self.Set_Result_Null(branch)
                return result
        
    #number9
    def Candidate_selection(self,state):
        #self.agent_O.Print_Tree_2(branch)
        inf=[]
        result=[]
        I_state=self.Build_string(state)
        for rule in self.Work_Agent.Agent.Rule:
            if self.Is_Good_Condition(state,rule.Condition):
                action=self.branch_Calculate(rule.Action[-1],I_state)
                inf.append(action)
                inf.append(float(rule.Prediction))
                inf.append(float(rule.Fitness))
                result.append(inf)
                inf=[]
        #print result[0][1]
        #print 'r',result
        return result

    #number10
    def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA

    #number11
    def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        return selection

    def Build_string(self,list):
        result=''
        for l in list:
            result=result+l
        return result

    def Get_Action(self,state):
        result=self.Choose_Action(state)
        return result

class xcsSMA_v2_Mapping_Function:
    def __init__(self,agent):
        self.env_M=env_Mapping()
        self.Work_Agent=agent#number1

    #number2
    def Is_Good_Condition(self,state,condition):
         number=len(state)
         if len(state)>self.Work_Agent.Length:
             number=self.Work_Agent.Length
         for i in range(0,number):
             if condition[i]!='#':
                 if condition[i]!=state[i]:
                     return False
         return True

    #number3
    def Get_active_action(self,FSM):
         active_list=[]
         for instance in FSM.FSM_q:
             if instance.active=='1':
                 active_list.append(instance.q_number)
         return active_list

    #number4
    def Is_Active(self,active_list,Id):
        for instance in active_list:
            if Id ==instance:
                return True
        return False

    #number5
    def Get_randomly_choose_Q(self,active_list):
        #active_list=self.Get_active_action(FSM)
        result=random.choice(active_list)
        return result

    #number6
    def Get_FSM_Id(self,FSM_q,state_piece):
        return FSM_q.Action[state_piece]
    
    #number7
    def Get_FSM_q(self,q_number,FSM_qs):
        for instance in FSM_qs:
            if q_number== instance.q_number:
                return instance   

    #number8
    def Run_FSM(self,FSM,state):
        calculate_state=self.env_M.convert_int_condition_new(state)
        active_list=self.Get_active_action(FSM)
        count_number=0
        start_number=FSM.Start_q
        u_FSM_q=self.Get_FSM_q(start_number,FSM.FSM_q)
        result=None
        while count_number<len(calculate_state):
                if count_number==0:
                    candidate_Id=self.Get_FSM_Id(u_FSM_q,calculate_state[count_number])
                    if self.Is_Active(active_list,candidate_Id):
                        next_Id=candidate_Id
                    else:
                        next_Id=self.Get_randomly_choose_Q(active_list)
                    u_FSM_q=self.Get_FSM_q(next_Id,FSM.FSM_q)
                else:               
                    candidate_Id=self.Get_FSM_Id(u_FSM_q,calculate_state[count_number])
                    if self.Is_Active(active_list,candidate_Id):
                        next_Id=candidate_Id
                    else:
                        next_Id=self.Get_randomly_choose_Q(active_list)
                    u_FSM_q=self.Get_FSM_q(next_Id,FSM.FSM_q)
                if count_number==(len(calculate_state)-1):
                    result=u_FSM_q.result
                count_number=count_number+1
        #print 'c',count_number
        return result

    #number9
    def Candidate_selection(self,state):
         inf=[]
         result=[]
         #print calculate_state
         for rules in self.Work_Agent.Agent.xcs_SMA:
             if self.Is_Good_Condition(state,rules.condition):
                #Action_Value=self.Run_FSM(rules.FSM,state)
                Action_Value=self.Run_FSM_basedon_list(rules.FSM,state)
                inf.append(int(Action_Value))
                inf.append(float(rules.Prediction))
                inf.append(float(rules.Fitness))
                result.append(inf)
                inf=[]
         #print result
         return result

    #number10
    def Choose_Action(self,state):
        PA=self.PA_Calculation(state)
        selection=None
        High=PA[0]
        for i in range(0,len(PA)):
            if PA[i]>=High:
                High=PA[i]
                selection=i
        #print selection
        return selection

    #number11
    def PA_Calculation(self,state):
        PA=[None,None]
        FSA=[0.0,0.0]
        Candidates=self.Candidate_selection(state)
        for i in range(0,len(Candidates)):
            if PA[Candidates[i][0]]==None:
                PA[Candidates[i][0]]=Candidates[i][1]*Candidates[i][2]
            else:
                PA[Candidates[i][0]]=PA[Candidates[i][0]]+Candidates[i][1]*Candidates[i][2]
            FSA[Candidates[i][0]]=FSA[Candidates[i][0]]+Candidates[i][2]
        for i in range(0,len(PA)):
            if FSA[i]!=0:
                PA[i]=PA[i]/FSA[i]
        #print 'PA' ,PA
        #print 'FSA',FSA
        return PA  

    #number12
    def Get_Action(self,state):
        result=self.Choose_Action(state)
        #print result
        return result

    #number13
    def Get_active_action_basedon_list(self,FSM):
         active_list=[]
         for i in range(0,len(FSM.FSM_q)):
             if FSM.FSM_q[i][1]=='1':
                 active_list.append(i)
         return active_list


    #number14
    def Run_FSM_basedon_list(self,FSM,state):
        calculate_state=self.env_M.convert_int_condition_new(state)
        active_list=self.Get_active_action_basedon_list(FSM)
        count_number=0
        answer_number=FSM.Start_q
        result=None
        for i in range(0,len(calculate_state)):
            answer_number=FSM.FSM_q[int(answer_number)][int(calculate_state[i])+2]
            if i==(len(calculate_state)-1):
                result=FSM.FSM_q[int(answer_number)][0]
        return result
            

    def Test(self):
         #Test_Message=['0','0','0','0','0','0','0','0','0','0','0']
         #Test_Message=['0','1','1','1','1','1','1','1','1','1','1']
         #Test_Message=['0','1','1','1','1','1','1','1','1','1','0']
         #Test_Message=['0']
         #Test_Message=['1']
         #Test_Message=['0','1']
         #Test_Message=['1','0']
         #Test_Message=['1','1']
         #result=self.Run_FSM_basedon_list(use_agent[0].Agent.xcs_SMA[0].FSM,Test_Message)
         #result=self.Choose_Action(Test_Message)
         #print result
        print"======================================================="
        print "Number 1"
        print "Name:Work_Agent"
        print "purpose: the work agent"
        print"======================================================="
        print "Number 2"
        print "Function Name: Is_Good_Condition(self,state,condition)"
        print "purpose: is this rule satisfying"
        print "parameter rule: the rule for test"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 3"
        print "Function Name:Get_active_action(self,FSM)"
        print "purpose: get the list of q which is active"
        print "parameter FSM: a set of instances of q"
        print"======================================================="
        print "Number 4"
        print "Function Name:Is_Active(self,active_list,Id)"
        print "purpose: judge the input q Id is active or not"
        print "parameter active_list: a list of active q Id"
        print "parameter Id: the id of q"
        print"======================================================="
        print "Number 5"
        print "Function Name:Get_randomly_choose_Q(self,active_list)"
        print "purpose: get the randomly q id choose based on the active q Id list"
        print "parameter active_list: a list of active q Id"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_FSM_Id(self,FSM_q,state_piece)"
        print "purpose: get the FSM's next step q Id"
        print "parameter FSM_q: the instance of some q "
        print "parameter state_piece: a piece of state "
        print"======================================================="
        print "Number 7"
        print "Function Name:Get_FSM_q(self,q_number,FSM_qs)"
        print "purpose: get the FSM_q instance based on input q Id"
        print "parameter FSM_q: a set of instances of some q "
        print "parameter q_number: the id of q"
        print"======================================================="
        print "Number 8"
        print "Function Name:Run_FSM(self,FSM,state)"
        print "purpose: get the action by run FSM"
        print "parameter FSM: a instance of FSM "
        print "parameter state: environment state"
        print"======================================================="
        print "Number 9"
        print "Function Name:Candidate_selection(self,state)"
        print "purpose: select the candidates"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 10"
        print "Function Name:PA_Calculation(self,state)"
        print "purpose: calculate the PA prediction array"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 11"
        print "Function Name:Choose_Action(self,state)"
        print "purpose: choose the action"
        print "parameter state: the state for use from environment"
        print"======================================================="
        print "Number 12"
        print "Function Name:Get_Action(self,state)"
        print "purpose: Get the action"
        print "parameter state: one condition of the environments"
        print"======================================================="
        print "Number 13"
        print "Function Name:Get_active_action_basedon_list(self,FSM)"
        print "purpose: get the list of q which is active"
        print "parameter FSM: a set of instances of q"
        print"======================================================="
        print "Number 14"
        print "Function Name:Run_FSM_basedon_list(self,FSM,state)"
        print "purpose: get the action by run FSM"
        print "parameter FSM: a instance of FSM "
        print "parameter state: environment state"
        print"======================================================="

class env_Mapping:
    #Number1
    def convert_int_condition(self,state):
        for i in range(0,len(state)):
            state[i]=int(state[i])
        return state

    #number2
    def convert_int_condition_new(self,state):
        result=[0]*len(state)
        for i in range(0,len(state)):
            result[i]=int(state[i])
        return result

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:convert_int_condition(self,state)"
        print "purpose: convert the env state into int[] type"
        print "parameter state: the state come from env"
        print"======================================================="
        print "Number 2"
        print "Function Name:convert_int_condition_new(self,state)"
        print "purpose: convert the env state into int[] type return a new instance"
        print "parameter state: the state come from env"
        print"======================================================="

class Mapping:
    def __init__(self):
        self.basic_config=Basic_Config()

    #number1 important
    def Get_Action(self,state,agent):
        if agent.Type==self.basic_config.Agent_Type[1]:
            M_F=xcscfc_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[2]:
            M_F=xcsCFA_SSP_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[3]:
            M_F= xcs_SSP_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[4]:
            M_F= xcsSMA_v2_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[5]:
            M_F= xcsf_Boolean_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[6]:
            M_F= xcsSMA_v2_adder_Mapping_Function(agent)
            return M_F.Get_Action(state)
        elif agent.Type==self.basic_config.Agent_Type[8]:
            M_F= xcscfunctions_Mapping_Function(agent)
            return M_F.Get_Action(state)


    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:Get_Action(self,state,agent)"
        print "purpose: get the agent action"
        print "parameter state: the state come from env"
        print "parameter agent: the agent come from agent pool"
        print"======================================================="

#agent_O=xcsCFCavg_Translate('Test_0')
#use_agent=agent_O.Get_Mapped_Agent()
#M_F=xcscfc_Mapping_Function(use_agent[0])
#M_F.Test()
#Test_Message=['0','0','0','0','0','0','0','0','0','0','0']
#result=M_F.Get_Action(Test_Message)
#print 'r',result

#xcscfa=Read_Agents('XcsSMA_v2_Test')
#use_agent=xcscfa.Read_Agent()
#use_agent[0].Agent.xcs_SMA[-1].FSM.FSM_q[-1].Test()
#M_F=xcsSMA_v2_Mapping_Function(use_agent[0])
#M_F.Test()
#print 'Hello'


test_address='I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXCFS_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXRules_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXUseRul_10000.txt'
x=Read_Agents(test_address)
result=x.Read_Agent()
#result[0].Test()
Test_Message=['0','0','0','0','0','0','0','0','0','0','0']
Test_Message=['0', '0', '0', '1', '0', '1', '1', '0', '0', '0', '1']
m=xcscfunctions_Mapping_Function(result[0])
r=m.Get_Action(Test_Message)
print r






