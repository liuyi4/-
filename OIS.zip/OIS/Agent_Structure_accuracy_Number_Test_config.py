﻿from Agent_Basic_Test_Config import Agent_Basic_Test_Config
class Agent_Structure_accuracy_Number_Test_config:
    def __init__(self):
        self.basic_config=Agent_Basic_Test_Config()
        self.change_rate=80

        self.result_Address=self.basic_config.result_Address
        self.Agent_fit_Address="fit.txt"

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:change_rate"
        print "purpose: the rate for change Agent"
        print ("value",self.change_rate)