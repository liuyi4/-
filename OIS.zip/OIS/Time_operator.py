import time
class Timer:
    def Get_Time_Now(self):
        return time.time()