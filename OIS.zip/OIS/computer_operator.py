﻿import math
import types
class computer_operator:
    #number1
    def AND(self,input1,input2):
        return input1 and input2

    #number2
    def OR(self,input1,input2):
        return input1 or input2

    #number3
    def NOT(self,input):
        return int(not input)

    #number4
    def NOR(self,input1,input2):
        return int( not(input1 or input2))

    #number5
    def NAND(self,input1,input2):
        return int(not(input1 and input2))

    #number6
    def Add(self,input1,input2):
        return float(input1+input2)

    #number7
    def substract(self,input1,input2):
        return float(input1-input2)

    #number8
    def times(self,input1,input2):
        return float(input1*input2)

    #number9
    def division(self,input1,input2):
        return float(input1/input2)

    #number10
    def remainder(self,input1,input2):
        return float(input1%input2)

    def OPFLR(self,value):
        return math.floor(value)

    def OPCLG(self,value):
        return math.ceil(value)
    
    def OPNLG(self,value):
        return math.log(value,2)

    def CONST_LEN(self,state):
        return len(state)

    def OPBINSTR(self,state,value):
        #return bin(value)[2:]
        value=int(value)
        return state[:value]

    def OPPLUS(self,input1,input2):
        if type(input1) is types.StringType:
            input1=int(input1,2)
        if type(input2) is types.StringType:
            input2=int(input2,2)
        return float(input1+input2)

    #number7
    def OPMINUS(self,input1,input2):
        if type(input1) is types.StringType:
            input1=int(input1,2)
        if type(input2) is types.StringType:
            input2=int(input2,2)
        return float(input1-input2)

    #number8
    def OPMUL(self,input1,input2):
        if type(input1) is types.StringType:
            input1=int(input1,2)
        if type(input2) is types.StringType:
            input2=int(input2,2)
        return float(input1*input2)

    #number9
    def OPDIV(self,input1,input2):
        if type(input1) is types.StringType:
            input1=int(input1,2)
        if type(input2) is types.StringType:
            input2=int(input2,2)
        return float(input1/input2)

    """
    def OPPOW2LOOP(self,value_1,value_2):
        test_state=None
        test_value=-1
        if type(value_1) is types.StringType:
            test_state=value_1
            test_value=value_2
        elif type(value_2) is types.StringType:           
            test_state=value_2
            test_value=value_1
        else:
            return 0
        if test_value>len(test_state):
            return 0
        if test_value<0:
            return 0
        return int(test_state[int(math.fabs(test_value-len(test_state))):],2)
        #print math.fabs(test_value-len(test_state))
    """
    def OPPOW2LOOP(self,value_2,value_1):
        #print trees[0],'  ',trees[1],'  ',trees[2] 
        #print value_1,"=====",value_2
        test_state=None
        test_value=-1
        if type(value_1)  is not types.IntType:
            value_1=int(value_1,2)

        if type(value_2) is not types.StringType:           
            value_2=bin(value_2)[2:]

        test_state=value_2
        test_value=value_1
        
        if test_value>len(test_state):
            return int(test_state,2)

        if test_value<0:
            test_value=0
        
        if test_value==0:
            return 0
        else:
            return int(test_state[int(math.fabs(test_value-len(test_state))):],2)
    
            
    def OPVAL(self,state,value):
        if int(value)<0:
            value=0
        if int(value)>(len(state)-1):
            value=len(state)-1
        return int(state[int(value)])
     
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: AND(self,input1,input2)"
        print "purpose: generate the result of input1 and inputi2"
        print "parameter input1: a bit 0 or 1"
        print "parameter input2: a bit 0 or 1"
        #result=self.AND(1,1)
        #print result
        print"======================================================="
        print "Number 2"
        print "Function Name: OR(self,input1,input2)"
        print "purpose: generate the result of input1 or inputi2"
        print "parameter input1: a bit 0 or 1"
        print "parameter input2: a bit 0 or 1"
        #result=self.OR(0,0)
        #print result
        print"======================================================="
        print "Number 3"
        print "Function Name: NOT(self,input)"
        print "purpose: generate the result of not inputi"
        print "parameter input: a bit 0 or 1"
        #result=self.NOT(1)
        #print result
        print"======================================================="
        print "Number 4"
        print "Function Name: NOR(self,input1,input2)"
        print "purpose: generate the result of not (input1 or inputi2)"
        print "parameter input1: a bit 0 or 1"
        print "parameter input2: a bit 0 or 1"
        #result=self.NOR(0,0)
        #print result
        print"======================================================="
        print "Number 5"
        print "Function Name: NAND(self,input1,input2)"
        print "purpose: generate the result of not (input1 and inputi2)"
        print "parameter input1: a bit 0 or 1"
        print "parameter input2: a bit 0 or 1"
        #result=self.NAND(0,0)
        #print result
        print"======================================================="
        print "Number 6"
        print "Function Name:  Add(self,input1,input2)"
        print "purpose: generate the result of add (input1 and inputi2)"
        print "parameter input1: a float number"
        print "parameter input2: a float number"
        print"======================================================="
        print "Number 7"
        print "Function Name:  substract(self,input1,input2)"
        print "purpose: generate the result of substract (input1 and inputi2)"
        print "parameter input1: a float number"
        print "parameter input2: a float number"
        print"======================================================="
        print "Number 8"
        print "Function Name:  times(self,input1,input2)"
        print "purpose: generate the result of times (input1 and inputi2)"
        print "parameter input1: a float number"
        print "parameter input2: a float number"
        print"======================================================="
        print "Number 9"
        print "Function Name:  division(self,input1,input2)"
        print "purpose: generate the result of division (input1 and inputi2)"
        print "parameter input1: a float number"
        print "parameter input2: a float number"
        print"======================================================="
        print "Number 10"
        print "Function Name:  remainder(self,input1,input2)"
        print "purpose: generate the result of remainder (input1 and inputi2)"
        print "parameter input1: a float number"
        print "parameter input2: a float number"
        print"======================================================="
        print self.OPPOW2LOOP(2,'11111111111111111111')

#o=computer_operator()
#o.Test()