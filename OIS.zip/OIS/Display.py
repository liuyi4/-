﻿import numpy as np
import matplotlib.pyplot as p_
class display:
    def __init__(self):
        self.fit_txt='result\\fit.txt'
    
    #number 1    
    def Read_Txt(self,address):
        reader=open(address,'r')
        information=[]
        for lines in reader:
            if lines!=None:
                information.append(lines)
        return information
    
    #number2
    def split_data(self,information):
        data_x=[]
        data_y=[]
        for i in range(0,len(information)):
            result_0=information[i].split('\n')
            result=result_0[0].split('_')
            data_x.append(result[0])
            data_y.append(result[1])
        return data_x,data_y
    
    #number3
    def Drew_fit(self,data_1,data_2): 
        font={'family':'serif','color':'red','weight':'normal','size':16,}
        p_.ylim(100,140)
        p_.plot(data_1,data_2,'o')
        p_.plot(data_1,data_2,'--')
        p_.ylabel('X----> the quantity of question it can solve',fontdict=font)
        p_.xlabel('Y----> the number of the agent',fontdict=font)
        p_.title("Picture for the virtual agent and conditions it can solve",size=10,color='purple')
        
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name: Read_Txt(self,address)"
        print "Purpose: return the information in txt"
        print "parameter address: the path of the txt"
        result=self.Read_Txt(self.fit_txt)
        #for i in result:
        #    print i
        print"======================================================="
        print "Number 2"
        print "Name: split_data(information)"
        print "Purpose: split the information in txt"
        print "parameter informaion: the data of the txt"
        result_0=self.split_data(result)
        print"======================================================="
        print "Number 3"
        print "Name:Drew_fit(self,data_1,data_2)"
        print "Purpose: drew the picture"
        print "parameter data_1: the data you'll use"
        print "parameter data_2: the data you'll use"
        self.Drew_fit(result_0[0],result_0[1])
        
class display_accuracy:
    def __init__(self,I_address):
        self.dis=display()
        #self.address= 'result\\accuracy_01.txt' 
        self.address=I_address
        self.information=self.dis.Read_Txt(self.address)
        self.instances=self.split_data()
        
    def count_numbers(self,array):
        dic={}
        for item in array:
            if item in dic.keys():
                dic[item]+=1
            else:
                dic[item]=1
        return dic
        
    def split_data(self):
        results=[]
        useful_data=[]
        for i in range(0,len(self.information)):
            result_0=self.information[i].split('\n')
            result=result_0[0].split(' ')
            useful_data.append(result)
        for data in useful_data:
            result=basic_accuracy()
            for i in range(0,len(data)):                
                if 'agent_Id:' in data[i]:
                    result.agent_Id=data[i+1]
                elif 'agent:'in data[i]:
                    result.agent=data[i+1]
                elif 'agent_questions:' in data[i]:
                    result.agent_questions=data[i+1]
                elif 'length:' in data[i]:
                     result.length=int(data[i+1])
                elif 'right:' in data[i]:
                     result.right=int( data[i+1])
                elif 'question_type:' in data[i]:
                     result.question_type =data[i+1]
                elif 'accuracy:' in data[i]:
                     result.accuracy=float(data[i+1])
                elif 'total_time:' in data[i]:
                     result.total_time=float(data[i+1])
            results.append(result)  
        return results

    def Get_accuracy_Number(self):
        x=[]
        y=[]
        for ins in self.instances:
            x.append(ins.accuracy)
            y.append(ins.length)
        return y,x
        
    def Drew_Test(self): 
        data_1,data_2=self.Get_accuracy_Number()
        font={'family':'serif','color':'red','weight':'normal','size':16,}
        #p_.ylim(0.7,1.2)
        p_.plot(data_1,data_2,'o')
        p_.plot(data_1,data_2,'--')
        p_.ylabel('X----> the accuracy of the test',fontdict=font)
        p_.xlabel('Y----> the number of the test questions',fontdict=font)
        data="Picture for the accuracy test\n"
        data_1='Agent Type:  '+self.instances[0].agent+'\n'
        data_1_1='agent Question Type: '+self.instances[0].agent_questions+'\n'
        data_2='environment Question Type: '+self.instances[0].question_type+'\n'
        to_time=0
        to_length=0
        to_Right=0
        for inss in self.instances:
            to_time=to_time+inss.total_time
            to_length=to_length+inss.length
            to_Right=to_Right+inss.right
        data_3='Total Time: '+str(to_time)    +'s\n'
        data_4='Total environment instances: '+str(to_length)+'\n'
        data_4_1='Total right prediction: '+str(to_length)+'\n'
        data_5='once_run Time: '+str(to_time/to_length)    +'s\n'
        result_data=data+data_1+data_1_1+data_2+data_3+data_4+data_4_1+data_5
        p_.title(result_data,size=15,color='purple')
        #for inf in self.information:
        #    print inf
        
        
    def Test(self):
        print"======================================================="
        #print self.information
        self.Drew_Test()
        
        
        
class basic_accuracy:
    def __init__(self):
        self.agent_Id=None
        self.agent=None
        self.agent_questions=None
        self.right=None
        self.length=None
        self.question_type=None
        self.accuracy=None
        self.total_time=None
        
    def Test(self):
        print self.agent_Id,'agent_Id'
        print self.agent,'agent'
        print self.agent_questions,'agent_questions'
        print self.right,'right'
        print self.length,'length'
        print self.question_type,'question_type'
        print self.accuracy,'accuracy'
        print self.total_time,'total_time'
#d=display_accuracy('result\\saved\\accuracy_11.txt')
#d.Test()
class Graph_Use:
    def __init__(self):
        #self.fit_txt='thefile_0.txt'
        #self.fit_txt='thefile_1.txt'
        #self.fit_txt='thefile_2.txt'
        #self.fit_txt='thefile_3.txt'
        #self.fit_txt='thefile_4.txt'
        self.fit_txt='thefile_5.txt'
        self.information=self.Read_Txt(self.fit_txt)
        self.x,self.y=self.split_data(self.information)
        self.Drew_Test()
        #self.Drew_Test2()
    
    def Read_Txt(self,address):
        reader=open(address,'r')
        information=[]
        for lines in reader:
            if lines!=None:
                information.append(lines)
        return information
        
    def split_data(self,information):
        data_x=[]
        data_y=[]
        for i in range(0,len(information)):
            result_0=information[i].split('\n')
            result=result_0[0].split('_')
            data_x.append(result[0])
            data_y.append(result[-1])
        return data_x,data_y  
        
    def Drew_Test(self): 
        font={'family':'serif','color':'red','weight':'normal','size':16,}
        #p_.ylim(0.75,1.1)
        #p_.ylim(0.6,1.1)
        p_.ylim(0.0,1.1)
        p_.xlim(0,105)
        p_.plot(self.x,self.y,'o')
        p_.plot(self.x,self.y,'--')
        
        #limit_x=[100,100]
        #limit_y=[0.964563841734,0.995436158266]
        #average_accuracy_x=102
        #average_accuracy_y=0.98
        
        #limit_x=[100,100]
        #limit_y=[1.0,1.0]
        #average_accuracy_x=102
        #average_accuracy_y=1.0

        #limit_x=[100,100]
        #limit_y=[0.932580655734 , 0.979419344266]
        #average_accuracy_x=102
        #average_accuracy_y=0.956
        
        #limit_x=[100,100]
        #limit_y= [0.938730359612, 0.983269640388]
        #average_accuracy_x=102
        #average_accuracy_y=0.961
        
        #limit_x=[101,101]
        #limit_y= [ 0.479781878159 ,0.584218121841]
        #average_accuracy_x=102
        #average_accuracy_y=0.532
        
        limit_x=[101,101]
        limit_y= [0.463574731891, 0.556425268109]
        average_accuracy_x=102
        average_accuracy_y=0.51
        
        p_.plot(limit_x,limit_y,'o')
        p_.plot(limit_x,limit_y,'-')
        p_.plot(average_accuracy_x,average_accuracy_y,'o',color='Black')
        p_.ylabel('accuracy ',fontdict=font)
        p_.xlabel('iterations',fontdict=font)
        data="Picture for the accuracy and confidence interval\n"
        #data_1='Agent Type:  '+'xcs_SMA'+'\n'
        data_1='Agent Type:  '+'xcs'+'\n'
        #data_1_1='agent Question Type: '+'multiplex'+'\n'
        #data_2='environment Question Type: '+'multiplex'+'\n'
        #data_1_1='agent Question Type: '+'carry'+'\n'
        #data_2='environment Question Type: '+'carry'+'\n'
        data_1_1='agent Question Type: '+'hiddenoddparity'+'\n'
        data_2='environment Question Type: '+'hiddenoddparity'+'\n'
        data_3='Blue points means the accuracy with each test'+'\n'
        data_4='Red points means the confidence interval'+'\n'
        data_5='the purple point means the average accuracy'+'\n'
        result_data=data+data_1+data_1_1+data_2+data_3+data_4+data_5
        #p_.title(result_data,size=15,color='purple')
        
    def Drew_Test2(self):
        font={'family':'serif','color':'red','weight':'normal','size':16,}
        p_.ylim(0.4,1.1)
        p_.xlim(0,11000)
        #p_.xlim(9000,31000)
        Test_x=[1000,1000,2000,2000,3000,3000,4000,4000,5000,5000,6000,6000,7000,7000,8000,8000,9000,9000,10000,10000]
        #Test_x=[10000,10000,20000,20000,30000,30000]
        #Test_y=[0.807554496603, 0.880445503397,0.864703131932, 0.925296868068,0.924459657058, 0.967540342942,
        #0.966508385025, 0.995491614975,0.9933926, 1.00,1.0, 1.0,1.0 ,1.0,1.0 ,1.0 ,1.0 ,1.0,1.0 ,1.0  ]
        #Test_y=[0.834477001021, 0.901522998979,0.901101241388, 0.950898758612,0.97193499471, 0.99606500529,
        #0.989550983405 ,1.00244901659,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0  ]
        #Test_y=[0.449855991655, 0.548144008345,0.481538095201, 0.562461904799,0.578393897206 ,0.667606102794,
        #0.453936446944, 0.556063553056,0.528268928052 ,0.613731071948,0.595784884426, 0.692215115574,0.576984473023 ,0.685015526977, 
        #0.668837932382, 0.761162067618,0.621835250763, 0.716164749237,0.683883824232, 0.780116175768]
        #Test_y=[0.683883824232, 0.780116175768,0.93942623827, 0.98657376173,0.970637924571, 0.995362075429]
        Test_y=[0.90717481695, 0.96082518305,0.995725496344, 1.00227450366,1.0,1.0,1.0,1.0,1.0,1.0,
                1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,]
        p_.ylabel('confidence interval',fontdict=font)
        p_.xlabel('instances',fontdict=font)
        p_.plot(Test_x,Test_y,'o',color='Red')
        for i in range(0,len(Test_x)/2):
            x=[]
            y=[]
            x.append(Test_x[2*i])
            x.append(Test_x[2*i+1])
            y.append(Test_y[2*i])
            y.append(Test_y[2*i+1])
            p_.plot(x,y,'-',color='green')
        data="Picture for the confidence interval and number of max problems\n"
        #data_1='Agent Type:  '+'xcs'+'\n'
        #data_1='Agent Type:  '+'xcs SMA'+'\n'
        #data_1='Agent Type:  '+'xcs CFC'+'\n'
        data_1='Agent Type:  '+'xcs CFA'+'\n'
        data_1_1='agent Question Type: '+'multiplex'+'\n'
        data_2='environment Question Type: '+'multiplex'+'\n'
        data_3='Blue points and green lines means the confidence interval with each test'+'\n'
        result_data=data+data_1+data_1_1+data_2+data_3
        #p_.title(result_data,size=15,color='purple')
   
g=Graph_Use()