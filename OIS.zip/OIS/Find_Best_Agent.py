﻿from Agent_Pools import Read_Agents
from Environment_Selection_Machine import Environment_Selection_Machine_V2
from environment_machine import environment_machine
from Basic_Config import Basic_Config
from Mapping_Function import Mapping
from T_table import T_table
import random
import os
import shutil
from Time_operator import Timer
import math

class Confidence_interval:
    def __init__(self):
        self.T_table=T_table()
        
    #Number1
    def Calculate_average(self,input_list):
        total=0.0
        for value in input_list:
            total=total+value
        return total/len(input_list)

    #Number2
    def Calculate_Population_Standard_deviation(self,population_list):
        average=self.Calculate_average(population_list)
        sum=0.0
        for value in population_list:
            sum=sum+(value-average)**2
        variance=sum/len(population_list)
        Standard_deviation=math.sqrt(variance)
        return Standard_deviation

    #Number3
    def Calculate_Sample_Standard_deviation(self,sample_list):
        average=self.Calculate_average(sample_list)
        sum=0.0
        for value in sample_list:
            sum=sum+(value-average)**2
        variance=sum/len(sample_list)
        Standard_deviation=math.sqrt(variance)
        return Standard_deviation

    #Number4
    def Calculate_T(self,Hypothesis,sample_list):
        average_x=self.Calculate_average(sample_list)
        N=len(sample_list)
        S=self.Calculate_Sample_Standard_deviation(sample_list)
        if S!=0:
            t=(average_x-Hypothesis)/(S*math.sqrt(N))
            t=math.fabs(t)
        else:
            t=0
        return t

    #Number5
    def Get_confidence(self,Hypothesis,sample_list):
        t=self.Calculate_T(Hypothesis,sample_list)
        confidence=self.T_table.Get_T_Confidence_One_Tail(t,len(sample_list))
        return confidence

    #Number6
    def Get_Confidence_interval(self,accuracy_list):
        Z_list=self.T_table.T_table[-1]
        average_x=self.Calculate_average(accuracy_list)
        s=self.Calculate_Sample_Standard_deviation(accuracy_list)
        z=Z_list[-1]
        max=average_x+((s/math.sqrt(len(accuracy_list)))*z)
        min=average_x-((s/math.sqrt(len(accuracy_list)))*z)
        #if max>1:
        #    max=1.0
        #if min<0:
        #    min=0
        return min,max

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: Calculate_average(self,input_list)"
        print "purpose: calculate the average"
        print"======================================================="
        print "Number 2"
        print "Function Name: Calculate_Population_Standard_deviation(self,population_list)"
        print "purpose: calculate the standard deviation Z Test"
        print"======================================================="
        print "Number 3"
        print "Function Name: Calculate_Sample_Standard_deviation(self,sample_list)"
        print "purpose: calculate the standard deviation T Test"
        print"======================================================="
        print "Number 4"
        print "Function Name: Calculate_T(self,Hypothesis,sample_list)"
        print "purpose: calculate the T"
        print"======================================================="
        print "Number 5"
        print "Function Name: Get_confidence(self,Hypothesis,sample_list)"
        print "purpose: calculate the confidence"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_Confidence_interval(self,accuracy_list)"
        print "purpose: calculate confidence interval"
        print"======================================================="

class Confidence_env_builder:
    def __init__(self,I_address,I_length):
        self.address=I_address
        self.individual_Test_Length=20
        self.population_size=I_length
        self.sample_size=16
        self.generate_envs=self.Read_Environments()
        self.Training_Population_envs=self.Get_Population_environments()
        #self.Training_Sample_envs=self.Get_Sample_environments()

    #Number1
    def Read_Environments(self):
        S_M_2=Environment_Selection_Machine_V2(self.address)
        environments=S_M_2.Get_environments()
        result=[]
        for env in environments:
            for cods in env.Conditions:
                result.append(cods)
        return result
     
    #Number2
    def Get_Population_environments(self):
        result=[]
        if len(self.generate_envs)<= self.individual_Test_Length:
            result.append(self.generate_envs)
            return result 

        for i in range(0,self.population_size):
                num =random.randint(0,(len(self.generate_envs)-self.individual_Test_Length))
                use_env=[]
                for j in range(0,self.individual_Test_Length):
                    use_env.append(self.generate_envs[num])
                    num=num+1
                result.append(use_env)
        return result

    #Number3
    def Get_Sample_environments(self):
        result=[]
        if len(self.generate_envs)<= self.individual_Test_Length:
            result.append(self.generate_envs)
            return result 
        for i in range(0,self.sample_size):
                num =random.randint(0,len(self.generate_envs)-self.individual_Test_Length)
                use_env=[]
                for j in range(0,self.individual_Test_Length):
                    use_env.append(self.generate_envs[num])
                    num=num+1
                result.append(use_env)
        return result

    def Test(self):
        for T in self.Training_Population_envs:
            print'-------------------------'
            for t in T:
                t.Test() 
        print'-------------------------'
        print len(self.Training_Population_envs)
        print len(self.Training_Population_envs[0])
        for T in self.Training_Sample_envs:
            print'-------------------------'
            for t in T:
                t.Test() 
        print'-------------------------'
        print len(self.Training_Sample_envs)
        print len(self.Training_Sample_envs[0])
        print"======================================================="
        print "Number 1"
        print "Function Name: Read_Environments(self)"
        print "purpose: read the environments"
        print"======================================================="
        print "Number 2"
        print "Function Name:  Get_Population_environments(self)"
        print "purpose: split the environments"
        print"======================================================="
        print "Number 3"
        print "Function Name:Get_Sample_environments(self)"
        print "purpose: return the test sample teams"
        print"======================================================="

class Agent_Reader:
    def __init__(self,I_Address):
        self.Address=I_Address#number1
        self.MyAgents=self.Read_Agents()#number2

    #number3
    def Read_Agents(self):
        Reader=Read_Agents(self.Address)
        MyAgents=Reader.Read_Agent()
        return  MyAgents

    #number4
    def Get_Agent(self):
        return self.MyAgents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Address"
        print "purpose: the agent pool address "
        print"======================================================="
        print "Number 2"
        print "Name:MyAgents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 3"
        print "Name: Read_Agents(self)"
        print "purpose: read the agent"
        print"======================================================="
        print "Number 4"
        print "Function Name:Get_Agent(self)"
        print "purpose: get the agent "
        print"======================================================="

class environment_Recognise:
    def __init__(self,I_address):
        self.address=I_address#number1
        self.max_k=2#number2
        self.k_count=0#number3
        self.Test_leng=60#number4
        self.step=20#number5
        self.size=10#number6
        self.envs=self.Get_environment()#number7
        self.length=len(self.envs[0].state)
    #number8   
    def Get_environment(self):
        S_M_2=Environment_Selection_Machine_V2(self.address)
        environments=S_M_2.Get_environments()
        result=[]
        for env in environments:
            for cods in env.Conditions:
                result.append(cods)
        return result

    #number9
    def Get_Use_environments_base(self):       
        result=[]
        if len(self.envs)<=self.Test_leng:
            result.append(self.envs)
            return result

        if len(self.envs)<=(self.Test_leng*self.size):
            num=0
            use_size=int(len(self.envs)/self.Test_leng)
            for i in range(0,use_size):
                use_env=[]
                for j in range(0,self.Test_leng):
                    use_env.append(self.envs[num])
                    num=num+1
                result.append(use_env)
            return result

        if len(self.envs)>(self.Test_leng*self.size):
            num=0
            for i in range(0,self.size):
                use_env=[]
                for j in range(0,self.Test_leng):
                    use_env.append(self.envs[num])
                    num=num+1
                result.append(use_env)
            return result
    
    #number10                  
    def Get_Use_environments_Random(self):
        result=[]
        if len(self.envs)-self.Test_leng<=0:
            result.append(self.envs)
            return result

        if len(self.envs)-self.Test_leng>0:
            for i in range(0,self.size):
                use_env=[]
                num =random.randint(0,len(self.envs)-self.Test_leng)
                for j in range(0,self.Test_leng):
                    use_env.append(self.envs[num])
                    num=num+1
                result.append(use_env)
            return result

    #number11
    def Recognise_envs(self):
        if self.k_count>self.max_k:
            return False,None
        select=random.randint(0,1)
        if select==0:
            envs=self.Get_Use_environments_base()
        else:
            envs=self.Get_Use_environments_Random()
        self.k_count=self.k_count+1
        self.Test_leng=self.Test_leng-self.step
        return True,envs

    #number12
    def Set_Max_k(self,value):
        self.max_k=value
    

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Address"
        print "purpose: the agent pool address "
        print"======================================================="
        print "Number 2"
        print "Name:max_k"
        print "purpose: the max k times to get the envs"
        print"======================================================="
        print "Number 3"
        print "Name: k_count"
        print "purpose: how many time you have already generate the envs"
        print"======================================================="
        print "Number 4"
        print "Function Name:Test_leng"
        print "purpose: get the length of the test env "
        print"======================================================="
        print "Number 5"
        print "Name:step"
        print "purpose: every step add length "
        print"======================================================="
        print "Number 6"
        print "Name:size"
        print "purpose: the size of the envs"
        print"======================================================="
        print "Number 7"
        print "Name: envs"
        print "purpose: the envs from env pool"
        print"======================================================="
        print "Number 8"
        print "Function Name:Get_environment(self)"
        print "purpose: get the envs from pool "
        print"======================================================="
        print "Number 9"
        print "Name: Get_Use_environments_base(self)"
        print "purpose: get the basic envs "
        print"======================================================="
        print "Number 10"
        print "Name:Get_Use_environments_Random(self)"
        print "purpose: get the random envs"
        print"======================================================="
        print "Number 11"
        print "Name: Recognise_envs(self)"
        print "purpose: try to recognise the envs"
        print"======================================================="
        print "Number 12"
        print "Function Name:Set_Max_k(self,value)"
        print "purpose: set the max k default is 3 "
        print"======================================================="

class environment_learning:

    def __init__(self,I_Address):
        #self.Address='learning_envs'#number1
        #self.Address='S_env'
        self.Address=I_Address
        S_M_2=Environment_Selection_Machine_V2(self.Address)#number2
        self.environments=S_M_2.Get_environments()

    #number3
    def Get_envs(self):
        return self.environments

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Address"
        print "purpose: the agent pool address "
        print"======================================================="
        print "Number 2"
        print "Name:environments"
        print "purpose: the envs from pool"
        print"======================================================="
        print "Number 3"
        print "Name:Get_envs(self)"
        print "purpose: get the envs"

class build_knowledge:
    def __init__(self,I_address,I_set=1):
        e_l=environment_learning(I_address)
        self.use_time=Timer()
        self.MP=Mapping()       
        self.save_address='knowledge\\my_knowledge.txt'
        self.save_folder='knowledge'
        self.basic_config= Basic_Config()
        self.Agent_Pool_Name=self.basic_config.Agent_Pool_Address+'\\'+'COMBINE_ALL'   
        #self.Agent_Pool_Name=self.basic_config.Agent_Pool_Address+'\\'+'combine_Test'   
        self.Judge_Is_Exist()
        self.Judge_Pool_Address_Is_Exist()
        if I_set==0:
            self.my_know=self.Read_Knowledge()
        else:
            self.my_know=self.Read_Knowledge_with_confidence_interval()
        self.Agent_Address=self.Get_Use_Agent_Name()
        self.N=100#Z test sample teams
        self.condition_length=10#the size of the team
        self.set=I_set
        
        if len(self.Agent_Address)>0:
            print'begin read environments'
            self.envs=e_l.Get_envs()
            self.env_length=self.Calculate_env_length()
            print'finish reading environments'
            self.Use_Agents=self.Get_Agents()
            self.write_information()
            print 'work complete'
    
    #Number1    
    def write_information(self):
        file_object = open(self.save_address)
        try:
            all_the_text = file_object.read( )
        finally:
            file_object.close( )
        if self.set==0:
            datas=self.Get_Result()
        else:
            datas=self.Get_Result_with_confidence_interval()

        file_object = open(self.save_address, 'w')
        file_object.write(all_the_text+datas)
        file_object.close( )

    #Number2
    def Judge_Is_Exist(self):
        if not os.path.exists(self.save_folder):
            os.makedirs(self.save_folder)
        if not os.path.exists(self.save_address):
            f=open(self.save_address,'w')

    #Number3
    def Judge_Pool_Address_Is_Exist(self):
        if not os.path.exists(self.Agent_Pool_Name):
            os.makedirs(self.Agent_Pool_Name)
    
    #Number4
    def Get_All_Agents_Name(self):
        point_txt='.txt'
        special_Name='xcsCFCavg'
        special_Name_2='xcscfunction'
        special_Name_2_result=[]
        add_result=[]
        result=[]
        for root, dirs, files in os.walk(self.Agent_Pool_Name, True):
            for name in files:
                if point_txt in name and not special_Name in name:
                    result.append(self.Agent_Pool_Name+'\\'+name)
                if special_Name in name:
                    add_result.append(self.Agent_Pool_Name+'\\'+name)
                if special_Name_2 in name:
                    special_Name_2_result.append(self.Agent_Pool_Name+'\\'+name)
        CFs=[]
        rule=[]
        for add in add_result:
            if 'CFs' in add:
                CFs.append(add)
            if 'Rules' in add:
                rule.append(add)
        for cfs in CFs:
            address=''
            point=cfs.split('.')[0].split('_')[-1]
            for rules in rule:
                if point in rules:
                    address=rules+'$$'+cfs
                    result.append(address)

        s_2_cf=[]
        s_2_rule=[]
        s_2_function=[]
        for s_2 in special_Name_2_result:
            if 'CFS' in s_2:
                s_2_cf.append(s_2)
            if 'UseRul' in s_2:
                s_2_rule.append(s_2)
            if 'Rules' in s_2:
                s_2_function.append(s_2)
        for cfs in s_2_cf:
            address=''
            point=cfs.split('.')[0].split('_')[-1]
            for fun in s_2_function:
                if point in fun:
                    address=address+cfs+'$$'+fun
                    for rul in s_2_rule:
                        if point in rul:
                            address=address+'$$'+rul
                            result.append(address)
        return result

    #Number5
    def Read_Knowledge(self):
        knowledges=[]
        read_information=open(self.save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if self.basic_config.Question_Types[i]==data[j]:
                        accuracy[i]=float(data[j+1])
                    elif 'once_running_time'==data[j]:
                        once_running=float(data[j+1])
                    elif 'agent_name' ==data[j]:
                        Name=data[j+1]
                    elif 'question_length'==data[j]:
                        length=float(data[j+1])
            kno=Knowledge()
            kno.Accuracy=accuracy
            kno.one_time_running=once_running
            kno.Name=Name
            kno.Length=length
            kno.Test()
            knowledges.append(kno)
        return knowledges
    
    #Number6        
    def Get_Use_Agent_Name(self):
        Agent_Address=self.Get_All_Agents_Name()
        result=[]
        for add in Agent_Address:
            if self.Is_Unknown_Agent(add):
                result.append(add)
        return result

    #Number7
    def Is_Unknown_Agent(self,address):
        for know in self.my_know:
            if address==know.Name:
                return False
        return True

    #Number8
    def Get_Agents(self):
        result_agents=[]
        for add in self.Agent_Address:
           A_R=Agent_Reader(add)
           Ag= A_R.Get_Agent()
           if Ag!=None and len(Ag)>0:
               for a in Ag:
                result_agents.append(a)
        return result_agents

    #Number9
    def Get_Result(self):
        right=0
        datas=''
        data=''
        for i in range(0,len(self.Use_Agents)):
            if self.env_length==self.Use_Agents[i].Length:
                size=0.0
                time_1=self.use_time.Get_Time_Now()
                for env in self.envs:          
                    for cods in env.Conditions:
                        if cods.actual_action=='False':
                            env_action=0
                        else:
                            env_action=1
                        A_action=self.MP.Get_Action(cods.state,self.Use_Agents[i])
                        if A_action==env_action:
                            right=right+1                
                #data='agent_Id: '+str(i)+' agent: '+self.agent[i].Type+ ' agent_questions: '+self.agent[i].Question+' right: '+str(right)+' length: '+ str(len(env.Conditions))
                    data=data+env.type+' ' + str(float(right)/float(len(env.Conditions)))+' ' 
                    size=size+len(env.Conditions)
                    question_length=len(env.Conditions[0].state)
                    right=0
                time_2=self.use_time.Get_Time_Now()
                total_time=time_2-time_1
                once_running=total_time/size
                data='agent_name '+self.Use_Agents[i].Name+ ' question_length '+str(question_length)+' ' +data +' once_running_time '+str(once_running)
                print data
                datas=datas+data+'\n'
                data=' '              
        return datas  
     
    #Number10
    def Calculate_env_length(self):
        if len(self.envs)>0:
            if self.envs[0]!=None:
                return len(self.envs[0].Conditions[0].state)

    #Number11
    def Get_Result_with_confidence_interval(self):
        right=0
        datas=''
        data=''
        works=''
        c_M=Confidence_interval()
        for i in range(0,len(self.Use_Agents)):
            if self.env_length==self.Use_Agents[i].Length:
                size=0.0
                time_1=self.use_time.Get_Time_Now()
                for j in range(0,len(self.envs)):
                    envs=self.split_envs(j)
                    accuracys=[]
                    k=0
                    for env in envs:          
                        for cods in env:
                            if cods.actual_action=='False':
                                env_action=0
                            else:
                                env_action=1
                            A_action=self.MP.Get_Action(cods.state,self.Use_Agents[i])
                            if A_action==env_action:
                                right=right+1
                        accuracy=float(right)/float(len(env))
                        work= str(k) +' _'+str(accuracy)
                        k=k+1
                        print work
                        works=works+work+'\n'
                        accuracys.append(accuracy)
                        right=0
                        size=size+len(env)
                    Min,Max=c_M.Get_Confidence_interval(accuracys)
                    average_accuracy=self.Calculate_average_accuracy(accuracys)                
                    data=data+self.envs[j].type+' ' + str(Min)+' ' +str(Max)+' '+str(average_accuracy)+' ' 
                    print data                  
                                            
                time_2=self.use_time.Get_Time_Now()
                total_time=time_2-time_1
                once_running=total_time/size
                data='agent_name '+self.Use_Agents[i].Name+ ' question_length '+str(self.env_length)+' ' +data +' once_running_time '+str(once_running)
                print data
                datas=datas+data+'\n'
                data=' ' 
                file_object = open('thefile.txt', 'w')
                file_object.write(works)
                file_object.close( )            
        return datas 
    
    #Number12
    def split_envs(self,i):
        result=[]
        conditions=[] 
        for cods in self.envs[i].Conditions:
            conditions.append(cods)

        for i in range(0,self.N):
                num =random.randint(0,(len(conditions)-self.condition_length))
                use_env=[]
                for j in range(0,self.condition_length):
                    use_env.append(conditions[num])
                    num=num+1
                result.append(use_env)
        return result

    #Number13
    def Calculate_average_accuracy(self,accuracy_list):
        total=0.0
        for  acc in accuracy_list:
            total=total+acc
        return total/self.N  

    #Number14
    def Read_Knowledge_with_confidence_interval(self):
        knowledges=[]
        read_information=open(self.save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[([None]*3) for i in range(len(self.basic_config.Question_Types))]
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if self.basic_config.Question_Types[i]==data[j]:
                        accuracy[i][0]=float(data[j+1])
                        accuracy[i][1]=float(data[j+2])
                        accuracy[i][2]=float(data[j+3])
                    elif 'once_running_time'==data[j]:
                        once_running=float(data[j+1])
                    elif 'agent_name' ==data[j]:
                        Name=data[j+1]
                    elif 'question_length'==data[j]:
                        length=float(data[j+1])
            kno=Knowledge()
            kno.Accuracy=accuracy
            kno.one_time_running=once_running
            kno.Name=Name
            kno.Length=length
            kno.Test()
            knowledges.append(kno)
        return knowledges
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:write_information(self)"
        print "purpose: write the information"
        print"======================================================="
        print "Number 2"
        print "Function Name: Judge_Is_Exist(self)"
        print "purpose: judge the folder is exist"
        print"======================================================="
        print "Number 3"
        print "Function Name:Judge_Pool_Address_Is_Exist(self)"
        print "purpose: judge the pool address is exist"
        print"======================================================="
        print "Number 4"
        print "Function Name:Get_All_Agents_Name(self)"
        print "purpose: get all agents name"
        print"======================================================="
        print "Number 5"
        print "Function Name:Read_Knowledge(self)"
        print "purpose: read the knowledge"
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_Use_Agent_Name(self)"
        print "purpose: get the agents name what will use"
        print"======================================================="
        print "Number 7"
        print "Function Name:Is_Unknown_Agent(self,address)"
        print "purpose: judge it is unknow agent or not"
        print"======================================================="
        print "Number 8"
        print "Function Name: Get_Agents(self)"
        print "purpose: get the agents instance"
        print"======================================================="
        print "Number 9"
        print "Function Name:Get_Result(self)"
        print "purpose: get the results"
        print"======================================================="
        print "Number 10"
        print "Function Name:Calculate_env_length(self)"
        print "purpose: calculate the envs' length"
        print"======================================================="
        print "Number 11"
        print "Function Name:Get_Result_with_confidence_interval(self)"
        print "purpose: get result with confidence interval"
        print"======================================================="
        print "Number 12"
        print "Function Name:split_envs(self,i)"
        print "purpose: split the envs"
        print"======================================================="
        print "Number 13"
        print "Function Name:Calculate_average_accuracy(self,accuracy_list)"
        print "purpose: calculate the average accuracies"
        print"======================================================="
        print "Number 14"
        print "Function Name:Read_Knowledge_with_confidence_interval(self)"
        print "purpose: read knowledge with confidence interval"
        print"======================================================="

class Knowledge:
    def __init__(self):
        self.Name=None
        self.Accuracy=None
        self.one_time_running=None
        self.Length=None

    def Test(self):
        print 'Name',self.Name
        print 'Accuracy',self.Accuracy
        print 'once_time_running',self.one_time_running
        print 'length',self.Length

#e=environment_machine()
#e.Add_One_Environment(0,3000,11)
class build_percept:
    def __init__(self,I_set=1):
        self.discuss_value=0.05#threshould
        self.use_K=5#for Knn
        self.predict_correct=0.8#threshold
        self.save_address='percept\\my_percept.txt'
        self.save_folder='percept'
        self.basic_config= Basic_Config()
        self.Agent_save_address='knowledge\\my_knowledge.txt'
        self.Judge_Is_Exist() 
        if I_set==0:       
            self.My_Knowledge=self.Read_Knowledge()
            self.write_information()
        else:
            self.My_Knowledge=self.Read_Knowledge_with_confidence_interval()
            self.write_information_with_confidence_interval()
        #self.write_information()
        #self.Read_percept()
        self.Read_percept_with_confidence_interval()

    #Number1
    def Get_Best_choose(self):
        candidates=self.Get_Candidate()
        result=[]
        for can in candidates:
            one_result=[]
            question_Type=can[0]
            one_result.append(question_Type)
            result_candidate=[]
            for i in range(1,len(can)):
                Best_choose=None
                if len(can[i])>0:
                    Min_Time=can[i][0]
                    for kn in can[i]:
                        if kn.one_time_running<Min_Time.one_time_running:
                            Min_Time=kn
                    Best_choose=Min_Time
                result_candidate.append(Best_choose)
            one_result.append(result_candidate)
            result.append(one_result)
        return result

    #Number2
    def Get_Best_choose_without_time(self):
        candidates=self.Get_Candidate()
        result=[]
        for can in candidates:
            one_result=[]
            question_Type=can[0]
            one_result.append(question_Type)
            result_candidate=[]
            for i in range(1,len(can)):
                Best_choose=None
                if len(can[i])>0:
                    choose=random.randint(0,len(can[i])-1)
                    Best_choose=can[i][choose]
                result_candidate.append(Best_choose)
            one_result.append(result_candidate)
            result.append(one_result)
        return result

    #Number3
    def Read_Knowledge(self):
        knowledges=[]
        read_information=open(self.Agent_save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if self.basic_config.Question_Types[i]==data[j]:
                        accuracy[i]=float(data[j+1])
                    elif 'once_running_time'==data[j]:
                        once_running=float(data[j+1])
                    elif 'agent_name' ==data[j]:
                        Name=data[j+1]
                    elif 'question_length'==data[j]:
                        length=float(data[j+1])
            kno=Knowledge()
            kno.Accuracy=accuracy
            kno.one_time_running=once_running
            kno.Name=Name
            kno.Length=length
            #kno.Test()
            knowledges.append(kno)
        return knowledges

    #Number4
    def Judge_Is_Exist(self):
        if not os.path.exists(self.save_folder):
            os.makedirs(self.save_folder)
        if not os.path.exists(self.save_address):
            f=open(self.save_address,'w')

    #Number5
    def build_condition(self):
        conditions=[]
        for i in range(0,len(self.basic_config.Question_Types)):
            for j in range(0,len(self.basic_config.support_length)):
                list=[i,int(self.basic_config.support_length[j])]
                conditions.append(list)
        return conditions

    #Number6
    def Classify_Knowledge(self):
        result=[]
        for i in range(0,len(self.basic_config.support_length)):
            list=[]
            list.append(int(self.basic_config.support_length[i]))
            for kno in self.My_Knowledge:
                if kno.Length==list[0]:
                    list.append(kno)
            result.append(list)
        return result

    ##Number7
    def Add_max_knowledge(self):
        result=[]
        c_k=self.Classify_Knowledge()
        max_result=[0]*len(self.basic_config.Question_Types)        
        for knows in c_k:
            if len(knows)>0:
                for i in range(1,len(knows)):
                    for j in range (0,len(max_result)):
                        if knows[i].Accuracy[j]>max_result[j]:
                            max_result[j]=knows[i].Accuracy[j]
                knows.append(max_result)
            result.append(knows)
        return result

    #Number8
    def Get_Candidate(self):
        u_k=self.Add_max_knowledge()
        result=[]
        for knows in u_k:
            result_conditions=[]            
            if len(knows)>1:
                question_length=knows[0]
                result_conditions.append(question_length)
                predictions=knows[-1]
                for i in range(0,len(self.basic_config.Question_Types)):
                    conditions=[]
                    for kn in range(1,len(knows)-1):
                        if predictions[i]-self.discuss_value<knows[kn].Accuracy[i] and knows[kn].Accuracy[i]>=self.predict_correct:
                            conditions.append(knows[kn])
                    result_conditions.append(conditions)
                result.append(result_conditions)
        return result

    #Number9
    def Generate_Best_Student(self):
        use_knowledge=self.Get_Best_choose()
        #use_knowledge=self.Get_Best_choose_without_time()
        result=[]
        for u_k in use_knowledge:
            length=u_k[0]
            for i in range(0,len(u_k[1])):
                p=percept()
                p.question_Length=length
                p.question_Type=self.basic_config.Question_Types[i]
                if u_k[1][i]!=None:
                    p.Believe_agent=u_k[1][i].Name
                    p.prediction=u_k[1][i].Accuracy[i]
                #p.Test()
                result.append(p)
        return result

    #Number10
    def Get_data(self):
        percepts=self.Generate_Best_Student()
        datas=''
        for per in percepts:
            data='question_Type '+str(per.question_Type)+' question_length '+str(per.question_Length)+' Believe_Agent '+str(per.Believe_agent) +' prediction '+str(per.prediction)
            datas=datas+data+'\n'
        #print datas
        return datas

    #Number11
    def write_information(self):
        datas=self.Get_data()
        file_object = open(self.save_address, 'w')
        file_object.write(datas)
        file_object.close( )

    #Number12
    def Read_percept(self):
        percepts=[]
        read_information=open(self.save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if 'question_Type'==data[j]:
                        q_t=data[j+1]
                    elif 'question_length'==data[j]:
                        q_l=data[j+1]
                    elif 'Believe_Agent' ==data[j]:
                        Name=data[j+1]
                    elif 'prediction'==data[j]:
                        prediction=data[j+1]
            if Name!='None':
                p=percept()
                p.Believe_agent=Name
                p.prediction=prediction
                p.question_Length=q_l
                p.question_Type=q_t
                p.Test()
                percepts.append(p)
        return percepts

    #Number13
    def Read_Knowledge_with_confidence_interval(self):
        knowledges=[]
        read_information=open(self.Agent_save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[([None]*3) for i in range(len(self.basic_config.Question_Types))]
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if self.basic_config.Question_Types[i]==data[j]:
                        accuracy[i][0]=float(data[j+1])
                        accuracy[i][1]=float(data[j+2])
                        accuracy[i][2]=float(data[j+3])
                    elif 'once_running_time'==data[j]:
                        once_running=float(data[j+1])
                    elif 'agent_name' ==data[j]:
                        Name=data[j+1]
                    elif 'question_length'==data[j]:
                        length=float(data[j+1])
            kno=Knowledge()
            kno.Accuracy=accuracy
            kno.one_time_running=once_running
            kno.Name=Name
            kno.Length=length
            #kno.Test()
            knowledges.append(kno)
        return knowledges

    #Number14
    def Add_max_knowledge_with_confidence_interval(self):
        result=[]
        c_k=self.Classify_Knowledge()
        max_result=[0]*len(self.basic_config.Question_Types)        
        for knows in c_k:
            if len(knows)>0:
                for i in range(1,len(knows)):
                    for j in range (0,len(max_result)):
                        if knows[i].Accuracy[j][2]>max_result[j]:
                            max_result[j]=knows[i].Accuracy[j][2]
                knows.append(max_result)
            result.append(knows)
        return result

    #Number15
    def Get_Candidate_with_confidence_interval(self):
        u_k=self.Add_max_knowledge_with_confidence_interval()
        result=[]
        for knows in u_k:
            result_conditions=[]            
            if len(knows)>1:
                question_length=knows[0]
                result_conditions.append(question_length)
                predictions=knows[-1]
                for i in range(0,len(self.basic_config.Question_Types)):
                    conditions=[]
                    for kn in range(1,len(knows)-1):
                        if predictions[i]-self.discuss_value<knows[kn].Accuracy[i][2] and knows[kn].Accuracy[i][2]>=self.predict_correct:
                            conditions.append(knows[kn])
                    result_conditions.append(conditions)
                result.append(result_conditions)
        #print result
        return result

    #Number16
    def Get_Best_choose_with_confidence_interval(self):
        candidates=self.Get_Candidate_with_confidence_interval()
        result=[]
        for can in candidates:
            one_result=[]
            question_Type=can[0]
            one_result.append(question_Type)
            result_candidate=[]
            for i in range(1,len(can)):
                Best_choose=None
                if len(can[i])>0:
                    Min_Range=can[i][0]
                    for kn in can[i]:
                        # score=kn.Accuracy[i-1][3]*10000
                        if math.fabs( kn.Accuracy[i-1][0]-kn.Accuracy[i-1][1])<math.fabs(Min_Range.Accuracy[i-1][0]-Min_Range.Accuracy[i-1][1]):                            
                            Min_Range=kn
                    Best_choose=Min_Range
                result_candidate.append(Best_choose)
            one_result.append(result_candidate)
            result.append(one_result)
        return result

    #Number17
    def Generate_Best_Student_with_confidence_interval(self):
        use_knowledge=self.Get_Best_choose_with_confidence_interval()
        #use_knowledge=self.Get_Best_choose_without_time()
        result=[]
        for u_k in use_knowledge:
            length=u_k[0]
            for i in range(0,len(u_k[1])):
                p=percept()
                p.question_Length=length
                p.question_Type=self.basic_config.Question_Types[i]
                if u_k[1][i]!=None:
                    p.Believe_agent=u_k[1][i].Name
                    p.prediction=u_k[1][i].Accuracy[i]
                result.append(p)
        return result

    #Number18
    def Get_data_with_confidence_interval(self):
        datas=''
        percepts=self.Generate_Best_Student_with_confidence_interval()       
        for per in percepts:
            if per.prediction!=None:
                data='question_Type '+str(per.question_Type)+' question_length '+str(per.question_Length)+' Believe_Agent '+str(per.Believe_agent) +' prediction '+str(per.prediction[0])
                data=data+' '+str(per.prediction[1])+' '+str(per.prediction[2])
                datas=datas+data+'\n'
            else:
                data='question_Type '+str(per.question_Type)+' question_length '+str(per.question_Length)+' Believe_Agent '+str(per.Believe_agent) +' prediction '+str(per.prediction)
                datas=datas+data+'\n'
        return datas

    #Number19
    def write_information_with_confidence_interval(self):
        datas=self.Get_data_with_confidence_interval()
        file_object = open(self.save_address, 'w')
        file_object.write(datas)
        file_object.close( )

    #Number20
    def Read_percept_with_confidence_interval(self):
        percepts=[]
        read_information=open(self.save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if 'question_Type'==data[j]:
                        q_t=data[j+1]
                    elif 'question_length'==data[j]:
                        q_l=data[j+1]
                    elif 'Believe_Agent' ==data[j]:
                        Name=data[j+1]
                    elif 'prediction'==data[j]:
                        if data[j+1]!='None':
                            prediction=[data[j+1],data[j+2],data[j+3]]
                        else:
                            prediction=data[j+1]

            if Name!='None':
                p=percept()
                p.Believe_agent=Name
                p.prediction=prediction
                p.question_Length=q_l
                p.question_Type=q_t
                p.Test()
                percepts.append(p)
        return percepts

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:Get_Best_choose(self)"
        print "purpose: get the best candidate"
        print"======================================================="
        print "Number 2"
        print "Function Name:  Get_Best_choose_without_time(self)"
        print "purpose: get the best candidate without conside time"
        print"======================================================="
        print "Number 3"
        print "Function Name:Read_Knowledge(self)"
        print "purpose: read the knowledges"
        print"======================================================="
        print "Number 4"
        print "Function Name: Judge_Is_Exist(self)"
        print "purpose: judge the folder is exist or not"
        print"======================================================="
        print "Number 5"
        print "Function Name:build_condition(self)"
        print "purpose: build the requires"
        print"======================================================="
        print "Number 6"
        print "Function Name:Classify_Knowledge(self)"
        print "purpose: classify the knowledges"
        print"======================================================="
        print "Number 7"
        print "Function Name:Add_max_knowledge(self)"
        print "purpose: calculate the max average accuracy"
        print"======================================================="
        print "Number 8"
        print "Function Name:Get_Candidate(self)"
        print "purpose: get the candidates"
        print"======================================================="
        print "Number 9"
        print "Function Name: Generate_Best_Student(self)"
        print "purpose: get the candidates"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_data(self)"
        print "purpose: get the data"
        print"======================================================="
        print "Number 11"
        print "Function Name:write_information(self)"
        print "purpose: write the result"
        print"======================================================="
        print "Number 12"
        print "Function Name:Read_percept(self)"
        print "purpose: read the percept"
        print"======================================================="
        print "Number 13"
        print "Function Name:Read_Knowledge_with_confidence_interval(self)"
        print "purpose: read the knowledge with confidence interval"
        print"======================================================="
        print "Number 14"
        print "Function Name:Add_max_knowledge_with_confidence_interval(self)"
        print "purpose: get max average accuracy based on confidence interval"
        print"======================================================="
        print "Number 15"
        print "Function Name:Get_Candidate_with_confidence_interval(self)"
        print "purpose: get the candidates with confidence interval"
        print"======================================================="
        print "Number 16"
        print "Function Name: Get_Best_choose_with_confidence_interval(self)"
        print "purpose: get the best candidate"
        print"======================================================="
        print "Number 17"
        print "Function Name:Generate_Best_Student_with_confidence_interval(self)"
        print "purpose: get the candidates"
        print"======================================================="
        print "Number 18"
        print "Function Name:Get_data_with_confidence_interval(self)"
        print "purpose: generate the result"
        print"======================================================="
        print "Number 19"
        print "Function Name:write_information_with_confidence_interval(self)"
        print "purpose: write the result"
        print"======================================================="
        print "Number 20"
        print "Function Name:Read_percept_with_confidence_interval(self)"
        print "purpose: read the percept with confidence interval"
        print"======================================================="


class percept:
    def __init__(self):
        self.question_Type=None
        self.Believe_agent=None
        self.prediction=None
        self.question_Length=None

    def Test(self):
        print 'question Type',self.question_Type
        print 'question length',self.question_Length
        print 'Believe Agent',self.Believe_agent
        print 'prediction',self.prediction

b=build_knowledge('Ma_env')
class recognise_problems:
    def __init__(self,I_address,choose=2):
        self.basic_config= Basic_Config()
        self.percept_save_address='percept\\my_percept.txt'
        
        self.allow_error=0.08
        self.env_address=I_address
        self.MP=Mapping()
        if choose==0:#old version
            self.my_percept=self.Read_percept()
            self.result=self.detect_question()
        elif choose==1:#old version
            self.my_percept=self.Read_percept()
            self.result=self.detect_question_with_confidence()
        elif choose==2:#default choose
            self.my_percept=self.Read_percept_with_confidence_interval()
            self.result=self.detect_question_with_confidence_interval()
        else:#old version  
            self.my_percept=self.Read_percept()
            self.result=self.detect_question_ALL_Answer()

    #number1
    def Read_percept(self):
        percepts=[]
        read_information=open(self.percept_save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if 'question_Type'==data[j]:
                        q_t=data[j+1]
                    elif 'question_length'==data[j]:
                        q_l=int(data[j+1])
                    elif 'Believe_Agent' ==data[j]:
                        Name=data[j+1]
                    elif 'prediction'==data[j]:
                        prediction=data[j+1]
            if Name!='None':
                p=percept()
                p.Believe_agent=Name
                p.prediction=float(prediction)
                p.question_Length=q_l
                p.question_Type=q_t
                #p.Test()
                percepts.append(p)
        return percepts

    #number2
    def Read_percept_with_confidence_interval(self):
        percepts=[]
        read_information=open(self.percept_save_address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        for lines in  information:
            data=lines.split('\n')[0].split(' ')
            accuracy=[None]*len(self.basic_config.Question_Types)
            for j in range(0,len(data)):
                for i in range(0,len(self.basic_config.Question_Types)):
                    if 'question_Type'==data[j]:
                        q_t=data[j+1]
                    elif 'question_length'==data[j]:
                        q_l=data[j+1]
                    elif 'Believe_Agent' ==data[j]:
                        Name=data[j+1]
                    elif 'prediction'==data[j]:
                        if data[j+1]!='None':
                            prediction=[float(data[j+1]),float(data[j+2]),float(data[j+3])]
                        else:
                            prediction=data[j+1]

            if Name!='None':
                p=percept()
                p.Believe_agent=Name
                p.prediction=prediction
                p.question_Length=float(q_l)
                p.question_Type=q_t
                #p.Test()
                percepts.append(p)
        return percepts

    #number3
    def Calculate_accuracy(self,agent,envs):
         accuracys=[]
         total_accuracy=0
         for env in envs:
             right=0
             for e in env:
                 if e.actual_action=='False':
                     env_action=0
                 else:
                     env_action=1
                 A_action=self.MP.Get_Action(e.state,agent)
                 if A_action==env_action:
                    right=right+1                     
             accuracy= right/float(len(env))
             #print accuracy
             total_accuracy=total_accuracy+accuracy              
             accuracys.append(accuracy)
         average_accuracy=total_accuracy/len(envs)
         print average_accuracy
         return average_accuracy

    #number4
    def calculate_accuracy_list(self,agent,envs):
         accuracys=[]
         total_accuracy=0
         for env in envs:
             right=0
             for e in env:
                 if e.actual_action=='False':
                     env_action=0
                 else:
                     env_action=1
                 A_action=self.MP.Get_Action(e.state,agent)
                 if A_action==env_action:
                    right=right+1                     
             accuracy= right/float(len(env))
             accuracys.append(accuracy)
             total_accuracy=total_accuracy+accuracy              
         average_accuracy=total_accuracy/len(envs)
         return average_accuracy,accuracys

    #number5
    def detect_question(self):
        for use_precept in self.my_percept:
            not_fail=True
            e_r=environment_Recognise(self.env_address)
            if e_r.length==use_precept.question_Length:
                A_R=Agent_Reader(use_precept.Believe_agent)
                Ag= A_R.Get_Agent()
                while not_fail:
                    envs=e_r.Recognise_envs()
                    not_fail=envs[0]
                    #print not_fail
                    if envs[1]!=None:
                        accuracy=self.Calculate_accuracy(Ag[0],envs[1])
                        #print use_precept.prediction-self.allow_error
                        if accuracy>=(use_precept.prediction-self.allow_error):
                            if use_precept.question_Type!=Ag[0].Question:
                                return "I'm confuse","My answer is "+use_precept.question_Type,"But agent should solve "+Ag[0].Question,"The agent I choose is ",use_precept.Believe_agent
                            else:
                                return "I get my result","My answer is "+use_precept.question_Type,"The agent I choose is ",use_precept.Believe_agent
                print 'not ',use_precept.question_Type
        return "I don't know","I have no ideal","I need new agent"

    #number6
    def detect_question_ALL_Answer(self):
        result=[]
        for use_precept in self.my_percept:            
            not_fail=True
            data=''
            e_r=environment_Recognise(self.env_address)
            if e_r.length==use_precept.question_Length:
                A_R=Agent_Reader(use_precept.Believe_agent)
                Ag= A_R.Get_Agent()
                data='question type: '+use_precept.question_Type+' '
                while not_fail:
                    envs=e_r.Recognise_envs()
                    not_fail=envs[0]
                    #print not_fail
                    
                    if envs[1]!=None:
                        data=data+' Accuracy: '
                        accuracy=self.Calculate_accuracy(Ag[0],envs[1])
                        data=data+str(accuracy)+' '
                result.append(data)
        return result

    #number7
    def detect_question_with_confidence(self):
        result=[]
        c_m=Confidence_interval()
        e_m=Confidence_env_builder(self.env_address,20)
        e_u=e_m.Training_Population_envs
        for use_precept in self.my_percept:
            if len(e_u[0][0].state)==use_precept.question_Length:
                A_R=Agent_Reader(use_precept.Believe_agent)
                Ag= A_R.Get_Agent()
                accuracy,accuracys=self.calculate_accuracy_list(Ag[0],e_u)
                confidence=c_m.Get_confidence(use_precept.prediction,accuracys)
                data=''
                
                data=data + 'Agent Question Type '+Ag[0].Question+'\n'
                data= data+'result accuracy '+str(accuracy)+'\n'
                data= data+'confidence ' +str(confidence)+'\n'
                result.append(data)
        return result
    
    #number8
    def detect_question_with_confidence_interval(self):
        result=[]
        candidate=[]
        c_m=Confidence_interval()
        e_m=Confidence_env_builder(self.env_address,20)
        e_u=e_m.Training_Population_envs
        for use_precept in self.my_percept:
            if len(e_u[0][0].state)==use_precept.question_Length:
                A_R=Agent_Reader(use_precept.Believe_agent)
                Ag= A_R.Get_Agent()
                accuracy,accuracys=self.calculate_accuracy_list(Ag[0],e_u)
                confidence=self.Get_prediction(use_precept.prediction[0],use_precept.prediction[1],accuracys)
                data=''
                data=data + 'percept Question Type '+str(use_precept.question_Length)+' bit '+use_precept.question_Type+' '+'\n'
                data=data + 'Agent Question Type '+Ag[0].Question+'\n'
                data= data+'result accuracy '+str(accuracy)+'\n'
                data= data+'confidence ' +str(confidence)+'\n'
                candidate.append([use_precept.question_Type,use_precept.question_Length,use_precept.Believe_agent ,confidence])
                result.append(data)
        judge=self.Get_final_prediction(candidate)
        result.append(judge)
        return result

    #number9
    def Get_final_prediction(self,candidate):
        max_confidence=0
        for cand in candidate:
            if cand[-1]>max_confidence:
                max_confidence=cand[-1]

        candidates=[]
        for cand in candidate:
            if max_confidence==cand[-1]:
                candidates.append(cand)

        if len(candidates)==1 and max_confidence>0:
            result='my result is '+ str(candidates[0][1])+' bit '+ str(candidates[0][0])+'\n'
            result=result+'my believe agent is '+candidate[0][2]+'\n'
        elif len(candidates)>1 and max_confidence>0:
            result="I'm confuse\n"
            for cand in candidates:
                result=result+'The answer may be '+str(cand[1])+' bit '+ str(cand[0])+'\n'
                result=result+'my believe agent is '+cand[2]+'\n'
        else:
            result="I don't know"
        return result

    #number10
    def Get_prediction(self,low,high,accuracys):
        c_m=Confidence_interval()
        k=5
        step=(math.fabs(high-low))/k
        confidences=[]
        for i in range(0,k+1):
            value=low+step*i
            confidence=c_m.Get_confidence(value,accuracys)
            confidences.append(confidence)
            print confidence
        max_confidence=0
        for conf in confidences:
            if max_confidence<conf:
                max_confidence=conf
        return max_confidence
     
    #number11                
    def Get_result(self):
        if self.result!=None:
            for ans in self.result:
                print ans

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:Read_percept(self)"
        print "purpose: read the percept old version"
        print"======================================================="
        print "Number 2"
        print "Function Name:  Read_percept_with_confidence_interval(self)"
        print "purpose: read the percept with confidence interval"
        print"======================================================="
        print "Number 3"
        print "Function Name: Calculate_accuracy(self,agent,envs)"
        print "purpose: calculate the accuracy"
        print"======================================================="
        print "Number 4"
        print "Function Name: calculate_accuracy_list(self,agent,envs)"
        print "purpose: get a set of accuracies"
        print"======================================================="
        print "Number 5"
        print "Function Name:detect_question(self)"
        print "purpose:detect the question"
        print"======================================================="
        print "Number 6"
        print "Function Name:detect_question_ALL_Answer(self)"
        print "purpose:return all the information of the test"
        print"======================================================="
        print "Number 7"
        print "Function Name:detect_question_with_confidence(self)"
        print "purpose:detect the question with confidence means based on T-student Test but without confidence interval"
        print"======================================================="
        print "Number 8"
        print "Function Name:detect_question_with_confidence_interval(self)"
        print "purpose:detect the question with confidence interval"
        print"======================================================="
        print "Number 9"
        print "Function Name: Get_final_prediction(self,candidate)"
        print "purpose:get the final prediction"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_prediction(self,low,high,accuracys)"
        print "purpose:calculate the predictions"
        print"======================================================="
        print "Number 11"
        print "Function Name:Get_result(self)"
        print "purpose:display the results"
        print"======================================================="

class Basic_Test_Functions:
     def __init__(self):
         self.Test_Name='Basic Functions'

     #Number1
     def Gaussian_Function(self,expect,variance,x):
         if(variance*variance)>0:
            result=(1.0/(math.sqrt(2.0*math.pi)*math.sqrt(variance)))*math.exp(-((x-expect)**2)/(2.0*(variance)))
            return result
         else:
             return -1

     #Number2
     def Normal_distribution_Function(self,x):
         result=(1.0/(math.sqrt(2.0*math.pi)))*math.exp(-(x**2)/2.0) 
         return result

     #Number3
     def Calculate_average(self,input_list):
        total=0.0
        for value in input_list:
            total=total+value
        return total/len(input_list)

    #Number4
     def Calculate_variance(self,input_list):
         average=self.Calculate_average(input_list)
         sum=0.0
         for value in input_list:
             sum=sum+(value-average)**2
         return sum/len(input_list)

     #Number5
     def Cumulative_Distribution_Function(self,expect,variance,x):
         if variance>0:
            result=(1.0/2.0)*(1.0+math.erf((x-expect)/(math.sqrt(variance)*math.sqrt(2))))
            return  result
         else:
            return -1

     def Test(self):
         #result=self.Calculate_variance([0.9,0.99,0.98,0.97])
         #avg=self.Calculate_average([0.9,0.99,0.98,0.97])
         #result_0=self.Cumulative_Distribution_Function(avg,result,1.3)
         #result_0=self.Gaussian_Function(avg,result,avg)
         #result_1=self.Cumulative_Distribution_Function(result_0,result,1.0)
         #print result_0
        print"======================================================="
        print "Number 1"
        print "Function Name:Gaussian_Function(self,expect,variance,x)"
        print "purpose: Gaussian function"
        print"======================================================="
        print "Number 2"
        print "Function Name: Normal_distribution_Function(self,x)"
        print "purpose: calculate the normal distrubution"
        print"======================================================="
        print "Number 3"
        print "Function Name: Calculate_average(self,input_list)"
        print "purpose: calculate the average"
        print"======================================================="
        print "Number 4"
        print "Function Name: Calculate_variance(self,input_list)"
        print "purpose: calculate the variance"
        print"======================================================="
        print "Number 5"
        print "Function Name:Cumulative_Distribution_Function(self,expect,variance,x)"
        print "purpose:get the distribution function"
        print"======================================================="

#b_p=build_percept()


r_p=recognise_problems('DV1_env_01')
r_p.Get_result()


#BF=Basic_Test_Functions()
#BF.Test()


#c= Confidence_interval_env_builder('carry_env_01')
#c.Test()

#c=Confidence_interval()
#Test=[1.0,1.0,1.0,1.0,1.0,0.999,0.7,0.65,0.44]
#result=c.Get_Confidence_interval(Test)
#print result



