﻿import os
from Classify_config import *
from virtual_Generate_config import *
from Environment_Selection_Machine import Environment_Selection_Machine
from environment_machine import Condition
from environment_machine import Environment
import random
from Classify_machine import classify_machine


class Virtual_Generate:
    def __init__(self,type,condition,rate):
       self.vc_c=virtual_Generate_config()
       if rate!=None:
           self.vc_c.Training_Rate=rate
       #self.vc_c.Test()
       self.c_m=classify_machine()
       self.environments=self.Get_environments(type,condition)
       self.Save_Virtual_Agent()
    
    #Number 1
    def Get_environments(self,type,conditions):
        if type !=None and conditions !=None:
            self.vc_c.Set_Environment_request(type,conditions)
        E_S_C=Environment_Selection_Machine(self.vc_c.Get_Environmet_Id,self.vc_c.Environment_Conditions)
        result=E_S_C.Complete_environment()
        return result

    #number 2
    def Get_Training_Data(self,use_environment):
        condition=use_environment.Conditions
        Training_Data=[]
        #Max=int(len(condition)*self.vc_c.Training_Rate/100)
        for i in condition:
            if(random.randint(1,100)<self.vc_c.Training_Rate):
                Training_Data.append(i)
        return Training_Data,use_environment.type

    #number 3
    def Build_Virtual_Agent(self,Training_Data):      
        result=[]
        for i in Training_Data[0]:    
            v_r=Virtual_Agent_Recognise(i.state,i.actual_action)
            result.append(v_r)
        my_virtual_agent=Virtual_Agent(result,Training_Data[1])
        return my_virtual_agent
   
    #number 4
    def build_Agent_floder(self):
        self.c_m.Create_folder(self.vc_c.Folder_Name)
    
    #number 5
    def Write_Anegnt_message(self,agents):
        result=self.vc_c.Classify_Type+"\n"
        result=result+agents.Question+"\n"
        for i in range(0,len(agents.recognise)):
            for j in range(0,len(agents.recognise[i].condition)):
                result=result+str(agents.recognise[i].condition[j])+' '
            result=result+'\\'+str(agents.recognise[i].understant)+'\n'
        return result

    #number 6
    def Generate_File_Name(self,count):
        use_time=self.c_m.Get_Stamp() 
        File_Name=self.vc_c.Folder_Name+'\\'+self.vc_c.file_Name+count+'_'+use_time+self.vc_c.file_type
        return File_Name

    #number 7
    def Save_Virtual_Agent(self):
        self.build_Agent_floder() 
        count=0
        for env in self.environments:  
            count=count+1
            data=self.Get_Training_Data(env)  
            agent=self.Build_Virtual_Agent(data)
            message=self.Write_Anegnt_message(agent)
            File_Name=self.Generate_File_Name(str(count))
            self.c_m.Write_File(File_Name,message)
                  
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:Get_environments(self,type,conditions)"
        print "purpose: get the environments"
        print "Value pairs:"
        print "type                              || conditions"
        print"============================================================="
        print "0   'Address_one'                 || int just like 0,1,2,3...@"
        print "1   'Address_list'                || int[] just like [0,1]@"
        print "2    'whole'                      || None"
        print "3'based_on_one_question'          || int just like 0,1,2,3...#"
        print "4'based_on_questions_list'        || int[] just like [0,1]#"
        print "5'based_on_one_question_several'  || int just like 0,1,2,3...#"
        print "6'based_on_questions_list_several'|| int[] just like [0,1]#"
        print "Notice @: means the value depend on the length of environment list, it should less than the length of environments"
        print "Notice #: means the value depend on the length of environment type list, it should less than the length of environment types"
        #for i in self.environments:
        #    i.Test()
        print"======================================================="
        print "Number 2"
        print "Function Name:Get_Training_Data(self,use_environment)"
        print "purpose: get the training data based on environment"
        print "parameter use_environment: the environment you want to generate the training data"
        result=self.Get_Training_Data(self.environments[0])
        #print len(result)
        #for i in result:
        #    i.Test()
        print"======================================================="
        print "Number 3"
        print "Function Name:Build_Virtual_Agent(self,Training_Data)"
        print "purpose: build the virtual agent"
        print "parameter Training_Data: the environment you want to generate the training data"
        Answer=self.Build_Virtual_Agent(result)
        #Answer.Test()
        print"======================================================="
        print "Number 4"
        print "Function Name:build_Agent_floder(self)"
        print "purpose: build the virtual agent floder"
        #self.build_Agent_floder()
        print"======================================================="
        print "Number 5"
        print "Function Name:Write_Anegnt_message(self,agents)"
        print "purpose: the message of the agent for saving"
        result_0=self.Write_Anegnt_message(Answer)
        #print result_0
        print"======================================================="
        print "Number 6"
        print "Function Name:Generate_File_Name(self,count)"
        print "purpose: the file name for saving the messages"
        print "parameter count: the number of environments"
        #result=self.Generate_File_Name()
        #print result
        print"======================================================="
        print "Number 7"
        print "Function Name:Save_Virtual_Agent(self)"
        print "purpose: save the virtual agent"
        #self.Save_Virtual_Agent()

    
class Virtual_Agent:
    def __init__(self,recognises,question):
        self.Question=question
        self.recognise=recognises
    
    def Test(self):
        for i in self.recognise:
            i.Test() 
        print len(self.recognise)       
    
class Virtual_Agent_Recognise:
    def __init__(self,state,result):
        self.condition=state
        self.understant=result

    def Test(self):
        print self.condition
        print self.understant

#v=Virtual_Generate()
#v.Test()