﻿from Agent_Pools_Configpy import Agent_pool_config
import os
import time
import uuid
import shutil
import sys
from virtual_Agent_Producer import Virtual_Agent_Recognise
from virtual_Agent_Producer import Virtual_Agent
from computer_operator import computer_operator as op_
from Basic_Config import Basic_Config

class Agents_Translate:
    def __init__(self,Address):
        self.myconfig=Agent_pool_config()
        self.Informations=self.Read_Information(Address)
        self.type=self.Read_Type(self.Informations)
        self.Agent=self.Translate_Agent(self.Informations)
        #self.Agent.Test()

    #Number1
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '':
             information.append(lines)
        return information

    #Number2
    def Read_Type(self,information):
        type=information[0].split('\n')
        return type[0]

    #Number3
    def convert_to_virtual_agent(self,information):
        type=self.type
        question=information[1].split('\n')
        recognise=[]
        for i in range(2,len(information)):
            state_o=str(information[i]).split('\n')
            state_1=state_o[0].split('\\')
            state=state_1[0].split(' ')
            del state[-1]
            V_A_R=Virtual_Agent_Recognise(state,state_1[1])
            recognise.append(V_A_R)
        V_A=Virtual_Agent(recognise,question[0])
        T_A=Trained_Agent(type,question[0],V_A)
        return T_A

    #Number4
    def Translate_Agent(self,information):
        if self.type==self.myconfig.Agent_Type[0]:
            result=self.convert_to_virtual_agent(information)
            return result
        else:
            return None
    
    #Number5
    def Get_Agent(self):
        return self.Agent

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: Read_Information(self,path)"
        print "purpose: read the information from path"
        print "parameter path: the adress of the file"
        #print self.Informations
        print"======================================================="
        print "Number 2"
        print "Function Name:Read_Type(self,information)"
        print "purpose: read the type of the agent"
        print "parameter information: the result from read information"
        print"======================================================="
        print "Number 3"
        print "Function Name: convert_to_virtual_agent(self,information)"
        print "purpose: convert the information into virtual agent instance"
        print "parameter information: the result from read information"
        #self.convert_to_virtual_agent(self.Informations)
        print"======================================================="
        print "Number 4"
        print "Function Name: Translate_Agent(self,information)"
        print "purpose: convert the information into agent instance based on the type"
        print "parameter information: the result from read information"
        print"======================================================="
        print "Number 5"
        print "Function Name: Get_Agent(self)"
        print "purpose: get the result"
        print "return: the result of the agent"
        #result=self.Get_Agent()
        #result.Test()
        print"======================================================="

class Trained_Agent:
    def __init__(self,type,question,agent):
        self.Type=type
        self.Question=question
        self.Agent=agent
        self.Name=None
        self.Length=None
        self.Length_Seneitive=True

    def Test(self):
        print self.Type
        print self.Question
        self.Agent.Test()

class Agent_pool_Controller:
    def __init__(self):
        self.my_config=Agent_pool_config()
        #self.Agent_T=Agents_Translate()
        self.Generate_basic_folders()

    #number1
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    #number2
    def Create_folder(self,Name):
        if not self.Is_File_Exist(Name):
            os.mkdir(Name)
    
    #number3
    def Generate_basic_folders(self):
        self.Create_folder(self.my_config.Original_Pools)
        self.Create_folder(self.my_config.My_Agent_Pools)

        for basic_floders in self.my_config.Agent_Pool_List:
            Address=self.my_config.Original_Pools+'\\'+basic_floders
            self.Create_folder(Address)

        for Agent_type in self.my_config.Agent_Type:
            Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[0]+'\\'+Agent_type
            self.Create_folder(Address)

        for question_type in self.my_config.Question_Types:
            for Agent_type in self.my_config.Agent_Type:
                Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[0]+'\\'+Agent_type+'\\'+question_type
                self.Create_folder(Address)

        for question_type in self.my_config.Question_Types:
            Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[1]+'\\'+question_type
            self.Create_folder(Address)

        for Agent_type in self.my_config.Agent_Type:
            Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[2]+'\\'+Agent_type
            self.Create_folder(Address)

        for Agent_type in self.my_config.Agent_Type:
            Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[3]+'\\'+Agent_type
            self.Create_folder(Address)

        for question_type in self.my_config.Question_Types:
            for Agent_type in self.my_config.Agent_Type:
                Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[3]+'\\'+Agent_type+'\\'+question_type
                self.Create_folder(Address)

        for question_type in self.my_config.Question_Types:
            Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[4]+'\\'+question_type
            self.Create_folder(Address)

        for question_type in self.my_config.Question_Types:
            for Agent_type in self.my_config.Agent_Type:
                Address=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[4]+'\\'+question_type+'\\'+ Agent_type
                self.Create_folder(Address)

    #number4
    def Get_Stamp(self):
        star_mytime=time.asctime(time.localtime(time.time()))
        list=str(star_mytime).split(' ')        
        result=''
        for inf in list:
            if ':' in inf:
                time_list=inf.split(':')
                for t in time_list:
                    result=result+'_'+t
            else:
                result=result+'_'+inf
        return result
    
    #number5
    def Generate_Pool_Name(self,myname): 
        id=uuid.uuid4() 
        id=str(id).replace('-','_')
        create_time=self.Get_Stamp()
        Name=self.my_config.My_Agent_Pools+'\\'+myname+'_'+self.my_config.Basic_Pool_Name+create_time+'_'+id
        while self.Is_File_Exist(Name):
           id=uuid.uuid4() 
           id=str(id).replace('-','_')
           create_time=self.Get_Stamp()
           Name=self.my_config.My_Agent_Pools+'\\'+myname+'_'+self.my_config.Basic_Pool_Name+create_time+'_'+id
        return Name

    #number6
    def Duplicate_Agent_Pool(self,id,myname):
        Address=self.Generate_Pool_Name(myname)
        for i in range(0,len(self.my_config.Agent_Pool_List)):
            if id==i:
               copy_folder=self.my_config.Original_Pools+'\\'+self.my_config.Agent_Pool_List[id]
               shutil.copytree(copy_folder,Address) 

    #number7
    def Get_Agent_Pool_Name_List(self):
        FileList=[]
        find_path=self.get_current_file_dir()+'\\'+self.my_config.My_Agent_Pools
        if self.Is_File_Exist(find_path):
            FileNames=os.listdir(find_path)
            for i in FileNames:
                if self.my_config.Basic_Pool_Name in i:
                    FileList.append(i)
        result=[]
        for inf in FileList:
            Address=self.my_config.My_Agent_Pools+'\\'+inf
            result.append(Address)
        return result

    #number8
    def get_current_file_dir(self):
        path=sys.path[0]
        if os.path.isdir(path):
            return path
        elif os.path.isfile(path):
            return os.path.dirname(path)

    #number9
    def Delete_Pool(self,Address):
        shutil.rmtree(Address)

    #number10
    def Copy_Agent(self,Address_From,Address_To):
        shutil.copy(Address_From,Address_To)
    
    #number11
    def Get_All_Agents(self,Address):
        result=[]
        for root,dirs,files in os.walk(Address):
            for file in files:
                result_Address=root+'\\'+file
                result.append(result_Address)
        return result

    #number12
    def Get_All_Agents_From_pool(self,Address):
        result=[]
        Address_list=self.Get_All_Agents(Address)
        for use_address in Address_list:
            Agent_T=Agents_Translate(use_address)
            my_agent=Agent_T.Get_Agent()
            result.append(my_agent)
        return result

    def Test(self):
        self.my_config.Test()
        print"======================================================="
        print "Number 1"
        print "Function Name: Is_File_Exist(self,file_Name)"
        print "purpose: judge the file is exist or not"
        print "parameter file_Name: the adress of the file"
        print"======================================================="
        print "Number 2"
        print "Function Name: Create_folder(self,Name)"
        print "purpose: create the folder"
        print "parameter Name: the adress of the file"
        print"======================================================="
        print "Number 3"
        print "Function Name: Generate_basic_folders(self)"
        print "purpose: Generate the basic folders"
        print"======================================================="
        print "Number 4"
        print "Function Name:  Get_Stamp(self)"
        print "purpose: Get the time"
        print"======================================================="
        print "Number 5"
        print "Function Name:Generate_Pool_Name(self,myname)"
        print "purpose: generate the name of the pool"
        print "parameter myname: the string you want to add in front of the agent pool"
        #r=self.Generate_Pool_Name('')
        #print r
        print"======================================================="
        print "Number 6"
        print "Function Name:Duplicate_Agent_Pool(self,id,myname)"
        print "purpose: duplicate agent pool based on type you select"
        print "Parameter id: the type of the agent pool based on Agent_Pool_List in Agent_Pools_Config"
        print "parameter myname: the string you want to add in front of the agent pool"
        #self.Duplicate_Agent_Pool(3,'')
        print"======================================================="
        print "Number 7"
        print "Function Name:Get_Agent_Pool_Name_List(self)"
        print "purpose: get the list of agent pools"
        r=self.Get_Agent_Pool_Name_List()
        #print r
        print"======================================================="
        print "Number 8"
        print "Function Name:get_current_file_dir(self)"
        print "purpose: get the current file address"
        #r=self.get_current_file_dir()
        #print r
        print"======================================================="
        print "Number 9"
        print "Function Name:Delete_Pool(self,Address)"
        print "purpose: delete pool"
        print "Parameter Adress: the adress of the pool you want to delete"
        #self.Delete_Pool(r[0])
        print"======================================================="
        print "Number 10"
        print "Function Name:Copy_Agent(self,Address_From,Address_To)"
        print "purpose: copy agent from one file to another"
        #self.Copy_Agent('1.txt',self.my_config.Original_Pools)
        print"======================================================="
        print "Number 11"
        print "Function Name:Get_All_Agents(self,Address)"
        print "purpose: get all the agents in the agent pool"
        #result=self.Get_All_Agents(r[0])
        #print result[0]
        print"======================================================="
        print "Number 12"
        print "Function Name:Get_All_Agents_From_pool(self,Address)"
        print "purpose: get all the agents from some agent pool"
        #Agent_T=Agents_Translate(result[0])
        #result=Agent_T.Get_Agent()
        #result.Test()
        #result=self.Get_All_Agents_From_pool(r[0])
        #print len(result)
        #for i in result:
        #    i.Test()
        print"======================================================="
#Ap=Agent_pool_Controller()
#Ap.Test()

class xcsCFCavg_Translate:
    def __init__(self,address):
        self.basic_string='xcsCFCavg'#number4
        if self.basic_string in address or not '.txt' in address:  
            self.Terminal_string=['CF_','D']#number14
            self.symbol_string=['&','|','d','r','~','o']#number15
            self.one_link_symbol=['~','o']#number16
            self.two_link_symbol=['&','|','d','r']#number17
            self.address=address#number12
            self.count_operator=-1
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[1]#number1
            self.AC=Agent_pool_Controller()
            self.basic_string='xcsCFCavg'#number4
            self.basic_CFs='CFs'
            self.basic_Rules='Rules'
            self.action_string='Action'
            self.parameter_string='Numerosity'
            self.Numerosity_string='Numerosity'
            self.Accuracy_string='Accuracy'
            self.Fitness_string='Fitness'
            self.Prediction_Error_string='Error:'
            self.Prediction_string='Prediction:'
            self.Experience_string='Experience'
            self.Specificness_string='Specificness'
            self.basic_config=Basic_Config()
            #self.result_agents=self.Generate_all_Agents()#number18
            self.result_Mapped_Agents=self.Generate_Mapped_Agent()#number19
            #print 'xcsfc agent translate working complete'
        else:
            self.result_Mapped_Agents=[]

    #number2
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P
    
    #number3
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '':
             information.append(lines)
        return information

    #number5
    def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

    #number6
    def Get_Pairs(self):
        if '.txt' in self.address and self.basic_string in self.address:
            return_pair=[]
            pair=[]
            result=self.address.split('$$')
            pair.append(result[0])
            pair.append(result[1])
            return_pair.append(pair)
            return  return_pair
        
        paths=self.Get_current_files()
        CFs=[]
        Rules=[]
        for path in paths :
            if self.basic_CFs in path:
                CFs.append(path)
            elif self.basic_Rules in path:
                Rules.append(path)
        return_pair=[]
        for CF in CFs:
            inf_0=CF.split('_')
            inf_1=inf_0[-1].split('.')
            pair=[]
            for Ru in Rules:
                if inf_1[0] in Ru:
                    pair.append(Ru)
                    pair.append(CF)
                    return_pair.append(pair)
        return return_pair

    #number7
    def Read_MUXCFs(self,address):
        Information=self.Read_Information(address)
        parameter_1=None
        parameter_2=None
        Read_CFs=[]
        for i in range(0,len(Information)):
            if Information[i]!='\n':
                if i==0:
                    parameter_1=Information[i].split('\n')[0]
                elif i==1:
                    parameter_2=Information[i].split('\n')[0]
                else:
                    infs_0= Information[i].split(' ')
                    ID= int(infs_0[-1].split('\n')[0])
                    use_list=[]
                    for inf in infs_0:
                        if inf !='o':
                            use_list.append(inf)
                        else:
                            use_list.append(inf)
                            break
                    use_CF=CF(ID,use_list)
                    Read_CFs.append(use_CF)
        #print len(Read_CFs)
        #for i in Read_CFs:
        #    if i.ID==15:
        #        i.Test()
        result=CFs(parameter_1,parameter_2,Read_CFs)
        return result
        
    #number8
    def Read_Rule(self,address):
        Information=self.Read_Information(address)
        Is_Condition_Flag=True
        action=None
        conditions=[]
        Rule_part=[]
        for i in range(0,len( Information)):
            if Is_Condition_Flag and not (self.action_string in Information[i]):
                inf_0= Information[i].split(' ')
                use_list=[]
                for inf in inf_0:
                    if inf!='o':
                        use_list.append(inf)
                    else:
                        use_list.append(inf)
                        break
                conditions.append(use_list)
            if self.action_string in Information[i]:
                Is_Condition_Flag=False
                action=int( Information[i].split(' ')[-1].split('\n')[0])
            if self.parameter_string in Information[i]:
                Is_Condition_Flag=True
                inf_0= Information[i].split('\n')[0]
                inf_1=inf_0.split(' ')
                for j in range(0,len(inf_1)):
                    if self.Numerosity_string in inf_1[j]:
                        Numerosity=inf_1[j+1]
                        #print Numerosity
                    elif self.Accuracy_string in inf_1[j]:
                        Accuracy=inf_1[j+1]
                        #print Accuracy
                    elif self.Fitness_string in inf_1[j]:
                        Fitness=inf_1[j+1]
                        #print Fitness
                    elif self.Prediction_Error_string in inf_1[j]:
                        Prediction_Error=inf_1[j+1]
                        #print Prediction_Error
                    elif self.Prediction_string in inf_1[j]:
                        Prediction=inf_1[j+1]
                        #print Prediction
                    elif self.Experience_string in inf_1[j]:
                        Experience=inf_1[j+1]
                        #print Experience
                    elif self.Specificness_string in inf_1[j]:
                        Specificness=inf_1[j+1]
                        #print Specificness
                use_xcscfc=xcsCFC(conditions,action,Numerosity,Accuracy,Fitness,Prediction_Error,Prediction,Experience,Specificness)
                #use_xcscfc.Test()
                Rule_part.append(use_xcscfc)
                conditions=[]
        return Rule_part

    #number9
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number10
    def Generate_Agent(self,pair):
        CFs_Part=None
        Rule_Part=None
        question=None
        for path in pair:
            if self.basic_CFs in path:
                CFs_Part=self.Read_MUXCFs(path)
                question=self.Get_Question(path)
            elif self.basic_Rules in path:
                Rule_Part=self.Read_Rule(path)
        use_agent=xcsCFC_Agent(CFs_Part, Rule_Part)
        #use_agent.Test()
        #print question
        result=Trained_Agent(self.Type,question,use_agent)
        result.Name=pair[0]+'$$'+pair[1]
        result.Length=int(pair[0].split('\\')[-1].split('_')[1])
        return result
     
    #number11 important 
    def Generate_all_Agents(self):
        Agents=[]
        try:
            pairs=self.Get_Pairs()
            if len(pairs)>0:
                #print 'begin read xcsfc agent '
                for pair in pairs:
                    agent=self.Generate_Agent(pair)
                    Agents.append(agent)
            return Agents
        except:
            error=[]
            return error

    #number13
    def Get_Agent(self):
        return self.result_agents

    #number20
    def Is_Termianl(self,cod):
        for t in self.Terminal_string:
            if t in cod:
                return True
        return False

    #number21
    def Is_symbol(self,cod):
        for s in self.symbol_string:
            if s==cod:
                return True
        return False

    #number22
    def Is_One_Link_symbol(self,cod):
        for s in self.one_link_symbol:
            if s==cod:
                return True
        return False

    #number23
    def Is_two_link_symbol(self,cod):
        for s in self.two_link_symbol:
            if s==cod:
                return True
        return False

    #number24
    def Link_first_Root(self,Id,branch):
        if Id-1>=0:
            branch[Id-1].Set_Root(branch[Id])
            branch[Id].Set_Left(branch[Id-1])
    
    #number25        
    def Return_2Number_without_root(self,Id,branch):
        result=[]
        for i in range(0,Id):
            if branch[Id-i-1].root==None:
                result.append(Id-i-1)
            if len(result)==2:
                return result

    #number26
    def Link_Second_Root(self,Id,branch):
        Ids=self.Return_2Number_without_root(Id,branch)
        branch[Id].Set_Left(branch[Ids[0]])
        branch[Id].Set_Right(branch[Ids[1]])
        branch[Ids[0]].Set_Root(branch[Id])
        branch[Ids[1]].Set_Root(branch[Id])

    #number27   
    def Get_Rule_One_Tree(self,condition):
        branches=[]
        symbol_number=[]
        for i in range(0,len(condition)):
            Tree=Tree_4(condition[i])
            if self.Is_Termianl(condition[i]):
                Tree.Set_Type(0)
            elif self.Is_symbol(condition[i]):
                Tree.Set_Type(1)
                symbol_number.append(i)
            branches.append(Tree)
        #print len(branches)
        #print condition
        #print branches[0]
        for i in symbol_number:
            if self.Is_One_Link_symbol(branches[i].value):
                self.Link_first_Root(i,branches)
        for i in symbol_number:
            if self.Is_two_link_symbol(branches[i].value):
                self.Link_Second_Root(i,branches)
        #for i in branches:
        #    i.Test()
        #branches[-1].Test()
        self.Set_Depth(branches[-1])
        self.count_operator=-1
        #for bran in branches:
        #    bran.Test()
        return branches

    #number28 important
    def Generate_Mapped_Agent(self):
        Error=[]
        try:
            Agents=self.Generate_all_Agents()
            if Agents!=None and len(Agents)>0:
                print 'begin read xcsfc agent '
                for Agent_Id in range(0,len(Agents)):
                    for rule_Id in range(0,len(Agents[Agent_Id].Agent.Rule)):
                        for cod_Id in range(0,len(Agents[Agent_Id].Agent.Rule[rule_Id].conditions)):
                            Agents[Agent_Id].Agent.Rule[rule_Id].conditions[cod_Id]=self.Get_Rule_One_Tree(Agents[Agent_Id].Agent.Rule[rule_Id].conditions[cod_Id])
                             #self.Print_Tree_2(Agents[Agent_Id].Agent.Rule[rule_Id].conditions[cod_Id])
                    for cf_Id in range(0,len(Agents[Agent_Id].Agent.xcf.CFS)):
                        Agents[Agent_Id].Agent.xcf.CFS[cf_Id].Rule=self.Get_Rule_One_Tree(Agents[Agent_Id].Agent.xcf.CFS[cf_Id].Rule)
                        #self.Print_Tree_2(Agents[Agent_Id].Agent.xcf.CFS[cf_Id].Rule)
                print 'xcsfc agent translate working complete '
            return Agents
        except:
            return Error

    #number29                                
    def Set_Depth(self,branch):        
        if branch.Left!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Left)
        if branch.Right!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Right)
        if branch.Type==branch.Type_Id[0] or branch.Canset_Depth==True:
            branch.Set_Depth(self.count_operator)
            if branch.root!=None:
                 branch.root.Canset_Depth=True
                 #print self.count_operator
                 self.count_operator=self.count_operator-1

    #number30
    def Get_Max_Length(self,branches):
        max=2
        for bran in branches:
            if len(bran.value)>max:
                max=len(bran.value)
        return max

    #number31
    def Get_space(self,number):
        result=''
        for i in range(0,number):
            result=result+' '
        return result 

    #number32
    def GenMatrix(self,rows,cols,length):
        matrix=[[self.Get_space(length) for col in range(cols)] for row in range(rows)]
        return matrix

    #number33
    def Print_Tree_2(self,branches):
        length=self.Get_Max_Length(branches)
        text_list=self.GenMatrix(4,7,length)
        result='\n'
        answer=''
        for bran in branches:
            if bran.Depth==-1:
                text_list[0][3]=bran.value
            elif bran.Depth==0:
                text_list[1][3]=bran.value
            elif bran.Depth==1:
                if bran.root.Left==bran:
                    text_list[2][1]=bran.value
                    if bran.Left!=None:
                        text_list[3][0]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][2]=bran.Right.value 
                elif bran.root.Right==bran:
                    text_list[2][5]=bran.value
                    if bran.Left!=None:
                        text_list[3][4]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][6]=bran.Right.value 
        for txt in text_list:
            for t in txt:
                answer=answer+t
            result=result+answer+'\n'
            answer=''
        print result

    #number34
    def Get_Mapped_Agent(self):
        return self.result_Mapped_Agents
              
    def Test_1(self):
        print"======================================================="
        print "Number 14"
        print "Name:Terminal_string"
        print "purpose: if contain these string than it is terminal"
        print ('value:', self.Terminal_string)
        print"======================================================="
        print "Number 15"
        print "Name:symbol_string"
        print "purpose: if contain these string than it is symbol"
        print ('value:', self.symbol_string)
        print"======================================================="
        print "Number 16"
        print "Name:one_link_symbol"
        print "purpose: the symbol only link one"
        print ('value:', self.one_link_symbol)
        print"======================================================="
        print "Number 17"
        print "Name:two_link_symbol"
        print "purpose: the symbol  link two"
        print ('value:', self.two_link_symbol)
        print"======================================================="
        print "Number 18"
        print "Name:result_agents"
        print "purpose: the agent based on list"
        #print ('value:', self.result_agents)
        print"======================================================="
        print "Number 19"
        print "Name:result_Mapped_Agents"
        print "purpose: the agent based on binary tree"
        #print ('value:', self.result_Mapped_Agents)
        print"======================================================="
        print "Number 20"
        print "Function Name:Is_Termianl(self,cod)"
        print "purpose: judge the branch is terminal or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 21"
        print "Function Name:Is_symbol(self,cod)"
        print "purpose: judge the branch is symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 22"
        print "Function Name:Is_One_Link_symbol(self,cod)"
        print "purpose: judge the branch is one link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 23"
        print "Function Name:Is_two_link_symbol(self,cod)"
        print "purpose: judge the branch is two link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 24"
        print "Function Name:Link_first_Root(self,Id,branch)"
        print "purpose: link the first root ~ or o"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 25"
        print "Function Name: Return_2Number_without_root(self,Id,branch)"
        print "purpose: get the nearest two tree_4 instance which don't have root yet"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 26"
        print "Function Name: Link_Second_Root(self,Id,branch)"
        print "purpose: link the second level branch |,&,r,d"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 27"
        print "Function Name: Get_Rule_One_Tree(self,condition)"
        print "purpose: generate the tree"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 28"
        print "Function Name: Generate_Mapped_Agent(self)"
        print "purpose: generate the agents based on binary tree"
        print"======================================================="
        print "Number 29"
        print "Function Name: Set_Depth(self,branch)"
        print "purpose: set the depth of the tree_4 instances"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 30"
        print "Function Name: Get_Max_Length(self,branches)"
        print "purpose: get the max length cod"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 31"
        print "Function Name: Get_space(self,number)"
        print "purpose: get the space"
        print "parameter number: the number of space"
        print"======================================================="
        print "Number 32"
        print "Function Name: GenMatrix(self,rows,cols,length)"
        print "purpose: get the matrix"
        print "parameter length: the length of space"
        print "parameter row: the row of matrix"
        print "parameter col the col of matrix"
        print"======================================================="
        print "Number 33"
        print "Function Name:Print_Tree_2(self,branches)"
        print "purpose: print the binary tree"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 34"
        print "Function Name:Get_Mapped_Agent(self)"
        print "purpose: return the agent based on binary tree"
  
        #Agents=self.Get_Agent()
        #use_Agent=Agents[0].Agent
        #cod= use_Agent.Rule[-1]
        #for i in cod.conditions:
        #    print i 
        #    for j in i:
        #        if self.Is_symbol(j):
        #            print j 
        #tree=Tree_4(1)
        #self.Print_Tree(tree)
        #count=0 
        #for rules in use_Agent.Rule:  
        #    for test_1 in rules.conditions:
        #        result=self.Get_Rule_One_Tree(test_1) 
        #        count=count+1
        #        if count<40:
        #            print count
        #            self.Print_Tree_2(result)
        #test_1=cod.conditions[4]
        #results=self.Get_Rule_One_Tree(test_1) 
        #self.Print_Tree_2(results)
        #self.Generate_Mapped_Agent()
        #self.Print_Tree_2(results)
        #print self.count_operator
        #"======================================================="
        #Agents=self.Get_Mapped_Agent()
        #use_Agent=Agents[0].Agent
        #cod= use_Agent.Rule[-1].conditions[0]
        #cod= use_Agent.xcf.CFS[1].Rule
        #self.Print_Tree_2(cod)
        print"======================================================="

    #contain document from number1~number13
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 2"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        #result=self.Get_Path()
        #print result
        print"======================================================="
        print "Number 3"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 4"
        print "Name:.basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 5"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        #result=self.Get_current_files()
        #print result
        print"======================================================="
        print "Number 6"
        print "Function Name:Get_Pairs(self)"
        print "purpose: get the pairs of the address"
        #result=self.Get_Pairs()
        #for i in result:
        #    print i
        print"======================================================="
        print "Number 7"
        print "Function Name:Read_MUXCFs(self,address)"
        print "purpose: Read the CFs"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 8"
        print "Function Name：Read_Rule(self,address)"
        print "purpose: Read the rules"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 9"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 10"
        print "Function Name: Generate_Agent(self,pair)"
        print "purpose: get the trained agent"
        print "paramter pair: a pair of path"
        print"======================================================="
        print "Number 11"
        print "Function Name: Generate_all_Agents(self)"
        print "purpose: get the all xcscfc agents"
        #result_0=self.Generate_Agent(result[0])
        #result=self.Generate_all_Agents()
        #for i in result:
        #    i.Test()
        #print len(result)
        print"======================================================="
        print "Number 12"
        print "Name: address"
        print "purpose: the agent pool's name for example 'Test_0' "
        print ("value",self.address)
        print"======================================================="
        print "Number 13"
        print "Function Name: Get_Agent(self)"
        print "purpose: get the agent"

class CF:
    def __init__(self,id,condition):
        self.ID=id
        self.Rule=condition

    def Test(self):
        print self.ID
        #for inf in self.Rule:
        #    print inf
        print self.Rule

class CFs:
    def __init__(self,parameter_1,parameter_2,CFs):
        self.Length=parameter_1
        self.parameter_02=parameter_2
        self.CFS=CFs

    def Test(self):
        print self.Length
        print self.parameter_02
        for C_F in self.CFS:
            C_F.Test()

class xcsCFC:
    def __init__(self,condition,act,in_Numerosity,in_Accuracy,in_Fitness,in_Prediction_Error,in_Prediction,in_Experience,in_Specificness):
        self.conditions=condition
        self.action=act
        self.Numerosity=in_Numerosity
        self.Accuracy=in_Accuracy
        self.Fitness=in_Fitness
        self.Prediction_Error=in_Prediction_Error
        self.Prediction=in_Prediction
        self.Experience=in_Experience
        self.Specificness=in_Specificness

    def Test(self):
        print self.conditions
        print len(self.conditions)
        print self.action
        print self.Numerosity
        print self.Accuracy
        print self.Fitness
        print self.Prediction_Error
        print self.Prediction
        print self.Experience
        print self.Specificness

class xcsCFC_Agent:
    def __init__(self,XCF_part,Rule_Part):
        self.xcf=XCF_part
        self.Rule=Rule_Part

    def Test(self):
        self.xcf.Test()
        for rul in self.Rule:
            rul.Test()

class Tree_4:
    def __init__(self,in_value):
        self.MaxDepth=2
        self.Type_Id=['terminal','symbol']
        self.Type=None
        self.Left=None
        self.Right=None
        self.root=None
        self.Depth=0
        self.Canset_Depth=False
        self.value=in_value
        self.Result=None

    def Set_Type(self,Id):
        self.Type=self.Type_Id[Id]

    def Set_Left(self,left):
        self.Left=left

    def Set_Right(self,right):
        self.Right=right

    def Set_Root(self,root):
        self.root=root

    def Set_Depth(self,value):
        self.Depth=value

    def Set_Result(self,value):
        self.Result=value

    def Test_1(self):
        print"======================================================="
        #print ('MaxDepth' ,self.MaxDepth)
        #print ('Type_Id',self.Type_Id)
        print ('Type',self.Type)
        print ('Left',self.Left)
        print ('Right',self.Right)
        print ('root',self.root)
        print ('Depth',self.Depth)
        print ('value',self.value)
        print ('result',self.Result)
        print"======================================================="

    def Test(self):
        print"======================================================="
        #print ('MaxDepth' ,self.MaxDepth)
        #print ('Type_Id',self.Type_Id)
        print ('Type',self.Type)
        print ('Left',self.Left)
        if self.Left!=None:
            print self.Left.value
        print ('Right',self.Right)
        if self.Right!=None:
            print self.Right.value
        print ('root',self.root)
        if self.root!=None:
            print self.root.value
        print ('Depth',self.Depth)
        print ('value',self.value)
        print"======================================================="

class print_binary_Tree: 
    
    #number2 
    def Get_space(self,number):
        result=''
        for i in range(0,number):
            result=result+' '
        return result 

    #number1
    def Get_Max_Length(self,branches):
        max=2
        for bran in branches:
            if len(bran.value)>max:
                max=len(bran.value)
        return max

    #number3
    def GenMatrix(self,rows,cols,length):
        matrix=[[self.Get_space(length) for col in range(cols)] for row in range(rows)]
        return matrix

    #number4
    def Print_Tree_2(self,branches):
        length=self.Get_Max_Length(branches)
        text_list=self.GenMatrix(4,7,length)
        result='\n'
        answer=''
        for bran in branches:
            if bran.Depth==-1:
                text_list[0][3]=bran.value
            elif bran.Depth==0:
                text_list[1][3]=bran.value
            elif bran.Depth==1:
                if bran.root.Left==bran:
                    text_list[2][1]=bran.value
                    if bran.Left!=None:
                        text_list[3][0]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][2]=bran.Right.value 
                elif bran.root.Right==bran:
                    text_list[2][5]=bran.value
                    if bran.Left!=None:
                        text_list[3][4]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][6]=bran.Right.value 
        for txt in text_list:
            for t in txt:
                answer=answer+t
            result=result+answer+'\n'
            answer=''
        print result  
        
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: Get_Max_Length(self,branches)"
        print "purpose: get the max length cod"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 2"
        print "Function Name: Get_space(self,number)"
        print "purpose: get the space"
        print "parameter number: the number of space"
        print"======================================================="
        print "Number 3"
        print "Function Name: GenMatrix(self,rows,cols,length)"
        print "purpose: get the matrix"
        print "parameter length: the length of space"
        print "parameter row: the row of matrix"
        print "parameter col the col of matrix"
        print"======================================================="
        print "Number 4"
        print "Function Name:Print_Tree_2(self,branches)"
        print "purpose: print the binary tree"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
          
class xcsCFA_SSP_Translate:

    def __init__(self,I_address):  
        self.basic_string='xcsCFA_SSP'#number2
        if self.basic_string in I_address or (not '.txt' in I_address):      
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[2]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.Tree_Begin_String='--->'#number5
            self.Tree_End_String='o'#number6
            self.Terminal_string=['D']#number7
            self.symbol_string=['&','|','d','r','~','o']#number8
            self.one_link_symbol=['~','o']#number9
            self.two_link_symbol=['&','|','d','r']#number10
            self.count_operator=-1
            self.Agents=self.Generate_Agents()#number11
        else:
            self.Agents=[]
    #number12
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number13
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #number14
    def Get_current_files(self):
        try:
            path=self.Get_Path()
            address=self.AC.Get_All_Agents(path)
            useful=[]
            for add in address:
                if self.basic_string in add:
                    useful.append(add)
            return useful
        except:
            return None

    #number15
    def Get_symbols(self,information):
        number =0
        beginflag=False
        result=[]
        while information[number]!=self.Tree_End_String and number<len(information)-1:
            if information[number]==self.Tree_Begin_String:
                beginflag=True
            if beginflag:
                result.append(information[number+1])
            number=number+1
        return result

    #number16
    def Is_Termianl(self,cod):
        for t in self.Terminal_string:
            if t in cod:
                return True
        return False

    #number17
    def Is_symbol(self,cod):
        for s in self.symbol_string:
            if s==cod:
                return True
        return False

    #number18
    def Is_One_Link_symbol(self,cod):
        for s in self.one_link_symbol:
            if s==cod:
                return True
        return False

    #number19
    def Is_two_link_symbol(self,cod):
        for s in self.two_link_symbol:
            if s==cod:
                return True
        return False

    #number20
    def Link_first_Root(self,Id,branch):
        if Id-1>=0:
            branch[Id-1].Set_Root(branch[Id])
            branch[Id].Set_Left(branch[Id-1])
    
    #number21        
    def Return_2Number_without_root(self,Id,branch):
        result=[]
        for i in range(0,Id):
            if branch[Id-i-1].root==None:
                result.append(Id-i-1)
            if len(result)==2:
                return result

    #number22
    def Link_Second_Root(self,Id,branch):
        Ids=self.Return_2Number_without_root(Id,branch)
        branch[Id].Set_Left(branch[Ids[0]])
        branch[Id].Set_Right(branch[Ids[1]])
        branch[Ids[0]].Set_Root(branch[Id])
        branch[Ids[1]].Set_Root(branch[Id])

    #number23                                
    def Set_Depth(self,branch):        
        if branch.Left!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Left)
        if branch.Right!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Right)
        if branch.Type==branch.Type_Id[0] or branch.Canset_Depth==True:
            branch.Set_Depth(self.count_operator)
            if branch.root!=None:
                 branch.root.Canset_Depth=True
                 #print self.count_operator
                 self.count_operator=self.count_operator-1

    #number24
    def Get_Rule_One_Tree(self,condition):
        branches=[]
        symbol_number=[]
        for i in range(0,len(condition)):
            Tree=Tree_4(condition[i])
            if self.Is_Termianl(condition[i]):
                Tree.Set_Type(0)
            elif self.Is_symbol(condition[i]):
                Tree.Set_Type(1)
                symbol_number.append(i)
            branches.append(Tree)
        #print len(branches)
        #print condition
        #print branches[0]
        for i in symbol_number:
            if self.Is_One_Link_symbol(branches[i].value):
                self.Link_first_Root(i,branches)
        for i in symbol_number:
            if self.Is_two_link_symbol(branches[i].value):
                self.Link_Second_Root(i,branches)
        #for i in branches:
        #    i.Test()
        #branches[-1].Test()
        self.Set_Depth(branches[-1])
        self.count_operator=-1
        #for bran in branches:
        #    bran.Test()
        return branches

    #number25
    def Get_basic_Details(self,information):
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Prediction:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Consistency:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Value:' in information[i]:
                results.append(int(information[i+1]))
        return results

    #number26
    def Read_xcsCFA_SSP(self,path):
        results=[]
        information =self.Read_Information(path)
        for inf in information:
            result=inf.split('\n')[0].split(' ')
            I_condition=result[0]
            symbols=self.Get_symbols(result)
            I_result_Tree=self.Get_Rule_One_Tree(symbols)            
            #print symbols  
            details=self.Get_basic_Details(result)  
            xcsCFA_SSP_I=xcsCFA_SSP(I_condition,I_result_Tree,details[0],details[1],details[2],details[3],details[4],details[5],details[6],details[7])     
            results.append(xcsCFA_SSP_I)
        xs_A=xcsCFA_SSP_Agent(results)
        #results[0].Test()
        return xs_A        

    #number27
    def Get_space(self,number):
        result=''
        for i in range(0,number):
            result=result+' '
        return result 

    #number28
    def Get_Max_Length(self,branches):
        max=2
        for bran in branches:
            if len(bran.value)>max:
                max=len(bran.value)
        return max

    #number29
    def GenMatrix(self,rows,cols,length):
        matrix=[[self.Get_space(length) for col in range(cols)] for row in range(rows)]
        return matrix

    #number30
    def Print_Tree_2(self,branches):
        length=self.Get_Max_Length(branches)
        text_list=self.GenMatrix(4,7,length)
        result='\n'
        answer=''
        for bran in branches:
            if bran.Depth==-1:
                text_list[0][3]=bran.value
            elif bran.Depth==0:
                text_list[1][3]=bran.value
            elif bran.Depth==1:
                if bran.root.Left==bran:
                    text_list[2][1]=bran.value
                    if bran.Left!=None:
                        text_list[3][0]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][2]=bran.Right.value 
                elif bran.root.Right==bran:
                    text_list[2][5]=bran.value
                    if bran.Left!=None:
                        text_list[3][4]=bran.Left.value
                    if bran.Right!=None:  
                        text_list[3][6]=bran.Right.value 
        for txt in text_list:
            for t in txt:
                answer=answer+t
            result=result+answer+'\n'
            answer=''
        print result

    #number31
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number32
    def Generate_Agents(self):
        #try:
            Agents=[]
            if len(self.path)>0:
                print 'begin read xcsCFA SSP Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    x_s_A=self.Read_xcsCFA_SSP(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_A)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[2])
                    Agents.append(T_A)
                print 'reading xcsCFA SSP Agents completed'
            return Agents
        #except:
           # error=[]
           # return error

    #number33
    def Get_Agents(self):
        return self.Agents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:Tree_Begin_String"
        print "purpose: the symbol means the tree begin"
        print ("value",self.Tree_Begin_String)
        print"======================================================="
        print "Number 6"
        print "Name:Tree_End_String"
        print "purpose: the symbol means the tree end"
        print ("value",self.Tree_End_String)
        print"======================================================="
        print "Number 7"
        print "Name:Terminal_string"
        print "purpose: the symbol means it is the terminal of the tree"
        print ("value",self.Terminal_string)
        print"======================================================="
        print "Number 8"
        print "Name:symbol_string"
        print "purpose: the symbol string"
        print ("value",self.symbol_string)
        print"======================================================="
        print "Number 9"
        print "Name:one_link_symbol"
        print "purpose: the symbol means link first"
        print ("value",self.one_link_symbol)
        print"======================================================="
        print "Number 10"
        print "Name:two_link_symbol"
        print "purpose: the symbol means link second"
        print ("value",self.two_link_symbol)
        print"======================================================="
        print "Number 11"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 12"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 13"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 14"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 15"
        print "Function Name:Get_symbols(self,information)"
        print "purpose: get the symbols for generate the tree"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 16"
        print "Function Name:Is_Termianl(self,cod)"
        print "purpose: judge the branch is terminal or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 17"
        print "Function Name:Is_symbol(self,cod)"
        print "purpose: judge the branch is symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 18"
        print "Function Name:Is_One_Link_symbol(self,cod)"
        print "purpose: judge the branch is one link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 19"
        print "Function Name:Is_two_link_symbol(self,cod)"
        print "purpose: judge the branch is two link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 20"
        print "Function Name:Link_first_Root(self,Id,branch)"
        print "purpose: link the first root ~ or o"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 21"
        print "Function Name: Return_2Number_without_root(self,Id,branch)"
        print "purpose: get the nearest two tree_4 instance which don't have root yet"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 22"
        print "Function Name: Link_Second_Root(self,Id,branch)"
        print "purpose: link the second level branch |,&,r,d"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="        
        print "Number 23"
        print "Function Name: Set_Depth(self,branch)"
        print "purpose: set the depth of the tree_4 instances"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 24"
        print "Function Name: Get_Rule_One_Tree(self,condition)"
        print "purpose: generate the tree"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 25"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcsCFA_SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 26"
        print "Function Name:Read_xcsCFA_SSP(self,path)"
        print "purpose: read the agent"
        print "parameter path: the path of agent file"
        print"======================================================="
        print "Number 27"
        print "Function Name: Get_Max_Length(self,branches)"
        print "purpose: get the max length cod"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 28"
        print "Function Name: Get_space(self,number)"
        print "purpose: get the space"
        print "parameter number: the number of space"
        print"======================================================="
        print "Number 29"
        print "Function Name: GenMatrix(self,rows,cols,length)"
        print "purpose: get the matrix"
        print "parameter length: the length of space"
        print "parameter row: the row of matrix"
        print "parameter col the col of matrix"
        print"======================================================="
        print "Number 30"
        print "Function Name:Print_Tree_2(self,branches)"
        print "purpose: print the binary tree"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 31"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 32"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 33"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"
        
class xcsCFA_SSP:
    def __init__(self,I_condition,I_result_Tree,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Prediction,I_Experience,I_Action_Consistency,I_Action_Value):
        self.condition=I_condition
        self.result_tree=I_result_Tree
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.Action_Consistency=I_Action_Consistency
        self.Action_Value=I_Action_Value

    def Test(self):
        print 'condition',self.condition
        print 'result_Tree'#,self.result_tree
        pt=print_binary_Tree()
        pt.Print_Tree_2(self.result_tree)
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'Action_Consistency',self.Action_Consistency
        print 'Action_Value',self.Action_Value

class xcsCFA_SSP_Agent: 
    def __init__(self,I_xcsCFA_SSP):
        self.xcsCFA_SSPs=I_xcsCFA_SSP

    def Test(self):
        for ins in self.xcsCFA_SSPs:
            ins.Test()

class xcs_SSP_Translate:
    def __init__(self,I_address):
        #print 'begin read xcs SSP Agents'
        self.basic_string='xcs_SSP'#number2
        if self.basic_string in I_address or not '.txt' in I_address:
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[3]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.information_Begin_String='---->'#number5
            self.Agents=self.Generate_Agents()#number6
        else:
            self.Agents=[]
        #print 'reading xcs SSP Agents completed'

    #number7
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number8
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #number9
    def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

    #number10
    def Get_basic_Details(self,information):
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Prediction:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'ActionSetSize:' in information[i]:
                results.append(float(information[i+1]))
            elif self.information_Begin_String in information[i]:
                results.append(int(information[i-2]))
        return results

    #number11
    def Read_xcs_SSP(self,path):
        results=[]
        information =self.Read_Information(path)
        for inf in information:
            result=inf.split('\n')[0].split(' ')
            I_condition=result[0]
            details=self.Get_basic_Details(result)  
            xcs_SSP_I=xcs_SSP(I_condition,details[0],details[1],details[2],details[3],details[4],details[5],details[6],details[7])     
            results.append(xcs_SSP_I)
        xs_A=xcs_SSP_Agent(results)
        #results[0].Test()
        return xs_A    

    #number12
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number13
    def Generate_Agents(self):        
        try:
            Agents=[]
            if len(self.path)>0:
                print 'begin read xcs SSP Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    x_s_A=self.Read_xcs_SSP(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_A)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[2])
                    Agents.append(T_A)
                print 'reading xcs SSP Agents completed'
            return Agents
        except:
            error=[]
            return error

    #number14
    def Get_Agents(self):
        return self.Agents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:information_Begin_String"
        print "purpose: the symbol means the tree begin"
        print ("value",self.information_Begin_String)
        print"======================================================="
        print "Number 6"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 7"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 8"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 9"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcs SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 11"
        print "Function Name:Read_xcs_SSP(self,path)"
        print "purpose: read the agent"
        print "parameter path: the path of agent file"
        print"======================================================="
        print "Number 12"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 13"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 14"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"

class xcs_SSP:
    def __init__(self,I_condition,I_Action_Value,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Prediction,I_Experience,I_ActionSetSize):
        self.condition=I_condition
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.ActionSetSize=I_ActionSetSize
        self.Action_Value=I_Action_Value

    def Test(self):
        print 'condition',self.condition
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'ActionSetSize',self.ActionSetSize
        print 'Action_Value',self.Action_Value

class xcs_SSP_Agent:
    def __init__(self,I_xcs_SSPs):
        self.xcs_SSPs=I_xcs_SSPs

    def Test(self):
        for ins in self.xcs_SSPs:
            ins.Test()

class xcsSMA_v2_Translate:
    def __init__(self,I_address):
        self.basic_string='XcsSMA_v2'#number2
        if self.basic_string in I_address or not '.txt' in I_address:
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[4]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.information_End_String='Numerosity:'#number5
            self.q_string='q_'#number6
            self.Agents=self.Generate_Agents()#number7
        else:
            self.Agents=[]

    #number8
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number9
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #number10
    def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

    #number11
    def Get_basic_Details(self,informations):
        information=informations.split(' ')
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Prediction:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Action_Set_Size:' in information[i]:
                results.append(float(information[i+1]))
        return results

    #number12
    def split_information(self,path):
        result=[]
        Add_Flag=True
        Step=[]
        information=self.Read_Information(path)
        #print len(information)
        for i in range(0,len(information)):
            if Add_Flag:
                Step.append(information[i].split('\n')[0])
                if self.information_End_String in information[i]:
                    Add_Flag=False
                if i==len(information)-1:
                    result.append(Step)
            else:
                result.append(Step)
                Step=[]
                Step.append(information[i].split('\n')[0])
                Add_Flag=True
        return result
    
    #number13    
    def split_q_Id(self,q):
        result=q.split(self.q_string)[-1]
        return result

    #number14
    def Read_xcs_SMA(self,path):
        results=[]
        information =self.split_information(path)
        #print len(information)
        for inf in information:
            condition=inf[0]
            details=self.Get_basic_Details(inf[-1])
            use_FSMs_q=[]
            for i in range(2,len(inf)-1):
                if 'State:'in inf[i]:
                    first_q=self.split_q_Id(inf[i].split(' ')[-1])
                else:
                    q_number= self.split_q_Id(inf[i].split(':')[0])
                    q_action_inf=inf[i].split(':')[-1].split('\t')[1:-1]
                    q_result=q_action_inf[0]
                    q_active=q_action_inf[1]
                    q_action=[q_action_inf[2],q_action_inf[3]]
                    FSM_Q_use=FSM_Q(q_number,q_result,q_active,q_action)
                    use_FSMs_q.append(FSM_Q_use)
            use_FSM=FSM(use_FSMs_q,first_q)
            result= xcsSMA_v2(condition,use_FSM,details[0],details[1],details[2],details[3],details[4],details[5],details[6])
            results.append(result) 
        #results[-1].Test()
        result_agent=xcsSMA_V2_Agent(results)
        return result_agent
  
     #number15
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number16
    def Generate_Agents(self):
        Agents=[]
        try:
            if len(self.path)>0:
                print 'begin read XcsSMA_v2 Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    #x_s_A=self.Read_xcs_SMA(use_path)
                    x_s_A=self.Read_xcs_SMA_Base_List(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_A)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[2])
                    T_A.Length_Seneitive=False
                    Agents.append(T_A)
                print 'reading XcsSMA_v2 Agents completed'
            return Agents
        except:
            error=[]
            return error

    #number17
    def Get_Agents(self):
        return self.Agents

    #number18
    def Read_xcs_SMA_Base_List(self,path):
        results=[]
        information =self.split_information(path)
        #print len(information)
        for inf in information:
            condition=inf[0]
            details=self.Get_basic_Details(inf[-1])
            use_FSMs_q=[]
            input_list=[]
            for i in range(2,len(inf)-1):
                if 'State:'in inf[i]:
                    first_q=self.split_q_Id(inf[i].split(' ')[-1])
                else:
                    q_number= self.split_q_Id(inf[i].split(':')[0])
                    q_action_inf=inf[i].split(':')[-1].split('\t')[1:-1]
                    q_result=q_action_inf[0]
                    q_active=q_action_inf[1]
                    q_action=[q_action_inf[2],q_action_inf[3]]
                    FSM_Q_use=FSM_Q(q_number,q_result,q_active,q_action)
                    use_FSMs_q.append(FSM_Q_use)
            for length in range(0,len(use_FSMs_q)):
                for instance in use_FSMs_q:
                    if int(instance.q_number)==length:
                        input_list.append([instance.result,instance.active,instance.Action[0],instance.Action[1]])

            use_FSM=FSM(input_list,first_q)
            result= xcsSMA_v2(condition,use_FSM,details[0],details[1],details[2],details[3],details[4],details[5],details[6])
            results.append(result) 
        #results[-1].Test()
        result_agent=xcsSMA_V2_Agent(results)
        return result_agent

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:information_End_String"
        print "purpose: the symbol means the tree begin"
        print ("value",self.information_End_String)
        print"======================================================="
        print "Number 6"
        print "Name:q_string"
        print "purpose: the string use to split q_"
        print ("value",self.q_string)
        print"======================================================="
        print "Number 7"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 8"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 9"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 11"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcs SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 12"
        print "Function Name:split_information(self,path)"
        print "purpose: split the information into piece"
        print "parameter path: the path of txt file"
        print"======================================================="
        print "Number 13"
        print "Function Name:split_q_Id(self,q)"
        print "purpose: split the q and get the number"
        print "parameter q: the string contain q"
        print"======================================================="
        print "Number 14"
        print "Function Name:Read_xcs_SMA(self,path)"
        print "purpose: read the agent"
        print "parameter path: the path of agent file"
        print"======================================================="
        print "Number 15"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 16"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 17"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"
        print"======================================================="
        print "Number 18"
        print "Function Name:Read_xcs_SMA_Base_List(self,path)"
        print "purpose: read the agent but use list instead of instance"
        print "parameter path: the path of agent file"
        print"======================================================="

class xcsSMA_V2_Agent:
    def __init__(self,I_xcs_SMA):
        self.xcs_SMA=I_xcs_SMA

    def Test(self):
        for ins in self.xcs_SMA:
            ins.Test()

class xcsSMA_v2:
     def __init__(self,I_condition,I_FSM,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Prediction,I_Experience,I_ActionSetSize):
        self.condition=I_condition
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.ActionSetSize=I_ActionSetSize
        self.FSM=I_FSM

     def Test(self):
        print 'condition',self.condition
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'ActionSetSize',self.ActionSetSize
        print 'FSM'
        self.FSM.Test() 

class FSM:
    def __init__(self,I_FSM_q,I_Start_q):
        self.FSM_q=I_FSM_q
        self.Start_q=I_Start_q

    def Test(self):
        print'========================================================'
        print 'FSM_q',len(self.FSM_q)
        for instance in self.FSM_q:
            print instance
        print'========================================================'
        print 'Start_q',self.Start_q

class FSM_Q:
    def __init__(self,I_q_number,I_result,I_active,I_Action):
        self.q_number=I_q_number
        self.result=I_result
        self.active=I_active
        self.Action=I_Action

    def Test(self):
        print 'number',self.q_number
        print 'result',self.result
        print 'active',self.active
        print 'Action',self.Action

class xcsf_Boolean_Translate: 
     def __init__(self,I_address):
        self.basic_string='xcsf_Boolean'#number2
        if self.basic_string in I_address or not '.txt' in I_address:
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[5]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.prediction_End_String='---->'#number5
            self.Agents=self.Generate_Agents()#number6
        else:
            self.Agents=[]

    #number7
     def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number8
     def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

     #number9
     def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

     #number10
     def Get_basic_Details(self,information):
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'ActionSetSize:' in information[i]:
                results.append(float(information[i+1]))
        return results

     #number11
     def Read_xcsf_Boolean(self,path):
        results=[]
        information =self.Read_Information(path)
        for inf in information:
            result=inf.split('\n')[0].split(self.prediction_End_String)
            result_1=result[0].split(' ')
            condition=result_1[0]
            action=result_1[2]
            begin_flag=False
            prediction=[]
            for i in range(2,len(result_1)):               
                if begin_flag and result_1[i]!='':
                    prediction.append(float(result_1[i]))
                if 'Prediction:' in result_1[i]:
                    begin_flag=True
            detail=self.Get_basic_Details(result[1].split(' '))
            x_b=xcsf_Boolean(condition,action,prediction,detail[0],detail[1],detail[2],detail[3],detail[4],detail[5])
            results.append(x_b)
        Agent=xcsf_Boolean_Agent(results)
        return Agent
 
     #number12
     def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

     #number13
     def Generate_Agents(self):
        Agents=[]
        try:
            if len(self.path)>0:
                print 'begin read xcsf_Boolean Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    x_s_b=self.Read_xcsf_Boolean(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_b)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[2])
                    T_A.Length_Seneitive=False
                    Agents.append(T_A)
                print 'reading xcsf_Boolean Agents completed'
            return Agents
        except:
            print 'fail'
            error=[]
            return error

     #number14
     def Get_Agents(self):
        return self.Agents

     def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:prediction_End_String"
        print "purpose: the symbol means the prediction end"
        print ("value",self.prediction_End_String)
        print"======================================================="
        print "Number 6"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 7"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 8"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 9"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcs SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 11"
        print "Function Name:Read_xcsf_Boolean(self,path)"
        print "purpose: read the agent"
        print "parameter path: the path of agent file"
        print"======================================================="
        print "Number 12"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 13"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 14"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"

        self.Read_xcsf_Boolean(self.path[0])
        
class xcsf_Boolean:
     def __init__(self,I_condition,I_Action,I_Prediction,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Experience,I_ActionSetSize):
        self.condition=I_condition
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.ActionSetSize=I_ActionSetSize
        self.Action=I_Action

     def Test(self):
        print 'condition',self.condition
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'ActionSetSize',self.ActionSetSize
        print 'Action',self.Action
        
class xcsf_Boolean_Agent:
    def __init__(self,I_xcsf_Boolean):
        self.xcsf_Boolean=I_xcsf_Boolean

    def Test(self):
        for ins in self.xcsf_Boolean:
            ins.Test()
                  
class xcsSMA_v2_adder_Translate:
    def __init__(self,I_address):
        self.basic_string='xcsSMAv2_adder'#number2
        if self.basic_string in I_address or not '.txt' in I_address:
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[6]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.information_End_String='Numerosity:'#number5
            self.q_string='q_'#number6
            self.Agents=self.Generate_Agents()#number7
        else:
            self.Agents=[]

    #number8
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number9
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #number10
    def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

    #number11
    def Get_basic_Details(self,informations):
        information=informations.split(' ')
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Prediction:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Action_Set_Size:' in information[i]:
                results.append(float(information[i+1]))
        return results

    #number12
    def split_information(self,path):
        result=[]
        Add_Flag=True
        Step=[]
        information=self.Read_Information(path)
        #print len(information)
        for i in range(0,len(information)):
            if Add_Flag:
                Step.append(information[i].split('\n')[0])
                if self.information_End_String in information[i]:
                    Add_Flag=False
                if i==len(information)-1:
                    result.append(Step)
            else:
                result.append(Step)
                Step=[]
                Step.append(information[i].split('\n')[0])
                Add_Flag=True
        return result
    
    #number13    
    def split_q_Id(self,q):
        result=q.split(self.q_string)[-1]
        return result

    #number14
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number15
    def Generate_Agents(self):
        Agents=[]
        try:
            if len(self.path)>0:
                print 'begin read XcsSMA_v2_adder Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    #x_s_A=self.Read_xcs_SMA(use_path)
                    x_s_A=self.Read_xcs_SMA_Add_Base_List(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_A)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[2])
                    Agents.append(T_A)
                print 'reading XcsSMA_v2_adder Agents completed'
            return Agents
        except:
            error=[]
            return error

    #number17
    def Read_xcs_SMA_Add_Base_List(self,path):
        results=[]
        information =self.split_information(path)
        #print len(information)
        for inf in information:
            condition=inf[0]
            details=self.Get_basic_Details(inf[-1])
            input_list=[0]*(len(inf)-4)
            for i in range(2,len(inf)-1):
                if 'State:'in inf[i]:
                    first_q=self.split_q_Id(inf[i].split(' ')[-1])
                else:
                    q_number= self.split_q_Id(inf[i].split(':')[0])
                    q_action_inf=inf[i].split(':')[-1].split('\t')[1:-1]
                    q_result=q_action_inf[0]
                    q_active=q_action_inf[1]
                    q_action=[q_action_inf[2],q_action_inf[3],q_action_inf[4],q_action_inf[5]]
                    input_list[int(q_number)]=([q_result,q_active,q_action])
                    #print len(input_list)
            use_FSM=FSM(input_list,first_q)
            result= xcsSMA_v2_adder(condition,use_FSM,details[0],details[1],details[2],details[3],details[4],details[5],details[6])
            results.append(result) 
        #results[-1].Test()
        result_agent=xcsSMA_V2_adder_Agent(results)
        return result_agent

    #number16
    def Get_Agents(self):
        return self.Agents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:information_End_String"
        print "purpose: the symbol means the tree begin"
        print ("value",self.information_End_String)
        print"======================================================="
        print "Number 6"
        print "Name:q_string"
        print "purpose: the string use to split q_"
        print ("value",self.q_string)
        print"======================================================="
        print "Number 7"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 8"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 9"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 10"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 11"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcs SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 12"
        print "Function Name:split_information(self,path)"
        print "purpose: split the information into piece"
        print "parameter path: the path of txt file"
        print"======================================================="
        print "Number 13"
        print "Function Name:split_q_Id(self,q)"
        print "purpose: split the q and get the number"
        print "parameter q: the string contain q"
        print"======================================================="
        print "Number 14"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 15"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 16"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"
        print"======================================================="
        print "Number 17"
        print "Function Name:Read_xcs_SMA_Add_Base_List(self,path)"
        print "purpose: read the agent but use list instead of instance"
        print "parameter path: the path of agent file"
        print"======================================================="

class xcsSMA_V2_adder_Agent:
    def __init__(self,I_xcs_SMA_adder):
        self.xcs_SMA_adder=I_xcs_SMA_adder

    def Test(self):
        for ins in self.xcs_SMA_adder:
            ins.Test()

class xcsSMA_v2_adder:
     def __init__(self,I_condition,I_FSM,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Prediction,I_Experience,I_ActionSetSize):
        self.condition=I_condition
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.ActionSetSize=I_ActionSetSize
        self.FSM=I_FSM

     def Test(self):
        print 'condition',self.condition
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'ActionSetSize',self.ActionSetSize
        print 'FSM'
        self.FSM.Test()                    

class xcsrContA_Transfer:

    def __init__(self,I_address):
        self.basic_string='xcsrContA'#number2
        if self.basic_string in I_address or not '.txt' in I_address:
            self.address=I_address#number1
            self.AC=Agent_pool_Controller()
        
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[7]#number3
            self.basic_config=Basic_Config()
            if '.txt' in self.address and self.basic_string in self.address:
                self.path=[0]*1
                self.path[0]=self.address
            else:
                self.path=self.Get_current_files()#number4
            self.Tree_Begin_String='--->'#number5
            self.Tree_End_String='o'#number6
            self.Terminal_string=['D','.']#number7
            self.symbol_string=['&','|','d','r','~','o','+','-','*','/','%']#number8
            self.one_link_symbol=['~','o']#number9
            self.two_link_symbol=['&','|','d','r','+','-','*','/','%']#number10
            self.count_operator=-1
            self.Agents=self.Generate_Agents()#number11
        else:
            self.Agents=[]

    #number12
    def Get_Path(self):
        path=self.AC.Get_Agent_Pool_Name_List()
        for P in path:
            if self.address in P:
                return P

    #number13
    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    #number14
    def Get_current_files(self):
        path=self.Get_Path()
        address=self.AC.Get_All_Agents(path)
        useful=[]
        for add in address:
            if self.basic_string in add:
                useful.append(add)
        return useful

    #number15
    def Is_Termianl(self,cod):
        for t in self.Terminal_string:
            if t in cod:
                return True
        return False

    #number16
    def Is_symbol(self,cod):
        for s in self.symbol_string:
            if s==cod:
                return True
        return False

    #number17
    def Is_One_Link_symbol(self,cod):
        for s in self.one_link_symbol:
            if s==cod:
                return True
        return False

    #number18
    def Is_two_link_symbol(self,cod):
        for s in self.two_link_symbol:
            if s==cod:
                return True
        return False

    #number19
    def Link_first_Root(self,Id,branch):
        if Id-1>=0:
            branch[Id-1].Set_Root(branch[Id])
            branch[Id].Set_Left(branch[Id-1])
    
    #number20        
    def Return_2Number_without_root(self,Id,branch):
        result=[]
        for i in range(0,Id):
            if branch[Id-i-1].root==None:
                result.append(Id-i-1)
            if len(result)==2:
                return result

    #number21
    def Link_Second_Root(self,Id,branch):
        Ids=self.Return_2Number_without_root(Id,branch)
        branch[Id].Set_Left(branch[Ids[0]])
        branch[Id].Set_Right(branch[Ids[1]])
        branch[Ids[0]].Set_Root(branch[Id])
        branch[Ids[1]].Set_Root(branch[Id])

    #number22                                
    def Set_Depth(self,branch):        
        if branch.Left!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Left)
        if branch.Right!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Right)
        if branch.Type==branch.Type_Id[0] or branch.Canset_Depth==True:
            branch.Set_Depth(self.count_operator)
            if branch.root!=None:
                 branch.root.Canset_Depth=True
                 #print self.count_operator
                 self.count_operator=self.count_operator-1

    #number23
    def Get_Rule_One_Tree(self,condition):
        branches=[]
        symbol_number=[]
        for i in range(0,len(condition)):
            Tree=Tree_4(condition[i])
            if self.Is_Termianl(condition[i]):
                Tree.Set_Type(0)
            elif self.Is_symbol(condition[i]):
                Tree.Set_Type(1)
                symbol_number.append(i)
            branches.append(Tree)
        #print len(branches)
        #print condition
        #print branches[0]
        for i in symbol_number:
            if self.Is_One_Link_symbol(branches[i].value):
                self.Link_first_Root(i,branches)
        for i in symbol_number:
            if self.Is_two_link_symbol(branches[i].value):
                self.Link_Second_Root(i,branches)
        #for i in branches:
        #    i.Test()
        #branches[-1].Test()
        self.Set_Depth(branches[-1])
        self.count_operator=-1
        #for bran in branches:
        #    bran.Test()
        return branches

    #number24
    def Get_basic_Details(self,information):
        results=[]
        for i in range(0,len(information)):
            if 'Numerosity:'in information[i]:
                results.append(int( information[i+1]))
            elif 'Accuracy:' in information[i]:
                results.append(float (information[i+1]))
            elif 'Fitness:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Error:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Prediction:' in information[i]:
                results.append(float(information[i+1]))
            elif 'Experience:' in information[i]:
                results.append(float(information[i+1]))
            elif 'ActionSetSize:' in information[i]:
                results.append(float(information[i+1]))
            elif 'TimeStamp:' in information[i]:
                results.append(int(information[i+1]))
        return results

    #number25
    def Read_xcsrContA(self,path):
        results=[]
        information =self.Read_Information(path)
        for inf in information:
            result=inf.split('\n')[0]
            result_1=result.split(self.Tree_Begin_String)
            result_1_0=result_1[0].split(':')[0].split(' ')[:-2]            
            I_condition=result_1_0
            result_2= result_1[1].split('\t')
            symbols= result_2[1].split(' ')[:-1]
            #print symbols
            I_result_Tree=self.Get_Rule_One_Tree(symbols)            
            details=self.Get_basic_Details(result_2[2:])  
            xcsrContA_I=xcsrContA(I_condition,I_result_Tree,details[0],details[1],details[2],details[3],details[4],details[5],details[6],details[7])     
            results.append(xcsrContA_I)
        xs_A=xcsrContA_Agent(results)
        #results[-1].Test()
        return xs_A  

    #number26
    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    #number27
    def Generate_Agents(self):
        Agents=[]
        try:
            if len(self.path)>0:
                print 'begin read xcsrContA Agents'
                for use_path in self.path:
                    question=self.Get_Question(use_path)
                    x_s_A=self.Read_xcsrContA(use_path)
                    T_A=Trained_Agent(self.Type,question,x_s_A)
                    T_A.Name=use_path
                    T_A.Length=int(use_path.split('\\')[-1].split('_')[1])
                    Agents.append(T_A)
                print 'reading xcsrContA Agents completed'
            return Agents
        except:
            error=[]
            return error

    #number28
    def Get_Agents(self):
        return self.Agents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the agent pool address you use"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:basic_string"
        print "purpose: the basic string of this agent"
        print ("value",self.basic_string)
        print"======================================================="
        print "Number 3"
        print "Name:Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Type)
        print"======================================================="
        print "Number 4"
        print "Name:path"
        print "purpose: the path of the txt you use to read agent"
        print ("value",self.path)
        print"======================================================="
        print "Number 5"
        print "Name:Tree_Begin_String"
        print "purpose: the symbol means the tree begin"
        print ("value",self.Tree_Begin_String)
        print"======================================================="
        print "Number 6"
        print "Name:Tree_End_String"
        print "purpose: the symbol means the tree end"
        print ("value",self.Tree_End_String)
        print"======================================================="
        print "Number 7"
        print "Name:Terminal_string"
        print "purpose: the symbol means it is the terminal of the tree"
        print ("value",self.Terminal_string)
        print"======================================================="
        print "Number 8"
        print "Name:symbol_string"
        print "purpose: the symbol string"
        print ("value",self.symbol_string)
        print"======================================================="
        print "Number 9"
        print "Name:one_link_symbol"
        print "purpose: the symbol means link first"
        print ("value",self.one_link_symbol)
        print"======================================================="
        print "Number 10"
        print "Name:two_link_symbol"
        print "purpose: the symbol means link second"
        print ("value",self.two_link_symbol)
        print"======================================================="
        print "Number 11"
        print "Name:Agents"
        print "purpose: the result agents"
        print"======================================================="
        print "Number 12"
        print "Function Name:Get_Path(self)"
        print "purpose: get the path"
        print"======================================================="
        print "Number 13"
        print "Function Name:Read_Information(self,path)"
        print "purpose: get the information of the path"
        print"======================================================="
        print "Number 14"
        print "Function Name:Get_current_files(self)"
        print "purpose: get the current files"
        print"======================================================="
        print "Number 15"
        print "Function Name:Is_Termianl(self,cod)"
        print "purpose: judge the branch is terminal or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 16"
        print "Function Name:Is_symbol(self,cod)"
        print "purpose: judge the branch is symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 17"
        print "Function Name:Is_One_Link_symbol(self,cod)"
        print "purpose: judge the branch is one link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 18"
        print "Function Name:Is_two_link_symbol(self,cod)"
        print "purpose: judge the branch is two link symbol or not"
        print "parameter cod: the condition"
        print"======================================================="
        print "Number 19"
        print "Function Name:Link_first_Root(self,Id,branch)"
        print "purpose: link the first root ~ or o"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 20"
        print "Function Name: Return_2Number_without_root(self,Id,branch)"
        print "purpose: get the nearest two tree_4 instance which don't have root yet"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 21"
        print "Function Name: Link_Second_Root(self,Id,branch)"
        print "purpose: link the second level branch |,&,r,d"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="        
        print "Number 22"
        print "Function Name: Set_Depth(self,branch)"
        print "purpose: set the depth of the tree_4 instances"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 23"
        print "Function Name: Get_Rule_One_Tree(self,condition)"
        print "purpose: generate the tree"
        print "parameter Id: the Id of branch"
        print "parameter branch: a set of tree_4 instances"
        print"======================================================="
        print "Number 24"
        print "Function Name:Get_basic_Details(self,information)"
        print "purpose: get the details parameter of the xcsCFA_SSP"
        print "parameter information: one information come from the txt"
        print"======================================================="
        print "Number 25"
        print "Function Name:Read_xcsrContA(self,path)"
        print "purpose: read the agent"
        print "parameter path: the path of agent file"
        print"======================================================="
        print "Number 26"
        print "Function Name: Get_Question(self,Address)"
        print "purpose: get the question type"
        print "paramter address: the path of the file"
        print"======================================================="
        print "Number 27"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the trained agent"
        print"======================================================="
        print "Number 28"
        print "Function Name: Get_Agents(self)"
        print "purpose: return the trained agent"

class xcsrContA_Agent:
    def __init__(self,I_xcsrContA):
        self.xcsrContA=I_xcsrContA

    def Test(self):
        for ins in self.xcsrContA:
            ins.Test()

class xcsrContA:
     def __init__(self,I_condition,I_Tree,I_Numerosity,I_Accuracy,I_Fitness,I_Prediction_Error,I_Prediction,I_Experience,I_ActionSetSize,I_TimeStamp):
        self.condition=I_condition
        self.Tree=I_Tree
        self.Numerosity=I_Numerosity
        self.accuracy=I_Accuracy
        self.Fitness=I_Fitness
        self.Prediction_Error=I_Prediction_Error
        self.Prediction=I_Prediction
        self.Experience=I_Experience
        self.ActionSetSize=I_ActionSetSize
        self.TimeStamp=I_TimeStamp

     def Test(self):
        print 'condition',self.condition
        print 'Numerosity',self.Numerosity
        print 'Accuracy',self.accuracy
        print 'Fitness',self.Fitness
        print 'Prediction_Error',self.Prediction_Error
        print 'Prediction',self.Prediction
        print 'Experience',self.Experience
        print 'ActionSetSize',self.ActionSetSize
        print 'TimeStamp',self.TimeStamp
        print 'Tree'
        pt=print_binary_Tree()
        pt.Print_Tree_2(self.Tree)

class xcscfunctions_Translate:
    def __init__(self,address):
        self.type='xcscfunction'
        self.address=address
        self.CF_Value='CFS'
        self.Rule_Value='Rules'
        self.Use_R_Value='UseRul'
        self.split_value='$$'
        self.use_address=self.split_Address()
        #print self.use_address
        if len(self.use_address)==3:
            self.Tree_End_String='o'

            self.Rule_Information=self.Read_information(self.use_address[1])
            self.CFS_Information=self.Read_information(self.use_address[0])
            self.Use_Rule_Information=self.Read_information(self.use_address[2])


            self.initial_Functions=self.Read_initial_Functions()
            self.Use_CFS=self.Read_CFS()
            self.Use_Rules=self.Read_Rule_Use()
        
            #for i in self.initial_Functions:
            #    i.Test()

            #for i in self.Use_CFS:
            #    i.Test()

            #for i in self.Use_Rules:
            #    i.Test()
        

            self.Terminal_string=['CF_','L']#number14
            self.symbol_string=['o','+','-','*','/','=','$','@','[',']','{']#number15
            self.one_link_symbol=['o','=','$','[',']','{']#number16
            self.two_link_symbol=['+','-','*','/','@']#number17
            self.extend_symbols()
            #print self.Terminal_string
            #print self.symbol_string
            #print self.one_link_symbol
            #print self.two_link_symbol
            self.count_operator=-1

            self.Generate_Tree()
            #for i in self.initial_Functions:
            #    i.Test_Tree()

            #for i in self.Use_CFS:
            #   i.Test_Tree()

            #for i in self.Use_Rules:
            #    i.Test_Tree()
        
            self.count_operator=-1
            self.myconfig=Agent_pool_config()
            self.Type=self.myconfig.Agent_Type[8]#number1
            self.AC=Agent_pool_Controller()
            self.basic_string='xcsCFCavg'#number4
            self.basic_config=Basic_Config()
            self.Agents=self.Generate_Agents()
        else:
            self.Agents=None

    def split_Address(self):
        pair=self.address.split(self.split_value)
        CFS=None
        Rules=None
        use_Rule=None
        for add in pair:
            if self.CF_Value in add:
                CFS=add
            if self.Rule_Value in add:
                Rules=add
            if self.Use_R_Value in add:
                use_Rule=add
        result=[]
        if CFS!=None:
            result.append(CFS)
        if Rules!=None:
            result.append(Rules)
        if use_Rule!=None:
            result.append(use_Rule)
        return result

    def Read_information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information

    def Read_initial_Functions(self):
        function_begin='->Function:Begin'
        function_end='->Function:End'
        rule_begin='Rule:Begin'
        rule_end='Rule:End'
        group_begin='Group:Begin'
        group_num=0
        result_functions=[]
        result_Rules=[]
        rule_Id=1
        for i in range(0,len(self.Rule_Information)):
            if group_begin in self.Rule_Information[i]:
                group_num=group_num+1

            if function_begin in self.Rule_Information[i]:
                Name=self.Rule_Information[i+1].split('\n')[0]
                ID= self.Rule_Information[i+2].split('\n')[0].split('-')[1]
                Active= self.Rule_Information[i+3].split('\n')[0].split(' ')[1]
                Num_Rules=self.Rule_Information[i+3].split('\n')[0].split(' ')[2]
                Inp_Num=self.Rule_Information[i+3].split('\n')[0].split(' ')[3]
                F_U=xcscfunctions_Functions()
                F_U.Name=Name
                F_U.Id=ID
                F_U.Input_Number=int(Inp_Num)
                F_U.active=int(Active)
                F_U.Number_Rules=int(Num_Rules)
                F_U.Group_Id=group_num

            if rule_begin in self.Rule_Information[i]:
                rule=xcscfunctions_Rule()
                Tree= self.Get_symbols( self.Rule_Information[i+1].split('\n')[0])
                rule.Id=rule_Id
                rule_Id=rule_Id+1
                rule.Tree=Tree

            if rule_end in self.Rule_Information[i]:
                result_Rules.append(rule)

            if function_end in self.Rule_Information[i]:
                F_U.Rules=result_Rules
                result_functions.append(F_U)
                result_Rules=[]
                rule_Id=1

        return result_functions
        
    def Read_CFS(self):
        CF_String='--------->'
        result_CFS=[]
        for i in range(0,len(self.CFS_Information)):
            if CF_String in self.CFS_Information[i]:
                CF_U= self.Get_symbols(self.CFS_Information[i].split('\n')[0].split(CF_String)[0])
                Id=self.CFS_Information[i].split('\n')[0].split(CF_String)[-1]
                XCS_cf=xcscfunctions_CFs()
                XCS_cf.CFS=CF_U
                XCS_cf.Id=Id
                result_CFS.append(XCS_cf)
        return result_CFS

    def Read_Rule_Use(self):
        finialsymbol='Numerosity:'
        result=[]
        for i in range(0,len(self.Use_Rule_Information)):
            if finialsymbol in self.Use_Rule_Information[i]:
                U_R=xcscfunctions_Use_Rule()
                symbols= self.Get_symbols( self.Use_Rule_Information[i-1].split('\n')[0])
                condition=self.Use_Rule_Information[i-2].split('\n')[0].split(' ')[:-1]
                infs=self.Use_Rule_Information[i].split('\n')[0].split(' ')
                for j in range(0,len(infs)):
                    if 'Numerosity:' in infs[j]:
                        U_R.Numerosity=int(infs[j+1])
                    elif 'Accuracy:' in infs[j]:
                        U_R.Accuracy=float(infs[j+1])
                    elif 'Fitness:' in infs[j]:
                        U_R.Fitness=float(infs[j+1])
                    elif 'Error:' in infs[j]:
                        U_R.Prediction_Error=float(infs[j+1])
                    elif 'Prediction:' in infs[j]:
                        U_R.Prediction=float(infs[j+1])
                    elif 'Experience:' in infs[j]:
                        U_R.Experience=int(infs[j+1])
                    elif 'Specificness:' in infs[j]:
                        U_R.Specificness=int(infs[j+1])

                U_R.Action= symbols[1:]
                U_R.Condition=condition
                result.append(U_R)
        return result      

    def extend_symbols(self):
        for f in self.initial_Functions:
            if f.Name not in  self.symbol_string and f.Input_Number>0:
                self.symbol_string.append(f.Name)

            if f.Input_Number==0:
                self.Terminal_string.append(f.Name)

            if f.Input_Number==1:
                self.one_link_symbol.append(f.Name)

            if f.Input_Number==2:
                self.two_link_symbol.append(f.Name)

    def Get_symbols(self,information):
        number =0
        beginflag=False
        result=[]
        infs= information.split(' ')
        for i in infs:
            if i!='':
                result.append(i)
        return result

    #number16
    def Is_Termianl(self,cod):
        for t in self.Terminal_string:
            if t in cod:
                return True
        return False

    #number17
    def Is_symbol(self,cod):
        for s in self.symbol_string:
            if s==cod:
                return True
        return False

    #number18
    def Is_One_Link_symbol(self,cod):
        for s in self.one_link_symbol:
            if s==cod:
                return True
        return False

    #number19
    def Is_two_link_symbol(self,cod):
        for s in self.two_link_symbol:
            if s==cod:
                return True
        return False

    #number20
    def Link_first_Root(self,Id,branch):
        if Id-1>=0:
            branch[Id-1].Set_Root(branch[Id])
            branch[Id].Set_Left(branch[Id-1])
    
    #number21        
    def Return_2Number_without_root(self,Id,branch):
        result=[]
        for i in range(0,Id):
            if branch[Id-i-1].root==None:
                result.append(Id-i-1)
            if len(result)==2:
                return result

    #number22
    def Link_Second_Root(self,Id,branch):
        Ids=self.Return_2Number_without_root(Id,branch)
        branch[Id].Set_Left(branch[Ids[0]])
        branch[Id].Set_Right(branch[Ids[1]])
        branch[Ids[0]].Set_Root(branch[Id])
        branch[Ids[1]].Set_Root(branch[Id])

    #number23                                
    def Set_Depth(self,branch):        
        if branch.Left!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Left)
        if branch.Right!=None:
            self.count_operator=self.count_operator+1
            self.Set_Depth(branch.Right)
        if branch.Type==branch.Type_Id[0] or branch.Canset_Depth==True:
            branch.Set_Depth(self.count_operator)
            if branch.root!=None:
                 branch.root.Canset_Depth=True
                 #print self.count_operator
                 self.count_operator=self.count_operator-1

    #number24
    def Get_Rule_One_Tree(self,condition):
        branches=[]
        symbol_number=[]
        for i in range(0,len(condition)):
            Tree=Tree_4(condition[i])
            if self.Is_Termianl(condition[i]):
                Tree.Set_Type(0)
            elif self.Is_symbol(condition[i]):
                Tree.Set_Type(1)
                symbol_number.append(i)
            branches.append(Tree)
        #print len(branches)
        #print condition
        #print branches[0]
        for i in symbol_number:
            if self.Is_One_Link_symbol(branches[i].value):
                self.Link_first_Root(i,branches)
        for i in symbol_number:
            if self.Is_two_link_symbol(branches[i].value):
                self.Link_Second_Root(i,branches)
        #for i in branches:
        #    i.Test()
        #branches[-1].Test()
        self.Set_Depth(branches[-1])
        self.count_operator=-1
        #for bran in branches:
        #    bran.Test()
        return branches

    def Generate_Tree(self):
        for fun in self.initial_Functions:
            TREES=[]
            r=fun.Rules
            if r !=None:
                for rul in r:
                    TREE_RULE=self.Get_Rule_One_Tree(rul.Tree)
                    x_r= xcscfunctions_Rule()
                    x_r.Id=rul.Id
                    x_r.Tree=TREE_RULE
                    TREES.append(x_r)
            fun.Rules=TREES
        for inf in self.Use_CFS:
            tree=inf.CFS
            inf.CFS=self.Get_Rule_One_Tree(tree)

        for rul in self.Use_Rules:
            tree=rul.Action
            rul.Action=self.Get_Rule_One_Tree(tree)


    def Get_Question(self,Address):
        if self.basic_config.Document_Questions[0] in Address:
            question=self.basic_config.Question_Types[0]
        elif self.basic_config.Document_Questions[7] in Address:
            question=self.basic_config.Question_Types[7]
        elif self.basic_config.Document_Questions[4] in Address:
            question=self.basic_config.Question_Types[4]
        elif self.basic_config.Document_Questions[1] in Address:
            question=self.basic_config.Question_Types[1]
        elif self.basic_config.Document_Questions[2] in Address:
            question=self.basic_config.Question_Types[2]
        elif self.basic_config.Document_Questions[3] in Address:
            question=self.basic_config.Question_Types[3]
        elif self.basic_config.Document_Questions[5] in Address:
            question=self.basic_config.Question_Types[5]
        elif self.basic_config.Document_Questions[6] in Address:
            question=self.basic_config.Question_Types[6]
        else:
            question='unknown'
            #question=None
        return question

    def Read_xcsCFA(self):
        X_A=xcscfunctions_Agent()
        X_A.CFs=self.Use_CFS
        X_A.Functions=self.initial_Functions
        X_A.Rule=self.Use_Rules
        return X_A

    def Generate_Agents(self):
        #try:
            Agents=[]
            if len(self.use_address)>0:
                print 'begin read xcsCFA Agents'                
                question=self.Get_Question(self.use_address[0])
                x_s_A=self.Read_xcsCFA()
                T_A=Trained_Agent(self.Type,question,x_s_A)
                T_A.Name=self.address
                T_A.Length=int(self.use_address[0].split('\\')[-1].split('_')[1])
                Agents.append(T_A)
                print 'reading xcsCFA Agents completed'
            return Agents

    def Get_Agents(self):
        return self.Agents


    def Test(self):
        #print self.use_address
        #self.Read_initial_Functions()
        #self.Read_CFS()
        print 1

class xcscfunctions_Functions:
    def __init__(self):
        self.Input_Number=None
        self.Name=None
        self.Id=None
        self.Rules=None 
        self.active=None
        self.Number_Rules=None
        self.Group_Id=None           

    def Test(self):
        print'================================================='
        print 'Id', self.Id
        print 'Input Number',self.Input_Number
        print 'Name',self.Name        
        print 'Rules:'
        if self.Rules!=None:
            for r in self.Rules:
                r.Test()
        print 'active',self.active
        print 'Number Rules',self.Number_Rules
        print 'group Id',self.Group_Id
        print'================================================='

    def Test_Tree(self):
        B_p=print_binary_Tree()
        print'================================================='
        print 'Id', self.Id
        print 'Input Number',self.Input_Number
        print 'Name',self.Name        
        print 'Rules:'
        if self.Rules!=None:
            for r in self.Rules:
                print'================================================='
                B_p.Print_Tree_2(r.Tree)
                print'================================================='
        print 'active',self.active
        print 'Number Rules',self.Number_Rules
        print 'group Id',self.Group_Id
        print'================================================='

class xcscfunctions_Rule:
    def __init__(self):
        self.Tree=None
        self.Id=None

    def Test(self):
        print self.Tree
        print self.Id

class xcscfunctions_CFs:
    def __init__(self):
        self.CFS=None
        self.Id=None

    def Test(self):
        print'======================================'
        print 'Id',self.Id
        print 'CFS',self.CFS
        print'======================================'

    def Test_Tree(self):
        B_p=print_binary_Tree()
        print'======================================'
        print 'Id',self.Id
        print 'CFS'
        print B_p.Print_Tree_2(self.CFS)
        print len(self.CFS)
        print'======================================'

class xcscfunctions_Use_Rule:
    def __init__(self):
        self.Action=None
        self.Condition=None
        self.Numerosity=None
        self.Accuracy=None
        self.Fitness=None
        self.Prediction_Error=None
        self.Prediction=None
        self.Experience=None
        self.Specificness=None
    def Test(self):
        print 'Action',self.Action
        print 'Condition',self.Condition
        print 'Numerosity:',self.Numerosity
        print 'Accuracy:',self.Accuracy
        print 'Fitness:',self.Fitness
        print 'Prediction Error:',self.Prediction_Error
        print 'Prediction:',self.Prediction
        print'Experience:',self.Experience
        print'Specificness:',self.Specificness

    def Test_Tree(self):
        B_p=print_binary_Tree()
        print'======================================'
        print 'Action'
        print B_p.Print_Tree_2(self.Action)
        print 'Condition',self.Condition
        print 'Numerosity:',self.Numerosity
        print 'Accuracy:',self.Accuracy
        print 'Fitness:',self.Fitness
        print 'Prediction Error:',self.Prediction_Error
        print 'Prediction:',self.Prediction
        print'Experience:',self.Experience
        print'Specificness:',self.Specificness

class xcscfunctions_Agent:
    def __init__(self):
        self.Rule=None
        self.CFs=None 
        self.Functions=None 

    def Test_1(self):
        for i in self.CFs:
            i.Test_Tree()
        for i in self.Functions:
            i.Test_Tree()
        for i in self.Rule:
            i.Test_Tree()

    def Test(self):
        for i in self.CFs:
            i.Test()
        for i in self.Functions:
            i.Test()
        for i in self.Rule:
            i.Test()
              
#most important 
class Read_Agents:
    def __init__(self,I_address):
        self.address=I_address

    #number1
    def Read_Agent(self):
        agents=[]
        agent_0=xcsCFCavg_Translate(self.address)
        agent_1=xcsCFA_SSP_Translate(self.address)
        agent_2=xcs_SSP_Translate(self.address)
        agent_3=xcsSMA_v2_Translate(self.address)
        agent_4=xcsf_Boolean_Translate(self.address)
        agent_5=xcsSMA_v2_adder_Translate(self.address)
        agent_6=xcsrContA_Transfer(self.address)
        agent_7=xcscfunctions_Translate(self.address)

        uagent_0=agent_0.Get_Mapped_Agent()
        uagent_1=agent_1.Get_Agents()
        uagent_2=agent_2.Get_Agents()
        uagent_3=agent_3.Get_Agents()
        uagent_4=agent_4.Get_Agents()
        uagent_5=agent_5.Get_Agents()
        uagent_6=agent_6.Get_Agents()
        uagent_7=agent_7.Get_Agents()

        if uagent_0!=None and len(uagent_0)>0:
            for age in uagent_0:
                agents.append(age)
        if uagent_1!=None and len(uagent_1)>0:
            for age in uagent_1:
                agents.append(age)
        if uagent_2!=None and len(uagent_2)>0:
            for age in uagent_2:
                agents.append(age)
        if uagent_3!=None and len(uagent_3)>0:
            for age in uagent_3:
                agents.append(age)
        if uagent_4!=None and len(uagent_4)>0:
            for age in uagent_4:
                agents.append(age)
        if uagent_5!=None and len(uagent_5)>0:
            for age in uagent_5:
                agents.append(age)     
        if uagent_6!=None and len(uagent_6)>0:
            for age in uagent_6:
                agents.append(age)      
        if uagent_7!=None and len(uagent_7)>0:
            for age in uagent_7:
                agents.append(age)    
        return agents

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name:Read_Agent(self)"
        print "purpose: read the agent from agent pool"
        print"======================================================="


#xcsx=xcsCFCavg_Translate('Test_0')
#xcsx.Test()
#xcsx.Test_1()   

#xcscfa=xcsrContA_Transfer('xcsrContA_Test')
#xcscfa.Read_xcsrContA(xcscfa.path[0])
#Agents=xcscfa.Get_Agents()
#print Agents[0].Type


#print 'Hello' 
#x=Read_Agents('xcsrContA_Test')
#Agents=x.Read_Agent()
#print len(Agents[0].Agent.xcsrContA)
#print Agents[0].Name,'    ',Agents[0].Length,'     ',Agents[0].Type
#

#test_address='I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXCFS_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXRules_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXUseRul_10000.txt'
#x=xcscfunctions_Translate(test_address)
#for a in x.Agents:
#    a.Test()
              
