﻿class Basic_Config:
    def __init__(self):
        self.Question_Types=['multiplexer','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'dv1']#1
        self.Document_Questions=['MUX','hiddenEvenParity', 'hiddenOddParity', 'countOnes', 'carry', 'evenParity', 'majorityOn', 'DV1']#2
        self.Agent_Type=['virtual','xcsCFCavg','xcsCFA_SSP','xcs_SSP','XcsSMA_v2','xcsf_Boolean','xcsSMAv2_adder','xcsrContA','xcscfunction']#3
        self.Result_Type=['True','False','can not solve']#4
        self.Agent_Pool_Address='My_Agent_Pools'#5
        self.support_length=['11','6']#6
        
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Question_Types"
        print "purpose: the types of the questions "
        print ("value",self.Question_Types)
        print"======================================================="
        print "Number 2"
        print "Name:Document_Questions"
        print "purpose: the types of the questions "
        print ("value",self.Document_Questions)
        print"======================================================="
        print "Number 3"
        print "Name:Agent_Type"
        print "purpose: the types of the agents "
        print ("value",self.Agent_Type)
        print"======================================================="
        print "Number 4"
        print "Name:Result_Type"
        print "purpose: the types of the results"
        print ("value",self.Result_Type)
        print"======================================================="
        print "Number 5"
        print "Name:Agent_Pool_Address"
        print "purpose: the address of the agent pool"
        print ("value",self.Agent_Pool_Address)
        print"======================================================="
        print "Number 6"
        print "Name:support_length"
        print "purpose: the conditions"
        print ("value",self.support_length)


