﻿       
class Basic_Classify_config:
    def __init__(self):
        self.Classify_Type=['virtual']#1

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Classify_Type"
        print "purpose: the types of the classify algorithm "
        print ("value",self.Classify_Type)