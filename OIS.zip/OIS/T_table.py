﻿class T_table:
    def __init__(self):
        self.T_table=self.T_table_List()

    #Number1
    def T_table_List(self):
        table=[]
        table.append([0.000,1.000 ,1.376 ,1.963 ,3.078 ,6.314 ,12.71 ,31.82 ,63.66 ,318.31 ,636.62])
        table.append([0.000, 0.816, 1.061, 1.386, 1.886, 2.920, 4.303, 6.965 ,9.925, 22.327, 31.599])
        table.append([0.000, 0.765, 0.978, 1.250, 1.638, 2.353, 3.182, 4.541, 5.841, 10.215, 12.924])
        table.append([0.000 ,0.741, 0.941, 1.190, 1.533, 2.132, 2.776, 3.747, 4.604 ,7.173, 8.610])
        table.append([0.000 ,0.727, 0.920, 1.156 ,1.476 ,2.015 ,2.571, 3.365, 4.032 ,5.893, 6.869])

        table.append([0.000 ,0.718, 0.906, 1.134, 1.440, 1.943, 2.447 ,3.143 ,3.707, 5.208, 5.959])
        table.append([0.000 ,0.711, 0.896, 1.119 ,1.415, 1.895, 2.365, 2.998, 3.499, 4.785 ,5.408])
        table.append([0.000 ,0.706, 0.889, 1.108, 1.397, 1.860, 2.306, 2.896 ,3.355 ,4.501, 5.041])
        table.append([0.000, 0.703, 0.883, 1.100, 1.383, 1.833, 2.262, 2.821, 3.250 ,4.297, 4.781])
        table.append([0.000, 0.700, 0.879, 1.093, 1.372, 1.812, 2.228, 2.764, 3.169, 4.144 ,4.587])

        table.append([0.000, 0.697, 0.876, 1.088, 1.363, 1.796, 2.201, 2.718, 3.106, 4.025, 4.437])
        table.append([0.000, 0.695, 0.873, 1.083, 1.356, 1.782, 2.179, 2.681, 3.055, 3.930, 4.318])
        table.append([0.000, 0.694, 0.870, 1.079, 1.350, 1.771, 2.160, 2.650, 3.012, 3.852, 4.221])
        table.append([0.000, 0.692, 0.868, 1.076, 1.345, 1.761, 2.145, 2.624, 2.977, 3.787, 4.140])
        table.append([0.000, 0.691, 0.866, 1.074, 1.341, 1.753, 2.131, 2.602, 2.947, 3.733, 4.073])

        table.append([0.000, 0.690, 0.865, 1.071, 1.337, 1.746, 2.120, 2.583, 2.921, 3.686, 4.015])
        table.append([0.000, 0.689, 0.863, 1.069, 1.333, 1.740, 2.110, 2.567, 2.898, 3.646, 3.965])
        table.append([0.000, 0.688, 0.862, 1.067, 1.330, 1.734, 2.101, 2.552, 2.878, 3.610, 3.922])
        table.append([0.000, 0.688, 0.861, 1.066, 1.328, 1.729, 2.093, 2.539, 2.861, 3.579, 3.883])
        table.append([0.000, 0.687, 0.860, 1.064, 1.325, 1.725, 2.086, 2.528, 2.845, 3.552, 3.850])

        table.append([0.000, 0.686, 0.859, 1.063, 1.323, 1.721, 2.080, 2.518, 2.831, 3.527, 3.819])
        table.append([0.000, 0.686, 0.858, 1.061, 1.321, 1.717, 2.074, 2.508, 2.819, 3.505, 3.792])
        table.append([0.000, 0.685, 0.858, 1.060, 1.319, 1.714, 2.069, 2.500, 2.807, 3.485, 3.768])
        table.append([0.000, 0.685, 0.857, 1.059, 1.318, 1.711, 2.064, 2.492, 2.797, 3.467, 3.745])
        table.append([0.000, 0.684, 0.856, 1.058, 1.316, 1.708, 2.060, 2.485, 2.787, 3.450, 3.725])

        table.append([0.000, 0.684, 0.856, 1.058, 1.315, 1.706, 2.056, 2.479, 2.779, 3.435, 3.707])
        table.append([0.000, 0.684, 0.855, 1.057, 1.314, 1.703, 2.052, 2.473, 2.771, 3.421, 3.690])
        table.append([0.000, 0.683, 0.855, 1.056, 1.313, 1.701, 2.048, 2.467, 2.763, 3.408, 3.674])
        table.append([0.000, 0.683, 0.854, 1.055, 1.311, 1.699, 2.045, 2.462, 2.756, 3.396, 3.659])
        table.append([0.000, 0.683, 0.854, 1.055, 1.310, 1.697, 2.042, 2.457, 2.750, 3.385, 3.646])

        table.append([0.000, 0.681, 0.851, 1.050, 1.303, 1.684, 2.021, 2.423, 2.704, 3.307, 3.551])
        table.append([0.000, 0.679, 0.848, 1.045, 1.296, 1.671, 2.000, 2.390, 2.660, 3.232, 3.460])
        table.append([0.000, 0.678, 0.846, 1.043, 1.292, 1.664, 1.990, 2.374, 2.639, 3.195, 3.416])
        table.append([0.000, 0.677, 0.845, 1.042, 1.290, 1.660, 1.984, 2.364, 2.626, 3.174, 3.390])
        table.append([0.000, 0.675, 0.842, 1.037, 1.282, 1.646, 1.962, 2.330, 2.581, 3.098, 3.300])

        table.append([0.000, 0.674, 0.842, 1.036, 1.282, 1.645, 1.960, 2.326, 2.576, 3.090, 3.291])
        return table
    
    #Number2
    def Get_T_Value_One_Tail(self,T,N):
        if N>0 and N<=30:
            T_list=self.T_table[N-1]
        elif N==40:
            T_list=self.T_table[30]
        elif N==60:
            T_list=self.T_table[31]
        elif N==80:
            T_list=self.T_table[32]
        elif N==80:
            T_list=self.T_table[33]
        elif N==80:
            T_list=self.T_table[34]
        elif N=='Z':
            T_list=self.T_table[35]

        if T>=0.5:
            return T_list[0]
        elif T>=0.25 and T<0.5:
            return T_list[1]
        elif T>=0.2and T<0.25:
            return T_list[2]
        elif T>=0.15and T<0.2:
            return T_list[3]
        elif T>=0.1and T<0.15:
            return T_list[4]
        elif T>=0.05and T<0.1:
            return T_list[5]
        elif T>=0.025and T<0.05:
            return T_list[6]
        elif T>=0.01and T<0.025:
            return T_list[7]
        elif T>=0.005and T<0.01:
            return T_list[8]
        elif T>=0.001and T<0.005:
            return T_list[9]
        elif T>=0.0005and T<0.001:
            return T_list[10]
        else:
            return T_list[10]

    #Number3
    def Get_T_Value_Two_Tail(self,T,N):
        if N>0 and N<=30:
            T_list=self.T_table[N-1]
        elif N==40:
            T_list=self.T_table[30]
        elif N==60:
            T_list=self.T_table[31]
        elif N==80:
            T_list=self.T_table[32]
        elif N==80:
            T_list=self.T_table[33]
        elif N==80:
            T_list=self.T_table[34]
        elif N=='Z':
            T_list=self.T_table[35]

        if T>=1.0:
            return T_list[0]
        elif T>=0.5 and T<1.0:
            return T_list[1]
        elif T>=0.4and T<0.5:
            return T_list[2]
        elif T>=0.3and T<0.4:
            return T_list[3]
        elif T>=0.2and T<0.3:
            return T_list[4]
        elif T>=0.15and T<0.2:
            return T_list[5]
        elif T>=0.05and T<0.1:
            return T_list[6]
        elif T>=0.02and T<0.05:
            return T_list[7]
        elif T>=0.01and T<0.02:
            return T_list[8]
        elif T>=0.002and T<0.01:
            return T_list[9]
        elif T>=0.001and T<0.002:
            return T_list[10]
        else:
            return T_list[10]

    #Number4
    def Get_T_Confidence_One_Tail(self,T,N):
        if N>0 and N<=30:
            T_list=self.T_table[N-1]
        elif N==40:
            T_list=self.T_table[30]
        elif N==60:
            T_list=self.T_table[31]
        elif N==80:
            T_list=self.T_table[32]
        elif N==80:
            T_list=self.T_table[33]
        elif N==80:
            T_list=self.T_table[34]
        elif N=='Z':
            T_list=self.T_table[35]

        if T>=0.5:
            return 0.0
        elif T>=0.25 and T<0.5:
            return 50.0
        elif T>=0.2and T<0.25:
            return 60.0
        elif T>=0.15and T<0.2:
            return 70.0
        elif T>=0.1and T<0.15:
            return 80.0
        elif T>=0.05and T<0.1:
            return 90.0
        elif T>=0.025and T<0.05:
            return 95.0
        elif T>=0.01and T<0.025:
            return 98.0
        elif T>=0.005and T<0.01:
            return 99.0
        elif T>=0.001and T<0.005:
            return 99.8
        elif T>=0.0005and T<0.001:
            return 99.9
        else:
            return 99.9

    #Number5
    def Get_T_Conficence_Two_Tail(self,T,N):
        if N>0 and N<=30:
            T_list=self.T_table[N-1]
        elif N==40:
            T_list=self.T_table[30]
        elif N==60:
            T_list=self.T_table[31]
        elif N==80:
            T_list=self.T_table[32]
        elif N==80:
            T_list=self.T_table[33]
        elif N==80:
            T_list=self.T_table[34]
        elif N=='Z':
            T_list=self.T_table[35]

        if T>=1.0:
            return 0.0
        elif T>=0.5 and T<1.0:
            return 50.0
        elif T>=0.4and T<0.5:
            return 60.0
        elif T>=0.3and T<0.4:
            return 70.0
        elif T>=0.2and T<0.3:
            return 80.0
        elif T>=0.15and T<0.2:
            return 90.0
        elif T>=0.05and T<0.1:
            return 95.0
        elif T>=0.02and T<0.05:
            return 98.0
        elif T>=0.01and T<0.02:
            return 99.0
        elif T>=0.002and T<0.01:
            return 99.8
        elif T>=0.001and T<0.002:
            return 99.9
        else:
            return 99.9
    def Test(self):
        print "this t table is for [1,30]and 40 60 80 100 10000 others don't work"
        table=self.T_table_List()
        print len(table[0])
        print"======================================================="
        print "Number 1"
        print "Function Name:T_table_List(self):"
        print "purpose: build the T table"
        print "parameter N: number of test"
        print "parameter T: the confidence of the T"
        print"======================================================="
        print "Number 2"
        print "Function Name: Get_T_Value_One_Tail(self,T,N)"
        print "purpose: Get the T value based on one tail"
        print "parameter N: number of test"
        print "parameter T: the confidence of the T"
        print"======================================================="
        print "Number 4"
        print "Function Name:Get_T_Confidence_One_Tail(self,T,N)"
        print "purpose: Get the confidence based on one tail"
        print "parameter N: number of test"
        print "parameter T: the T value"
        print"======================================================="
        print "Number 5"
        print "Function Name:Get_T_Conficence_Two_Tail(self,T,N):"
        print "purpose: Get the confidence based on two tail"
        print "parameter N: number of test"
        print "parameter T: the T value"
        print"======================================================="

    
#T=T_table()
#T.Test()