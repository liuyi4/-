﻿from Environment_Selection_Machine import Environment_Selection_Machine_V2
from Agent_Pools import Read_Agents
from Mapping_Function import Mapping
from environment_machine import environment_machine
from Time_operator import Timer
from Agent_Basic_Test import Agent_Basic_Test

class Agent_accuracy_Test:
    def __init__(self,I_agent_address,I_env_address):
        self.a_b=Agent_Basic_Test()
        self.agent_address=I_agent_address#number1
        self.env_Address=I_env_address#number2
        S_M_2=Environment_Selection_Machine_V2(self.env_Address)
        
        self.environments=S_M_2.Get_environments()
        print"finish reading environments"
        R_A=Read_Agents(self.agent_address)
        self.agent=R_A.Read_Agent()
        #self.agent[0].Test()
        #print '111111111111111111111111111',self.agent[0].Name
        #print '111111111111111111111111111',self.agent[0].Length
        

        
        self.search_string='accuracy'
        self.save_address=self.a_b.Generate_save_address(self.search_string)#number3        
        self.MP=Mapping()
        self.use_time=Timer()

    #number4
    def Write_Information(self,data):
        f=open(self.save_address,'w')
        f.writelines(data)
        f.close()

    #number5
    def Get_Result(self):
        right=0
        datas=''
        data=''
        for i in range(0,len(self.agent)):
            for env in self.environments:
                time_1=self.use_time.Get_Time_Now()
                for cods in env.Conditions:
                    if cods.actual_action=='False':
                        env_action=0
                    else:
                        env_action=1
                    A_action=self.MP.Get_Action(cods.state,self.agent[i])
                    if A_action==env_action:
                        right=right+1
                time_2=self.use_time.Get_Time_Now()
                data='agent_Id: '+str(i)+' agent: '+self.agent[i].Type+ ' agent_questions: '+self.agent[i].Question+' right: '+str(right)+' length: '+ str(len(env.Conditions))
                data=data+' question_type: '+env.type+' accuracy: ' + str(float(right)/float(len(env.Conditions))) +' total_time: '+str(time_2-time_1)+'\n'
                datas=datas+data
                print data
                data=''
                right=0
        return datas    
    
    #number6 important
    def Run(self):
        #try:
            result=self.Get_Result()
            self.Write_Information(result)
            print'Agent accuracy Test complete'
        #except Exception:
        #    print 'error'

    def Generate_test_environment(self,question_number):
        number=100
        for i in range(1,11):
            e=environment_machine()
            e.Add_One_Environment(question_number,i*number,11)
        #print 'finish'

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:agent_address"
        print "purpose: the agent pool address "
        print"======================================================="
        print "Number 2"
        print "Name:env_Address"
        print "purpose: the environment pool address "
        print"======================================================="
        print "Number 3"
        print "Name:save_address"
        print "purpose: the address for saving the result "
        print"======================================================="
        print "Number 4"
        print "Function Name: Write_Information(self,data)"
        print "purpose: write the information into txt "
        print "parameter data：the data you want to save "
        print"======================================================="
        print "Number 5"
        print "Function Name: Get_Result(self)"
        print "purpose: get the result of the test "
        print"======================================================="
        print "Number 6"
        print "Function Name:  Run(self)"
        print "purpose: run the test "
        
print 'wow'
#test_address='I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXCFS_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXRules_10000.txt$$I:\\Agent_Combiner_V2\\Agent_Combiner_V2\\My_Agent_Pools\\COMBINE_USE\\xcscfunction_11_MUXUseRul_10000.txt'
#x=Agent_accuracy_Test('test_address','MUX_env1')
#x.Run()
#x.Generate_test_environment(7)
#e=environment_machine()
#e.Add_One_Environment(5,50,6)
#print 'finish'
#use_time=Timer()
#print use_time.Get_Time_Now()


