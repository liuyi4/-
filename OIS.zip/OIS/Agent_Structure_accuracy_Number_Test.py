﻿from Agent_Basic_Test import Agent_Basic_Test
from Agent_Structure_accuracy_Number_Test_config import Agent_Structure_accuracy_Number_Test_config
from environment_machine import Condition 
class Agent_Structure_accuracy_number_Test:
    def __init__(self):
        self.basic_function=Agent_Basic_Test()
        self.my_config=Agent_Structure_accuracy_Number_Test_config()
        #self.my_config.Test()
        self.environments=self.basic_function.Get_environments(2,None)
        self.Test_environment=self.Combine_environments()
        self.agents=self.basic_function.Get_Virtual_Agents()

    #number1 
    def Generate_Test_Environments(self):
        self.basic_function.Generate_environments(0,None,100,10)

    #number2
    def Generate_Agents(self):
        self.basic_function.Generate_Virtual_Agents(None,None,100)

    #number3
    def Combine_environments(self):
        result=[]
        if(self.environments!=None):
            for env in self.environments:
                for cod in env.Conditions:
                    result.append(cod)
        return result
    
    #number4           
    def different_percents(self):
        percent=[]
        for i in range(1,10):
            percent.append(i*0.1)
        return percent

    #number5
    def Virtual_Map_reward(self,condition,agent):
        reward=0
        input=self.Get_State(condition.state)
        for ag in agent.Agent.recognise:
            rule=self.Get_State(ag.condition)
            if input==rule:
                if condition.actual_action==ag.understant:
                    reward=1
        return reward

    #number6
    def Get_total_rewards(self,conditions,agent):
        reward=0
        for cod in conditions:
            reward=reward+self.Virtual_Map_reward(cod,agent)
        return reward

    #number7
    def Get_State(self,state):
        input=''
        for i in state:
             input=input+i
        return input

    #number8
    def Calculate_fit(self):
        output=[]
        for i in range(0,len(self.agents)):
            result=self.Get_total_rewards(self.Test_environment,self.agents[i])
            data=Data_2(i,result)
            output.append(data)
        return output

    #number9
    def fit_convert(self):
        out_put=self.Calculate_fit()
        write_data=''
        for inf in out_put:
            write_data=write_data+str(inf.data_1)+'_'+str(inf.data_2)+'\n'
        return write_data

    #number10
    def Save_fit(self):
        Address=self.my_config.result_Address+'\\'+self.my_config.Agent_fit_Address
        f=open(Address,'w')
        write_data=self.fit_convert()
        f.writelines(write_data)
        f.close()
        print "work complete"
                                   
    def Test(self):
        #self.Generate_Test_Environments()
        #self.Generate_Agents()
        #print len(self.agents)
        #result=self.Combine_environments()
        #print len(result)
        print"======================================================="
        print "Number 1"
        print "Function Name: Generate_Test_Environments(self)"
        print "purpose: generate the test environment"
        print"======================================================="
        print "Number 2"
        print "Function Name: Generate_Agents(self)"
        print "purpose: generate the agents"
        print"======================================================="
        print "Number 3"
        print "Function Name:  Combine_environments(self)"
        print "purpose: combine the environments"
        print"======================================================="
        print "Number 4"
        print "Function Name:  different_percents(self)"
        print "purpose: generate the different percents"
        #p=self.different_percents()
        #print p
        print"======================================================="
        print "Number 5"
        print "Function Name: Virtual_Map_reward(self,condition,agent)"
        print "purpose: get one condition's reward"
        print "parameter condition: one condition"
        print "parameter agent: one agent"
        #result=self.Virtual_Map_reward(self.Test_environment[0],self.agents[0])
        #print result
        print"======================================================="
        print "Number 6"
        print "Function Name: Get_total_rewards(self,conditions,agent)"
        print "purpose: get one condition's reward"
        print "parameter conditions: several conditions"
        print "parameter agent: one agent"
        #result=self.Get_total_rewards(self.Test_environment,self.agents[1])
        #print result
        print"======================================================="
        print "Number 7"
        print "Function Name: Get_State(self,state)"
        print "purpose: change state from list to string for example [1,1,1]=111"
        print "parameter state: a state"
        print"======================================================="
        print "Number 8"
        print "Function Name: Calculate_fit(self)"
        print "purpose: return the fit information"
        print"======================================================="
        print "Number 9"
        print "Function Name: fit_convert(self)"
        print "purpose: convert the fit information into string"
        print"======================================================="
        print "Number 10"
        print "Function Name: Save_fit(self)"
        print "purpose: save the information"
        #result=self.Calculate_fit()
       # for i in result:
       #     i.Test() 
        #self.Save_fit()
        print"======================================================="

class Data_2:
    def __init__(self,input_1,input_2):
        self.data_1=input_1
        self.data_2=input_2

    def Test(self):
        print self.data_1
        print self.data_2
#A=Agent_Structure_accuracy_number_Test()
#A.Test()