class Environment_Selection_Machine_Config:
    def __init__(self):
        self.Environments_selections=['Address_one','Address_list','whole','based_on_one_question','based_on_questions_list','based_on_one_question_several','based_on_questions_list_several']#1
        self.Environments_my_choose=None#2
        self.Environments_Address=None#3
        self.Environment_Lists=None#4
        self.Environment_Whole_Address=None#5
        self.Environment_Question_Types=None#10
        self.Environment_question=None#11
        self.Environment_question_list=None#12

    def Set_Environments_my_choose(self,value):#6
        self.Environments_my_choose=self.Environments_selections[value]

    def Set_Environments_Address(self,value):#7
        self.Environments_Address=value

    def Set_Environment_Lists(self,value):#8
        self.Environment_Lists=value

    def Set_Environment_Whole_Address(self,value):#9
        self.Environment_Whole_Address=value

    def Set_Environment_Question_Types(self,value):#13
        self.Environment_Question_Types=value

    def Set_Environment_question(self,value):#14
        self.Environment_question=value

    def Set_Environment_question_list(self,value):#15
        self.Environment_question_list=value

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Environments_selections"
        print "purpose: the selections of how to choose environments"
        print ("value",self.Environments_selections)
        print"======================================================="
        print "Number 2"
        print "Name:Environments_my_choose"
        print "purpose: the environment I choose."
        print ("value",self.Environments_my_choose)
        print"======================================================="
        print "Number 3"
        print "Name:Environments_Address"
        print "purpose: while choose Address_One the environment you will use."
        print ("value",self.Environments_Address)
        print"======================================================="
        print "Number 4"
        print "Name:Environment_Lists"
        print "purpose: while choose Address_list the environment you will use"
        print ("value",self.Environment_Lists)
        print"======================================================="
        print "Number 5"
        print "Name:Environment_Whole_Address"
        print "purpose: while choose whole means all the environments in the environment document you'll use."
        print ("value",self.Environment_Whole_Address)
        print"======================================================="
        print "Number 6"
        print "Function Name:Set_Environments_my_choose(self,value)"
        print "purpose: set the value of Environments_my_choose."
        print "parameter value: 0,1,2,3"
        print"======================================================="
        print "Number 7"
        print "Function Name:Set_Environments_Address(self,value)"
        print "purpose: set the value of Environments_Address."
        print "parameter value: int less than the number of environment list"
        print"======================================================="
        print "Number 8"
        print "Function Name:Set_Environment_Lists(self,value)"
        print "purpose: set the value of Environment_Lists."
        print "parameter value: int[], for example [1,2,4,7] less than the length of environment list"
        print"======================================================="
        print "Number 9"
        print "Function Name:Set_Environment_Whole_Address(self,value)"
        print "purpose: set the value of Environment_Whole_Address."
        print "parameter value: string[] the list of whole address"
        #self.Environment_question_list=None#12
        print"======================================================="
        print "Number 10"
        print "Name:Environment_Question_Types"
        print "purpose: the whole types of the environments"
        print ("value",self.Environment_Question_Types)
        print"======================================================="
        print "Number 11"
        print "Name:Environment_question"
        print "purpose: the environment questions use."
        print ("value",self.Environment_question)
        print"======================================================="
        print "Number 12"
        print "Name:Environment_question_list"
        print "purpose: the list of environment types use."
        print ("value",self.Environment_question_list)
        print"======================================================="
        print "Number 13"
        print "Function Name:Set_Environment_Question_Types(self,value)"
        print "purpose: set the value of Environment_Question_Types."
        print "parameter value: the types of environments string[]"
        print"======================================================="
        print "Number 14"
        print "Function Name:SetEnvironment_question(self,value)"
        print "purpose: set the value of Environment_question."
        print "parameter value: int, for example 1,2,3,4.. less than the length of environment type list"
        print"======================================================="
        print "Number 15"
        print "Function Name:Set_Environment_question_list(self,value)"
        print "purpose: set the value of Environment_question_list."
        print "parameter value: int[] the list of whole environmets you may use just like[0,2,4]"