﻿class Agent_Basic_Test_Config:
    def __init__(self):
        self.Use_Pool_Address="My_Agent_Pools\\virtual_Agents"#1
        self.result_Address="result"#3

    def Set_Use_Pool_Address(self,value):#2
        self.Use_Pool_Address=value

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Use_Pool_Address"
        print "purpose: the agen pool address this system use"
        print ("value",self.Use_Pool_Address)
        print"======================================================="
        print "Number 2"
        print "Function Name: Set_Use_Pool_Address(self,value)"
        print "purpose: set the value of Use_Pool_Address string"
        print"======================================================="
        print "Number 3"
        print "Name:result_Address"
        print "purpose: the address to save the result"
        print ("value",self.result_Address)