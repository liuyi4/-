﻿from Environment_Selection_Machine import Environment_Selection_Machine
from environment_machine import environment_machine
from virtual_Agent_Producer import Virtual_Generate
from Agent_Basic_Test_Config  import Agent_Basic_Test_Config
from Agent_Pools import Agent_pool_Controller
import os
class Agent_Basic_Test:
    def __init__(self):
        self.E_M=environment_machine()
        self.my_config=Agent_Basic_Test_Config()
        self.Create_folder(self.my_config.result_Address)
        #self.my_config.Test()
        #self.Test()

    #number1
    def Get_environments(self,type,condition):
        my_environment=Environment_Selection_Machine(type,condition)
        print "work complete"
        return my_environment.Environment_results

    #number2
    def Generate_environments(self,type_1,type_2,numbers,environment_numbers):
        self.E_M.e_con.Set_Environment_selected(type_1)
        if type_2!=None:
            if type_1==0:
                if type(type_2)==list:
                    if len(type_2)==8:
                        self.E_M.e_con.Set_Rate_multiplexer(type_2[0])
                        self.E_M.e_con.Set_Rate_hiddenEvenParity(type_2[1])
                        self.E_M.e_con.Set_Rate_hiddenOddParity(type_2[2])
                        self.E_M.e_con.Set_Rate_countOnes(type_2[3])
                        self.E_M.e_con.Set_Rate_carry(type_2[4])
                        self.E_M.e_con.Set_Rate_evenParity(type_2[5])
                        self.E_M.e_con.Set_Rate_majorityOn(type_2[6])
                        self.E_M.e_con.Set_Rate_dv1(type_2[7])
                    else:
                        print "input error"
                else:
                    print "input error"
            elif type_1==1:
                if type_2<=7:
                    self.E_M.e_con.Set_Environment_Default(type_2)
                else:
                     print "input error"
            elif type_1==2:
                if type_2==0 or type_2==1:
                    self.E_M.e_con.Set_Environment_Number_Set(type_2)
                else:
                    print "input error"
            else:
                print "input error"
        if numbers!=None:
             self.E_M.e_con.Set_NumofConditions(numbers)
        if environment_numbers!=None:
            self.E_M.e_con.Set_Environment_Random_Length(environment_numbers)
        self.E_M.Environments_Machine_Generater()
        print "work complete"

    #number3
    def Generate_Virtual_Agents(self,type,condition,rate):
        v=Virtual_Generate(type,condition,rate)
        print "work complete"

    #number4
    def Get_Virtual_Agents(self):
        A_P_C=Agent_pool_Controller()
        Agents=A_P_C.Get_All_Agents_From_pool(self.my_config.Use_Pool_Address)
        print "work complete"
        return Agents

    #number5
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    #number6
    def Create_folder(self,Name):
        if not self.Is_File_Exist(Name):
            os.mkdir(Name)

    #number7
    def GetFileList(self,information):
        FileList=[]
        if self.Is_File_Exist(self.my_config.result_Address):
            FileNames=os.listdir(self.my_config.result_Address)
            for i in FileNames:
                if information in i:
                    FileList.append(i)
        return FileList

    #number8
    def Get_Max_Number(self,information):
        File_list=self.GetFileList(information)
        max=0
        for F_L in File_list:
            number=F_L.split('_')[-1].split('.txt')[0]
            if number !='' and number!=None and number!=information:
                number_0=int(number)
                if number_0>max:
                    max=number_0
        return max+1
    
    #number9
    def Generate_save_address(self,information):
        max=self.Get_Max_Number(information)
        Address=self.my_config.result_Address+'\\'+information+'_'+str(max)+'.txt'
        return Address


    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: Get_environments(self,type,condition)"
        print "purpose: get the exist environments"
        print "parameter type: the type you select the environment"
        print "parameter condition: the condition you use to select the environment"
        print "value pairs you can input:"
        print "type                              || conditions"
        print"============================================================="
        print "0   'Address_one'                 || int just like 0,1,2,3...@"
        print "1   'Address_list'                || int[] just like [0,1]@"
        print "2    'whole'                      || None"
        print "3'based_on_one_question'          || int just like 0,1,2,3...#"
        print "4'based_on_questions_list'        || int[] just like [0,1]#"
        print "5'based_on_one_question_several'  || int just like 0,1,2,3...#"
        print "6'based_on_questions_list_several'|| int[] just like [0,1]#"
        print "Notice @: means the value depend on the length of environment list, it should less than the length of environments"
        print "Notice #: means the value depend on the length of environment type list, it should less than the length of environment types"
        #result=self.Get_environments(2,None)
        #for i in result:
        #    print len(i.Conditions)
        #     i.Test()
        #print len(result)
        print"======================================================="
        print "Number 2"
        print "Function Name: Generate_environments(self,type_1,type_2,numbers)"
        print "purpose: generate the environments"
        print "parameter type_1: the type you select to generate environment"
        print "parameter type_2: while type_1=2 the type you select to generate the environment"
        print "parameter numbers: the numbers of the conditions you want to generate"
        print "value pairs you can input:"
        print "type_1                    || type_2"
        print "============================================================="
        print "input 0  means 'random'   ||int[] length equal 8 just like [10,10,10,10...] or None"                    
        print "input 1  means'default'   ||int just like 0,1,2,3,4,5,6,7 or None"
        print "input 2  means 'set'      ||int None or 1"
        print "while type_1=0"
        print "type_2                    || means"
        print "int [0]                   || Rate_multiplexer"
        print "int [1]                   || Rate_hiddenEvenParity"
        print "int [2]                   || Rate_hiddenOddParity"
        print "int [3]                   || Rate_countOnes"
        print "int [4]                   || Rate_carry"
        print "int [5]                   || Rate_evenParity"
        print "int [6]                   || Rate_majorityOn"
        print "int [7]                   || Rate_dv1"
        print "while type_1=1"
        print "type_2                    || means"
        print "0                         || multiplexer"
        print "1                         || hiddenEvenParity"
        print "2                         || hiddenOddParity"
        print "3                         || countOnes"
        print "4                         || carry"
        print "5                         || evenParity"
        print "6                         || majorityOn"
        print "7                         || dv1"  
        #self.Generate_environments(0,None,1000,40)
        print"======================================================="
        print "Number 3"
        print "Function Name: Generate_Virtual_Agents(self,type,condition,rate)"
        print "purpose: Generate the virtual agents"
        print "parameter type: the type you select the environment"
        print "parameter condition: the condition you use to select the environment"
        print "parameter rate: the training rate"
        print "value pairs you can input:"
        print "type                              || conditions"
        print"============================================================="
        print "0   'Address_one'                 || int just like 0,1,2,3...or None@"
        print "1   'Address_list'                || int[] just like [0,1] or None@"
        print "2    'whole'                      || None"
        print "3'based_on_one_question'          || int just like 0,1,2,3... or None#"
        print "4'based_on_questions_list'        || int[] just like [0,1] or None#"
        print "5'based_on_one_question_several'  || int just like 0,1,2,3...or None#"
        print "6'based_on_questions_list_several'|| int[] just like [0,1]#or None"
        print "Notice @: means the value depend on the length of environment list, it should less than the length of environments"
        print "Notice #: means the value depend on the length of environment type list, it should less than the length of environment types"
        #self.Generate_Virtual_Agents(None,None,100)
        print"======================================================="
        print "Number 4"
        print "Function Name: Get_Virtual_Agents(self)"
        print "purpose: get the virtual agents based on use agent pools address"
        #r=self.Get_Virtual_Agents()
        #for i in r:
        #    i.Test()
        #print len(r)
        print"======================================================="
        print "Number 5"
        print "Function Name: Is_File_Exist(self,file_Name)"
        print "purpose: judge the file is exist or not"
        print "parameter file_Name: the adress of the file"
        print"======================================================="
        print "Number 6"
        print "Function Name: Create_folder(self,Name)"
        print "purpose: create the folder"
        print "parameter Name: the adress of the file"
        print"======================================================="
        print "Number 7"
        print "Function Name: GetFileList(self,information)"
        print "purpose: get the list of the file"
        print "parameter information: the key string of the txt tile"
        print"======================================================="
        print "Number 8"
        print "Function Name: Get_Max_Number(self,information)"
        print "purpose: get the max id of the file"
        print "parameter information: the key string of the txt tile"
        print"======================================================="
        print "Number 9"
        print "Function Name: Generate_save_address(self,information)"
        print "purpose: generate the address for save the result"
        print "parameter information: the key string of the txt tile"
        print"======================================================="


#t=Agent_Basic_Test()

