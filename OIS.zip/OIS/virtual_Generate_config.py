﻿from Classify_config import *
class virtual_Generate_config:
    def __init__(self):
        self.basic_config=Basic_Classify_config()
        self.Classify_Type=self.basic_config.Classify_Type[0]#1
        self.Classify_Type_ID=0#2      

        """
        important
        """
        self.Get_Environmet_Id=2#3
        self.Environment_Conditions=0#4

        self.Training_Rate=70#6

        self.Folder_Name="virtual_Agents"

        self.file_Name="Virtual_agent"
        self.file_type=".txt"

    def Set_Environment_request(self,type,conditions):#5
        self.Get_Environmet_Id=type
        self.Environment_Conditions=conditions

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Classify_Type"
        print "purpose: the type of classify system"
        print ("value",self.Classify_Type)
        print"======================================================="
        print "Number 2"
        print "Name:Classify_Type_ID"
        print "purpose: the type's ID of classify system just like 0,1,2,3 etc."
        print ("value",self.Classify_Type_ID)
        print"======================================================="
        print "Number 3"
        print "Name:Get_Environmet_Id"
        print "purpose: the type of environment you should use."
        print ("value",self.Get_Environmet_Id)
        print"======================================================="
        print "Number 4"
        print "Name:Environment_Conditions"
        print "purpose: the conditions of the environments."
        print ("value",self.Environment_Conditions)
        print"======================================================="
        print "Number 5"
        print "Function Name:Set_Environment_request(self,type,conditions)"
        print "purpose: the conditions of get environments."
        print "Value pairs:"
        print "Get_Environmet_Id /type           || Environment_Conditions/conditions"
        print"============================================================="
        print "0   'Address_one'                 || int just like 0,1,2,3...@"
        print "1   'Address_list'                || int[] just like [0,1]@"
        print "2    'whole'                      || None"
        print "3'based_on_one_question'          || int just like 0,1,2,3...#"
        print "4'based_on_questions_list'        || int[] just like [0,1]#"
        print "5'based_on_one_question_several'  || int just like 0,1,2,3...#"
        print "6'based_on_questions_list_several'|| int[] just like [0,1]#"
        print "Notice @: means the value depend on the length of environment list, it should less than the length of environments"
        print "Notice #: means the value depend on the length of environment type list, it should less than the length of environment types"
        print"======================================================="
        print "Number 6"
        print "Name:Training_Rate"
        print "purpose: the rate of training data"
        print ("value",self.Training_Rate)
        print"======================================================="
        print "Number 7"
        print "Name:Folder_Name"
        print "purpose: the folder save the agents"
        print ("value",self.Folder_Name)
        print"======================================================="
        print "Number 8"
        print "Name:file_Name"
        print "purpose: the name of the file"
        print ("value",self.file_Name)
        print"======================================================="
        print "Number 9"
        print "Name:file_type"
        print "purpose: the type of the file"
        print ("value",self.file_type)