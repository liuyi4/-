﻿from Basic_Config import Basic_Config
class Agent_pool_config:
    def __init__(self):
        self.basic_config=Basic_Config()
        self.Agent_Type=self.basic_config.Agent_Type#1
        self.Agent_Pool_List=['Candidate_Agent_Pool','active_Agent_pool_Based_question_Type','active_Agent_pool_Based_Agent_Type','active_Agent_pool_Based_Both_a_q','active_Agent_pool_Based_Both_q_a','active_Agent_pool_Based_empty']#2
        self.Candidate_Pool_list=['virtual_Agents']#3
        self.Question_Types=self.basic_config.Question_Types#4
        #self.Basic_Pool_Name="Test_Agent_Pool"#5
        self.Basic_Pool_Name=""#5
        self.My_Agent_Pools="My_Agent_Pools"#6
        self.Original_Pools="Original_Pools"#7

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:Agent_Type"
        print "purpose: the types of the agent system can translate"
        print ("value",self.Agent_Type)
        print"======================================================="
        print "Number 2"
        print "Name:Agent_Pool_List"
        print "purpose: the pool list of the agent pools "
        print ("value",self.Agent_Pool_List)
        print"======================================================="
        print "Number 3"
        print "Name:Candidate_Pool_list"
        print "purpose: the pool list of the candidate agent pools "
        print ("value",self.Candidate_Pool_list)
        print"======================================================="
        print "Number 4"
        print "Name:Question_Types"
        print "purpose: the types of questions for example dv1 ... "
        print ("value",self.Question_Types)
        print"======================================================="
        print "Number 5"
        print "Name:My_Agent_Pools"
        print "purpose: the name of use agent pools floder"
        print ("value",self.My_Agent_Pools)
        print"======================================================="
        print "Number 6"
        print "Name:Original_Pools"
        print "purpose: the name of original saved pool floder"
        print ("value",self.Original_Pools)