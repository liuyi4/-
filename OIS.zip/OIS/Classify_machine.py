﻿import os
from Classify_config import *
from environment_machine import *
import time

class classify_machine:
    def __init__(self):
       #self.vc_c=virtual_Generate_config()
       #self.vc_c.Test()
       self.my_config=Basic_Classify_config()


    #number1
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    #number2
    def Create_folder(self,Name):
        if not self.Is_File_Exist(Name):
            os.mkdir(Name)

    #number3
    def Get_Stamp(self):
        star_mytime=time.asctime(time.localtime(time.time()))
        list=str(star_mytime).split(' ')        
        result=''
        for inf in list:
            if ':' in inf:
                time_list=inf.split(':')
                for t in time_list:
                    result=result+'_'+t
            else:
                result=result+'_'+inf
        return result

    #number4
    def Write_File(self,Address,data):
        f=open(Address,'w')
        f.writelines(data)
        f.close()

    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Function Name: Is_File_Exist(self,file_Name)"
        print "purpose: judge the file is exist or not"
        print "parameter file_Name: the adress of the file"
        print"======================================================="
        print "Number 2"
        print "Function Name: Create_folder(self,Name)"
        print "purpose: create the folder"
        print "parameter \Name: the adress of the file"
        print"======================================================="
        print "Number 3"
        print "Function Name:  Get_Stamp(self)"
        print "purpose: Get the time"
        print"======================================================="
        print "Number 4"
        print "Function Name:Write_File(self,Address,data)"
        print "purpose: write the data into the file"
        #self.Get_Stamp()
    

#v=classify_machine()