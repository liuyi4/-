﻿from Environment_Selection_Machine_Config import Environment_Selection_Machine_Config
from environment_machine import *
from environment_config import environment_config
import os

class Environment_Selection_Machine:
    def __init__(self,type,conditions):
        self.my_config=Environment_Selection_Machine_Config()
        self.use_EM=environment_machine()
        self.e_c=environment_config()
        self.Environment_results=[]#5
        self.Get_Result(type,conditions)
        
    
    #number 1
    def Get_All_Path(self):
        self.my_config.Set_Environment_Whole_Address(self.use_EM.Get_sorted_environment_address())


    #number2
    def Get_Environments(self,type,Conditions):
        if type<len(self.my_config.Environments_selections):
            self.my_config.Environments_my_choose=self.my_config.Environments_selections[type]
            
            if self.my_config.Environments_my_choose==self.my_config.Environments_selections[0]:
                self.my_config.Set_Environments_Address(Conditions)
                self.Environment_results.append(self.Use_Address_Generate_Environment(self.my_config.Environment_Whole_Address[self.my_config.Environments_Address]))

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[1]:
                self.my_config.Set_Environment_Lists(Conditions)
                self.Environment_results=self.Use_Address_List_Generate_Environment()

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[2]:
                self.Environment_results=self.Generate_All_Environments()

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[3]:
                self.Get_Environments_Type()
                self.my_config.Set_Environment_question(Conditions)
                if len(self.my_config.Environment_Question_Types)>0:
                    self.Environment_results.append(self.Generate_First_Environment_Based_on_question())
                else:
                    self.Environment_results=None

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[4]:
                 self.Get_Environments_Type()
                 self.my_config.Set_Environment_question_list(Conditions)
                 if len(self.my_config.Environment_Question_Types)>0:
                    self.Environment_results=self.Generate_First_Environment_Based_on_question_list()
                 else:
                    self.Environment_results=None

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[5]:
                 self.Get_Environments_Type()
                 self.my_config.Set_Environment_question(Conditions)
                 if len(self.my_config.Environment_Question_Types)>0:
                    self.Environment_results=self.Generate_several_Environments_Based_On_question()
                 else:
                    self.Environment_results=None

            elif self.my_config.Environments_my_choose==self.my_config.Environments_selections[6]:
                 self.Get_Environments_Type()
                 self.my_config.Set_Environment_question_list(Conditions)
                 if len(self.my_config.Environment_Question_Types)>0:
                    self.Environment_results=self.Generate_several_Environments_Based_On_question_list()
                 else:
                    self.Environment_results=None
            else:
                print "setting error"
        else:
            print "input type illegal"

    #number3
    def Get_Environments_Type(self):
        self.my_config.Environment_Question_Types=self.e_c.Environments

    #number4
    def Get_Result(self,type,conditions):
        self.Get_All_Path()
        self.Get_Environments(type,conditions)

    #number6
    def Generate_All_Environments(self):
        results=self.use_EM.environments_Translater()
        return results

    #number7
    def Generate_First_Environment_Based_on_question(self):
        if self.my_config.Environment_question!=None:
            environments=self.Generate_All_Environments()
            for env in environments:
                if self.my_config.Environment_question==env.type_Id:
                    return env
            print "No such type environment exist, please regenerate environments"
            return None
        else:
            print 'system error'
            return None

    #number8
    def Complete_environment(self):
        return self.Environment_results

    #number9
    def Generate_First_Environment_Based_on_question_list(self):
        results=[]
        if self.my_config.Environment_question_list!=None:
            environments=self.Generate_All_Environments()
            for use_type in self.my_config.Environment_question_list:
                Flag=False
                count=0
                for env in environments:
                    if use_type==env.type_Id and Flag==False:
                        results.append(env)
                        Flag=True
                        count=count-1
                    count=count+1
                    if count==len(environments):
                        results.append(None)
                        print self.my_config.Environment_Question_Types[use_type], "No such type environment exist, please regenerate environments"
            return results
        else:
            print 'system error'
            return None

    #number10
    def Generate_several_Environments_Based_On_question(self):
        results=[]
        if self.my_config.Environment_question!=None:
            environments=self.Generate_All_Environments()
            count=0
            for env in environments:
                if self.my_config.Environment_question==env.type_Id:
                    results.append(env)
                    count=count-1
                count=count+1
                if count==count==len(environments):
                   results.append(None)
                   print "No such type environment exist, please regenerate environments"
            return results
        else:
            print 'system error'
            return None

    #number11
    def Generate_several_Environments_Based_On_question_list(self):
        results=[]
        if self.my_config.Environment_question_list!=None:
            environments=self.Generate_All_Environments()
            for use_type in self.my_config.Environment_question_list:
                for env in environments:
                    if use_type==env.type_Id:
                        results.append(env)
            return results
        else:
            print 'system error'
            return None

    #number12
    def Use_Address_Generate_Environment(self,Address):
        result=self.use_EM.Read_One_Environments(Address)
        return result

    #number13
    def Use_Address_List_Generate_Environment(self):
        environments=[]
        for i in self.my_config.Environment_Lists:
            Address=self.my_config.Environment_Whole_Address[i]
            result=self.use_EM.Read_One_Environments(Address)
            environments.append(result)
        return environments

    def Test(self):        
        print"======================================================="
        print "Number 1"
        print "Function Name:Get_All_Path(self)"
        print "purpose: get the whole environment path."
        #self.Get_All_Path()
        print"======================================================="
        print "Number 2"
        print "Function Name:Get_Environments(self,type,Conditions)"
        print "purpose: get the environment you choose ."
        print "parameter type: the type of how you generate environment 0,1,2,3,4,5"
        print "parameter conditions: the environment addresses you may use"
        #self.Set_Basic_Config(2,1)
        print"======================================================="
        print "Number 3"
        print "Function Name:Get_Environments_Type(self)"
        print "purpose: get the whole environment types."
        #self.Get_Environments_Type()
        print"======================================================="
        print "Number 4"
        print "Function Name:Basic_initial(self)"
        print "purpose: the basic set of environment machine."
        #self.Basic_initial()
        print"======================================================="
        print "Number 5"
        print "Name:Environment_results"
        print "purpose: the result of environments."
        #self.my_config.Test()
        print"======================================================="
        print "Number 6"
        print "Function Name:Generate_All_Environments(self)"
        print "purpose: get all the environments."
        #result=self.Generate_All_Environments()
        #self.Environment_results=result
        #print len(self.Environment_results)
        #for i in self.Environment_results:
        #    i.Test()
        print"======================================================="
        print "Number 7"
        print "Function Name: Generate_First_Environment_Based_on_question(self)"
        print "purpose: get the first environment which accord with input type."
        #self.Get_Environments(3,8)
        #print len(self.Environment_results)
        #for i in self.Environment_results:
        #    i.Test()
        print"======================================================="
        print "Number 8"
        print "Function Name:Complete_environment(self)"
        print "purpose: get the result of the environments."
        print"======================================================="
        print "Number 9"
        print "Function Name: Generate_First_Environment_Based_on_question_list(self)"
        print "purpose: get the first environment which accord with input type lists."
        #self.Get_Environments(4,[1,7])
        #print len(self.Environment_results)
        #for i in self.Environment_results:
        #    if i !=None:
        #        i.Test()
        #    else:
        #        print i
        print"======================================================="
        print "Number 10"
        print "Function Name: Generate_several_Environments_Based_On_question(self)"
        print "purpose: get all the environments which accord with input type."
        #self.Get_Environments(5,0)
        #print len(self.Environment_results)
        #for i in self.Environment_results:
        #    if i !=None:
        #        i.Test()
        #        print 1
        #    else:
        #        print i
        print"======================================================="
        print "Number 11"
        print "Function Name: Generate_several_Environments_Based_On_question_list(self)"
        print "purpose: get all the environments which accord with input type lists."
        #self.Get_Environments(6,[0,1])
        #print len(self.Environment_results)
        #for i in self.Environment_results:
        #    if i !=None:
        #        i.Test()
        #        print 1000
        #    else:
        #        print i
        print"======================================================="
        print "Number 12"
        print "Function Name: Use_Address_Generate_Environment(self,Address)"
        print "purpose: get the environment based on address."
        #self.Get_Environments(0,0)
        print"======================================================="
        print "Number 13"
        print "Function Name: Use_Address_List_Generate_Environment(self)"
        print "purpose: get the environment based on address list."
       
class Environment_Selection_Machine_V2:
    def __init__(self,in_address):   
        self.e_con=environment_config()
        self.env_M=environment_machine()
        self.address=self.Generate_Path(in_address)#number1
        self.file_list=self.GetFileList()#number2
        self.environments=self.environments_Translater()#number3

    #number4    
    def Generate_Path(self,address): 
        return self.e_con.File_Environment_Basic_Address +address

    #number5
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    #number6
    def GetFileList(self):
        FileList=[]
        if self.Is_File_Exist(self.address):
            FileNames=os.listdir(self.address)
            for i in FileNames:
                if self.e_con.File_Environmet_Basic_Type in i:
                    FileList.append(self.address+'\\'+ i)
        if len(FileList)>0:
            return FileList
        else:
            return None
    
    #number7
    def environments_Translater(self):
        environments=[]
        if self.file_list!=None:
            for i in self.file_list:
                e=self.env_M.Read_One_Environments(i)
                environments.append(e)
            return environments  
    
    #number8
    def Get_environments(self):
        return self.environments
           
    def Test(self):
        print"======================================================="
        print "Number 1"
        print "Name:address"
        print "purpose: the path save the environments"
        print ("value",self.address)
        print"======================================================="
        print "Number 2"
        print "Name:file_list"
        print "purpose: the file_list which  save the environments"
        print ("value",self.file_list)
        print"======================================================="
        print "Number 3"
        print "Name:environments"
        print "purpose: the read environments"
        print"======================================================="
        print "Number 4"
        print "Function Name:Generate_Path(self,address)"
        print "purpose: generate the path"
        print "parameter address: the file name like 'env'"
        print"======================================================="
        print "Number 5"
        print "Function Name:Is_File_Exist(self,file_Name)"
        print "purpose: judge the file is exist or not"
        print "parameter file_Name: the name of the file"
        print"======================================================="
        print "Number 6"
        print "Function Name:GetFileList(self)"
        print "purpose: generate the list of path which contain environments"
        print"======================================================="
        print "Number 7"
        print "Function Name:environments_Translater(self)"
        print "purpose: translate the environments"
        print"======================================================="
        print "Number 8"
        print "Function Name:Get_environments(self)"
        print "purpose: get the environments"
    

        
#e=Environment_Selection_Machine(1,[0,1])
#e.Test()
#print len(e.Environment_results)
#for i in e.Environment_results:
#     if i !=None:
#          i.Test()
#          print 1000
#     else:
#          print i
#e=Environment_Selection_Machine_V2('env1')
#e.Test()
