﻿from Basic_Config import Basic_Config
class environment_config:
    def __init__(self):
        self.basic_config=Basic_Config()
        self.condition_length=11    #1
        self.dont_care_symbol='#'   #3
        self.dont_care_probability=0.33#5
        self.posBits = 3#7
        self.numRelevantBits = 11#9 
        self.posRelevantBits = [0,1,2,3,4,5,6,7,8,9,10] #10

        self.Condition_Model_selections=['random','stable']#13
        self.Condition_Model=self.Condition_Model_selections[1]#14
        self.Condition_Max=500#15
        self.Condition_Min=10#16
        self.NumofConditions=100#17
        self.Environments=self.basic_config.Question_Types#22
        self.Rate_multiplexer=10#23
        self.Rate_hiddenEvenParity=10#24
        self.Rate_hiddenOddParity=10#25
        self.Rate_countOnes=10#26
        self.Rate_carry=10#27
        self.Rate_evenParity=10#28
        self.Rate_majorityOn=10#29
        self.Rate_dv1=10#30
        self.Environment_Set_options=['random','default','set']#39
        self.Environment_selected=self.Environment_Set_options[0]#40
        self.Environment_Default=[0,self.Environments[0]]#41
        self.Environment_Number_Set_Options=['random','sequence']#44
        self.Environment_Number_Set=self.Environment_Number_Set_Options[0]#45
        self.Environment_Random_Length=20#46
        self.Environment_sequence=[0,0,1,3,5,7,1,2,3]#47

        self.File_Environment_Basic_Name="Environment"#51
        self.File_Environment_Basic_Address="environment\\"#53
        self.File_Environmet_Basic_Type=".txt"#55
        self.File_Environment_Name_List=None#57

    def Set_condition_length(self,value):#2
        self.condition_length=value

    def Set_dont_care_symbol(self,value):#4
        self.dont_care_symbol=value

    def Set_dont_care_probability(self,value):#6
        self.Set_dont_care_probability=value 

    def Set_posBits(self,value):#8
        self.posBits=value 

    def Set_numRelevantBits(self,value):#11
        self.numRelevantBits=value 

    def Set_Condition_Model(self,value):#18
        self.Condition_Model=Condition_Model_selections[value]
         
    def Set_Condition_Max(self,value):#19
        self.Condition_Max=value 

    def Set_Condition_Min(self,value):#20
        self.Condition_Min=value 

    def Set_NumofConditions(self,value):#21
        self.NumofConditions=value 

    def Set_Rate_multiplexer(self,value):#31
        self.Rate_multiplexer=value 

    def Set_Rate_hiddenEvenParity(self,value):#32
        self.Rate_hiddenEvenParity=value 

    def Set_Rate_hiddenOddParity(self,value):#33
        self.Rate_hiddenOddParity=value 

    def Set_Rate_countOnes(self,value):#34
        self.Rate_countOnes=value 

    def Set_Rate_carry(self,value):#35
        self.Rate_carry=value 

    def Set_Rate_evenParity(self,value):#36
        self.Rate_evenParity=value 

    def Set_Rate_majorityOn(self,value):#37
        self.Rate_majorityOn=value 
    
    def Set_Rate_dv1(self,value):#38
        self.Rate_dv1=value 

    def Set_Environment_selected(self,value):#42
        self.Environment_selected=self.Environment_Set_options[value]

    def Set_Environment_Default(self,value):#43
        self.Environment_Default=[value,self.Environments[value]]

    def Set_Environment_Number_Set(self,value):#48
        self.Environment_Number_Set=self.Environment_Number_Set_Options[value]

    def Set_Environment_Random_Length(self,value):#49
        self.Environment_Random_Length=value

    def Set_Environment_sequence(self,value):#50
        self.Environment_sequence=value

    def Set_File_Environment_Basic_Name(self,value):#52
        self.File_Environment_Basic_Name=value

    def Set_File_Environment_Basic_Address(self,value):#54
        self.File_Environment_Basic_Address=value

    def Set_File_Environmet_Basic_Type(self,value):#56
        self.File_Environmet_Basic_Type=value

    def Set_File_Environmet_Basic_Type(self,value):#58
        self.File_Environmet_Basic_Type=value

#File_Environment_Name_List
    def Test_2(self):
        print"======================================================="
        print "Number 51"
        print "Name:File_Environment_Basic_Name"
        print "purpose: the basic name of the file "
        print ("value",self.File_Environment_Basic_Name)
        print"======================================================="
        print "Number 52"
        print "Function Name:Set_File_Environment_Basic_Name(self,value)"
        print "Parameter value: string "
        print "purpose: set the value of File_Environment_Basic_Name"
        print"======================================================="
        print "Number 53"
        print "Name:File_Environment_Basic_Address"
        print "purpose: the basic address of the file "
        print ("value",self.File_Environment_Basic_Address)
        print"======================================================="
        print "Number 54"
        print "Function Name:Set_File_Environment_Basic_Address(self,value)"
        print "Parameter value: string "
        print "purpose: set the value of File_Environment_Basic_Address"
        print"======================================================="
        print "Number 55"
        print "Name:File_Environmet_Basic_Type"
        print "purpose: the type of the file in linux and windows it may different in windows the type is .txt"
        print ("value",self.File_Environmet_Basic_Type)
        print"======================================================="
        print "Number 56"
        print "Function Name:Set_File_Environmet_Basic_Type(self,value)"
        print "Parameter value: string "
        print "purpose: set the value of File_Environmet_Basic_Type"
        print"======================================================="
        print "Number 57"
        print "Name:File_Environment_Name_List"
        print "purpose: the Name list of the environment"
        print ("value",self.File_Environment_Name_List)

    def Test(self):
        print "Number 1"
        print "Name: condition_length"
        print "purpose: the length of the condition"
        print ("value",self.condition_length)
        print"======================================================="
        print "Number 2"
        print "Function Name: Set_condition_length(self,value)"
        print "Parameter value: int, value of the condition_Length"
        print "purpose: set the value of condition_length"
        #self.Set_condition_length(5)
        #print self.condition_length
        print"======================================================="
        print "Number 3"
        print "Name: dont_care_symbol"
        print "purpose: the symbol of do not care"
        print ("value",self.dont_care_symbol)
        print"======================================================="
        print "Number 4"
        print "Function Name: Set_dont_care_symbol(self,value)"
        print "Parameter value: char, value of the dont_care_symbol"
        print "purpose: set the value of Set_dont_care_symbol"
        print"======================================================="
        print "Number 5"
        print "Name: dont_care_probability"
        print "purpose: the probability of do not care"
        print ("value",self.dont_care_probability)
        print"======================================================="
        print "Number 6"
        print "Function Name:Set_dont_care_probability(self,value)"
        print "Parameter value: char, value of the dont_care_probability"
        print "purpose: set the value of Set_dont_care_probability"
        print"======================================================="
        print "Number 7"
        print "Name:posBits "
        print "Notice: 2, 3, 4, 5, 6, and 7 for 6-, 11-, 20-, 37-, 70-, and 135-bits MUX respectively  "
        print "purpose: Multiplexer will use it"
        print ("value",self.posBits)
        print"======================================================="
        print "Number 8"
        print "Function Name:Set_posBits(self,value)"
        print "Parameter value: int , 2, 3, 4, 5, 6, and 7 for 6-, 11-, 20-, 37-, 70-, and 135-bits MUX respectively "
        print "purpose: set the value of posBits"
        print"======================================================="
        print "Number 9"
        print "Name:numRelevantBits"
        print "Notice: countOnes, hiddenEvenParity and hiddenOddParity environments "
        print "purpose: number of relevant bits"
        print ("value",self.numRelevantBits)
        print"======================================================="
        print "Number 10"
        print "Name:posRelevantBits"
        print "Notice: countOnes, hiddenEvenParity and hiddenOddParity environments "
        print "purpose: the hidden relevant bits"
        print ("value",self.posRelevantBits)
        print"======================================================="
        print "Number 11"
        print "Function Name:Set_numRelevantBits(self,value)"
        print "Parameter value: int , the length of relevent bits "
        print "purpose: set the value of numRelevantBits"
        print"======================================================="
        print "Number 12"
        print "Function Name:Set_posRelevantBits(self,value)"
        print "Parameter value: int[],just like[1,2,3,4] the relevent bits "
        print "purpose: set the value of posRelevantBits"
        print"======================================================="
        print "Number 13"
        print "Name:Condition_Model_selections"
        print "Notice: the options of environment condition random or stable "
        print "purpose: the options of the generate environment model"
        print ("value",self.Condition_Model_selections)
        print"======================================================="
        print "Number 14"
        print "Name:Condition_Model"
        print "Notice: the options of environment condition you have choosed random or stable "
        print "purpose: the option you choosed"
        print ("value",self.Condition_Model)
        print"======================================================="
        print "Number 15"
        print "Name:Condition_Max"
        print "Notice: while choose random the max number of the conditions "
        print "purpose: max number of conditions"
        print ("value",self.Condition_Max)
        print"======================================================="
        print "Number 16"
        print "Name:Condition_Min"
        print "Notice: while choose random the min number of the conditions "
        print "purpose: max number of conditions"
        print ("value",self.Condition_Min)
        print"======================================================="
        print "Number 17"
        print "Name:NumofConditions"
        print "Notice: while choose stable the number of the conditions "
        print "purpose:number of conditions"
        print ("value",self.NumofConditions)
        print"======================================================="
        print "Number 18"
        print "Function Name:Set_Condition_Model(self,value)"
        print "Parameter value: int,just 1 or 2 "
        print "purpose: set the value of Condition_Model"
        print"======================================================="
        print "Number 19"
        print "Function Name:Set_Condition_Max(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Condition_Max"
        print"======================================================="
        print "Number 20"
        print "Function Name:Set_Condition_Min(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Condition_Min"
        print"======================================================="
        print "Number 21"
        print "Function Name:Set_NumofConditions(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of NumofConditions"
        print"======================================================="
        print "Number 22"
        print "Name:Environments"
        print "purpose:the options of the environment"
        print ("value",self.Environments)
        print"======================================================="
        print "Number 23"
        print "Name:Rate_multiplexer"
        print "purpose:multiplexer environment exhibit rate"
        print ("value",self.Rate_multiplexer)
        print"======================================================="
        print "Number 24"
        print "Name:Rate_hiddenEvenParity"
        print "purpose:hiddenEvenParity environment exhibit rate"
        print ("value",self.Rate_hiddenEvenParity)
        print"======================================================="
        print "Number 25"
        print "Name:Rate_hiddenOddParity"
        print "purpose:hiddenOddParity environment exhibit rate"
        print ("value",self.Rate_hiddenOddParity)
        print"======================================================="
        print "Number 26"
        print "Name:Rate_countOnes"
        print "purpose:countOnes environment exhibit rate"
        print ("value",self.Rate_countOnes)
        print"======================================================="
        print "Number 27"
        print "Name:Rate_carry"
        print "purpose:carry environment exhibit rate"
        print ("value",self.Rate_carry)
        print"======================================================="
        print "Number 28"
        print "Name:Rate_evenParity"
        print "purpose:evenParity environment exhibit rate"
        print ("value",self.Rate_evenParity)
        print"======================================================="
        print "Number 29"
        print "Name:Rate_majorityOn"
        print "purpose:majorityOn environment exhibit rate"
        print ("value",self.Rate_majorityOn)
        print"======================================================="
        print "Number 30"
        print "Name:Rate_dv1"
        print "purpose:dv1 environment exhibit rate"
        print ("value",self.Rate_dv1)
        print"======================================================="
        print "Number 31"
        print "Function Name:Set_Rate_multiplexer(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_multiplexer"
        print"======================================================="
        print "Number 32"
        print "Function Name:Set_Rate_hiddenEvenParity(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_hiddenEvenParity"
        print"======================================================="
        print "Number 33"
        print "Function Name:Set_Rate_hiddenOddParity(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_hiddenOddParity"
        print"======================================================="
        print "Number 34"
        print "Function Name:Set_Rate_countOnes(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_countOnes"
        print"======================================================="
        print "Number 35"
        print "Function Name:Set_Rate_carry(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_carry"
        print"======================================================="
        print "Number 36"
        print "Function Name:Set_Rate_evenParity(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_evenParity"
        print"======================================================="
        print "Number 37"
        print "Function Name:Set_Rate_majorityOn(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_majorityOn"
        print"======================================================="
        print "Number 38"
        print "Function Name:Set_Rate_dv1(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Rate_dv1"
        print"======================================================="
        print "Number 39"
        print "Name:Environment_Set_options"
        print "purpose:set how to generate environment type default 1 or random 0"
        print ("value",self.Environment_Set_options)
        print"======================================================="
        print "Number 40"
        print "Name:Environment_selected"
        print "purpose:the set of how to generate environment"
        print ("value",self.Environment_selected)
        print"======================================================="
        print "Number 41"
        print "Name:Environment_Default"
        print "purpose:the default set of how to generate environment"
        print ("value",self.Environment_Default)
        print"======================================================="
        print "Number 42"
        print "Function Name:Set_Environment_selected(self,value)"
        print "Parameter value: int 0 or 1"
        print "purpose: set the value of Environment_selected"
        print"======================================================="
        print "Number 43"
        print "Function Name:Set_Environment_Default(self,value)"
        print "Parameter value: int [0~7]"
        print "purpose: set the value of Environment_Default"    
        print"======================================================="
        print "Number 44"
        print "Name:Environment_Number_Set_Options"
        print "purpose:options  for how to generate a set of environment based on random or sequence"
        print ("value",self.Environment_Number_Set_Options)
        print"======================================================="
        print "Number 45"
        print "Name:Environment_Number_Set"
        print "purpose: set how to generate a set of environment based on random 0 or sequence 1"
        print ("value",self.Environment_Number_Set)
        print"======================================================="
        print "Number 46"
        print "Name:Environment_Random_Length"
        print "purpose: while set random set how many environments you want"
        print ("value",self.Environment_Random_Length)
        print"======================================================="
        print "Number 47"
        print "Name:Environment_sequence"
        print "purpose:owhile set sequence here is the sequence use for generate a set of environment"
        print ("value",self.Environment_sequence)
        print"======================================================="
        print "Number 48"
        print "Function Name:Set_Environment_Number_Set(self,value)"
        print "Parameter value: int 0 or 1"
        print "purpose: set the value of Environment_Number_Set"
        print"======================================================="
        print "Number 49"
        print "Function Name:Set_Environment_Random_Length(self,value)"
        print "Parameter value: int "
        print "purpose: set the value of Environment_Random_Length"
        print"======================================================="
        print "Number 50"
        print "Function Name:Set_Environment_sequence(self,value)"
        print "Parameter value: int[] just like [1,2,1,4,6] from[0~7] "
        print "purpose: set the value of Environment_sequence"
