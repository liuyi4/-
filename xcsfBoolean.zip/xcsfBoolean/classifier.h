void setInitialVariables(Classifier *clfr, double setSize, int time);
void initializePopulation(ClassifierSet **population);
int getNumerositySum(ClassifierSet *set);
int getSetSize(ClassifierSet *set);

ClassifierSet* getMatchSet(ClassifierSet **population, ClassifierSet **killset, char state[], int itTime);
int nrActionsInSet(ClassifierSet *set, bool coveredActions[]);
bool isConditionMatched(char clfrCond[], char cond[]);
Classifier* matchingCondAndSpecifiedAct(char state[], int act, int setSize, int time);
void createMatchingCondition(char cond[], char state[]);

void getPredictionArray(ClassifierSet *ms, char state[]);
double getBestValue();
int randomActionWinner();
int bestActionWinner();
int rouletteActionWinner();

ClassifierSet* getActionSet(int action, ClassifierSet *ms);
void updateActionSet(ClassifierSet **aset, char state[], double maxPrediction, double reward, ClassifierSet **pop, ClassifierSet **killset);
void updateWeightVector(Classifier *cl, char state[], double P);
void updateFitness(ClassifierSet *aset);

void discoveryComponent(ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int itTime, char situation[]);
void getDiscoversSums(ClassifierSet *set, double *fitsum, int *setsum, int *gaitsum);
void setTimeStamps(ClassifierSet *set, int itTime);

void selectTwoClassifiers(Classifier **cl, Classifier **parents, ClassifierSet *set, double fitsum, int setsum);
Classifier* selectClassifierUsingTournamentSelection(ClassifierSet *set, int setsum, Classifier *notMe);
Classifier* selectClassifierUsingRWS(ClassifierSet *set, double fitsum);

void crossover(Classifier **cl, int crossoverType);
void uniformCrossover(Classifier **cl);
void onePointCrossover(Classifier **cl);
void twoPointCrossover(Classifier **cl);
void mutation(Classifier *clfr, char state[]);
void applyNicheMutation(Classifier *clfr, char state[]);
void applyGeneralMutation(Classifier *clfr, char state[]);
void mutateAction(Classifier *clfr);

void insertDiscoveredClassifier(Classifier **cl, Classifier **parents, ClassifierSet **set, ClassifierSet **pop, ClassifierSet **killset, int len);

void doActionSetSubsumption(ClassifierSet **aset, ClassifierSet **pop, ClassifierSet **killset);
void subsumeClassifier(Classifier *cl, Classifier **parents, ClassifierSet *locset, ClassifierSet **pop);
bool subsumeClassifierToSet(Classifier *cl, ClassifierSet *set);
bool subsumes(Classifier *cl1, Classifier * cl2);
bool isSubsumer(Classifier *cl);
bool isMoreGeneral(char first[], char second[]);

bool addClassifierToPointerSet(Classifier *cl, ClassifierSet **pointerset);
bool addClassifierToSet(Classifier *cl, ClassifierSet **clSet);
void addNewClassifierToSet(Classifier *cl, ClassifierSet **clSet);
bool equals(Classifier *clfr1, Classifier *clfr2);
bool isSameCondition(char cond1[], char cond2[]);

Classifier* deleteStochClassifier(ClassifierSet **pop);
double getDelProp(Classifier *clfr, double meanFitness);
Classifier* deleteTypeOfClassifier(ClassifierSet *setp, ClassifierSet *setpl, ClassifierSet **pop);
bool updateSet(ClassifierSet **uset, ClassifierSet *killset);
bool deleteClassifierPointerFromSet(ClassifierSet **set, Classifier *clp);

void freeSet(ClassifierSet **cls);
void freeClassifierSet(ClassifierSet **cls);
void freeClassifier(Classifier *cl);

void printClassifierSet(ClassifierSet *head);
void fprintClassifierSet(FILE *fp, ClassifierSet *head);
void printClassifier(Classifier *clfr);
void fprintClassifier(FILE *fp, Classifier *classifier);

ClassifierSet* sortClassifierSet(ClassifierSet **cls, int type);

void condensePopulation(ClassifierSet **population);
void simplifyPopulation(ClassifierSet **population);

double absoluteValue(double value);
