enum Environment{
    multiplexer, hiddenEvenParity, hiddenOddParity, countOnes, carry, evenParity, majorityOn, dv1
};

const Environment env = multiplexer;

const int condLength = 11; 

// multiplexer environment settings
const int posBits = 3;//2, 3, 4, 5, 6, and 7 for 6-, 11-, 20-, 37-, 70-, and 135-bits MUX respectively

// countOnes, hiddenEvenParity and hiddenOddParity environments settings
const int numRelevantBits = 11; 
const int posRelevantBits[] = {0,1,2,3,4,5,6,7,8,9,10}; 

const int maxPopSize = 1.5*1000; //Specifies the maximal number of micro-classifiers in the population. 
const int maxProblems = 20*100*1000; //training set 
const int maxPayoff = 1000;

const int numActions = 2; //0 or 1

struct Classifier{
	char condition[condLength];
	int action;
	double weightVector[condLength+1];
	double covarianceMatrix[condLength+1][condLength+1];
	double predictionValue;
	double predictionError;
	double accuracy;
	double fitness;
	int numerosity;
	int experience;
	double actionSetSize;
	int timeStamp;
};
struct ClassifierSet{
	Classifier *classifier;
	ClassifierSet *next;
};
